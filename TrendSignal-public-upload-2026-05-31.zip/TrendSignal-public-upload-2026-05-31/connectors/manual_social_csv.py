from __future__ import annotations

from pathlib import Path

from connectors.csv_social import load_social_csv_dir
from models import TrendObservation


class ManualSocialCsvConnector:
    """Loads real exported CSVs from restricted social or marketplace platforms."""

    def __init__(self, input_dir: Path) -> None:
        self.input_dir = input_dir

    def fetch(self) -> list[TrendObservation]:
        return load_social_csv_dir(self.input_dir)
