from __future__ import annotations

import logging
import base64
import os
import time
import urllib.parse
import urllib.request
import json
from datetime import date, datetime, timedelta, timezone

from models import TrendObservation

LOGGER = logging.getLogger(__name__)


class RedditConnector:
    """Live Reddit mention velocity connector using Reddit's OAuth API."""

    def __init__(
        self,
        terms: list[str],
        subreddits: list[str],
        recent_days: int = 3,
        baseline_days: int = 21,
        limit_per_query: int = 100,
    ) -> None:
        self.terms = terms
        self.subreddits = subreddits
        self.recent_days = recent_days
        self.baseline_days = baseline_days
        self.limit_per_query = limit_per_query
        self.client_id = os.getenv("REDDIT_CLIENT_ID")
        self.client_secret = os.getenv("REDDIT_CLIENT_SECRET")
        self.user_agent = os.getenv("REDDIT_USER_AGENT", "TrendSignal/0.1")

    def fetch(self) -> list[TrendObservation]:
        if not self.client_id or not self.client_secret:
            raise RuntimeError("REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET are required for live Reddit data.")

        token = self._access_token()
        subreddit_path = "+".join(self.subreddits)
        if not self.terms:
            return self._fetch_new_discussions(token, subreddit_path)
        observations: list[TrendObservation] = []
        for term in self.terms:
            rows = self._search_term(token, subreddit_path, term)
            recent_count, baseline_count, engagement = self._count_velocity(rows)
            baseline_daily = baseline_count / max(self.baseline_days, 1)
            recent_daily = recent_count / max(self.recent_days, 1)
            growth = (recent_daily - baseline_daily) / max(baseline_daily, 1)
            observations.append(
                TrendObservation(
                    term=term,
                    raw_term=term,
                    normalized_term=_normalize(term),
                    source="reddit",
                    platform="reddit",
                    date=date.today(),
                    mentions=float(recent_count),
                    engagement=float(engagement),
                    growth_rate=growth,
                    metadata={
                        "subreddits": self.subreddits,
                        "recent_days": self.recent_days,
                        "baseline_days": self.baseline_days,
                        "baseline_mentions": baseline_count,
                    },
                )
            )
        return observations

    def _fetch_new_discussions(self, token: str, subreddit_path: str) -> list[TrendObservation]:
        params = urllib.parse.urlencode({"limit": str(self.limit_per_query)})
        url = f"https://oauth.reddit.com/r/{subreddit_path}/new?{params}"
        request = urllib.request.Request(
            url,
            headers={"Authorization": f"Bearer {token}", "User-Agent": self.user_agent},
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
        observations: list[TrendObservation] = []
        for child in payload.get("data", {}).get("children", []):
            row = child.get("data", {})
            title = str(row.get("title") or "").strip()
            if not title:
                continue
            score = int(row.get("score") or 0)
            comments = int(row.get("num_comments") or 0)
            observations.append(
                TrendObservation(
                    term=title,
                    raw_term=title,
                    normalized_term=_normalize(title),
                    source="reddit",
                    platform="reddit",
                    date=date.today(),
                    mentions=1,
                    engagement=float(score + comments),
                    url=f"https://www.reddit.com{row.get('permalink')}" if row.get("permalink") else None,
                    title=title,
                    comments=float(comments),
                    timestamp=datetime.fromtimestamp(float(row.get("created_utc") or 0), tz=timezone.utc)
                    if row.get("created_utc")
                    else None,
                    raw_payload_json=json.dumps(row, ensure_ascii=True),
                    velocity=float(score + comments),
                    metadata={
                        "subreddit": row.get("subreddit"),
                        "reddit_score": score,
                        "reddit_comments": comments,
                        "source_score": float(score + 2 * comments),
                    },
                )
            )
        return observations

    def _access_token(self) -> str:
        payload = urllib.parse.urlencode({"grant_type": "client_credentials"}).encode("utf-8")
        request = urllib.request.Request(
            "https://www.reddit.com/api/v1/access_token",
            data=payload,
            headers={"User-Agent": self.user_agent},
            method="POST",
        )
        auth = f"{self.client_id}:{self.client_secret}".encode("utf-8")
        request.add_header("Authorization", f"Basic {base64.b64encode(auth).decode('ascii')}")
        with urllib.request.urlopen(request, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
        return str(data["access_token"])

    def _search_term(self, token: str, subreddit_path: str, term: str) -> list[dict]:
        params = urllib.parse.urlencode(
            {
                "q": f'"{term}"',
                "restrict_sr": "1",
                "sort": "new",
                "t": "month",
                "limit": str(self.limit_per_query),
            }
        )
        url = f"https://oauth.reddit.com/r/{subreddit_path}/search?{params}"
        request = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "User-Agent": self.user_agent,
            },
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
        time.sleep(0.6)
        return [child["data"] for child in data.get("data", {}).get("children", [])]

    def _count_velocity(self, rows: list[dict]) -> tuple[int, int, int]:
        now = datetime.now(timezone.utc)
        recent_cutoff = now - timedelta(days=self.recent_days)
        baseline_cutoff = now - timedelta(days=self.recent_days + self.baseline_days)
        recent_count = 0
        baseline_count = 0
        engagement = 0
        for row in rows:
            created = datetime.fromtimestamp(float(row.get("created_utc", 0)), tz=timezone.utc)
            if created >= recent_cutoff:
                recent_count += 1
                engagement += int(row.get("score") or 0) + int(row.get("num_comments") or 0)
            elif created >= baseline_cutoff:
                baseline_count += 1
        return recent_count, baseline_count, engagement


def _normalize(value: str) -> str:
    return " ".join(value.casefold().split())
