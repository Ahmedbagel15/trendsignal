from __future__ import annotations

import logging
import os
from datetime import date

from models import TrendObservation

LOGGER = logging.getLogger(__name__)


class GoogleAdsKeywordsConnector:
    """Optional second-stage Keyword Planner validator.

    This connector intentionally does not perform unrestricted discovery.
    KeywordPlanIdeaService should only receive product candidates that passed
    the inexpensive commercial filter.
    """

    def __init__(self) -> None:
        self.developer_token = os.getenv("GOOGLE_ADS_DEVELOPER_TOKEN")
        self.customer_id = os.getenv("GOOGLE_ADS_CUSTOMER_ID")
        self.config_path = os.getenv("GOOGLE_ADS_CONFIG_PATH", "google-ads.yaml")

    @property
    def enabled(self) -> bool:
        return bool(self.developer_token and self.customer_id)

    def fetch(self) -> list[TrendObservation]:
        if not self.enabled:
            raise RuntimeError("Google Ads credentials are required for Keyword Planner validation.")
        LOGGER.info("Google Ads Keyword Planner is validation-only; no unrestricted discovery request was sent.")
        return []

    def validate_terms(self, terms: list[str]) -> list[TrendObservation]:
        if not terms:
            return []
        if not self.enabled:
            raise RuntimeError("Google Ads credentials are required for Keyword Planner validation.")
        try:
            from google.ads.googleads.client import GoogleAdsClient  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError("Install google-ads to enable Google Ads Keyword Planner validation.") from exc
        client = GoogleAdsClient.load_from_storage(self.config_path)
        service = client.get_service("KeywordPlanIdeaService")
        request = client.get_type("GenerateKeywordIdeasRequest")
        request.customer_id = str(self.customer_id).replace("-", "")
        request.language = "languageConstants/1000"
        request.geo_target_constants.append("geoTargetConstants/2840")
        request.keyword_plan_network = client.enums.KeywordPlanNetworkEnum.GOOGLE_SEARCH
        request.keyword_seed.keywords.extend(terms)
        observations: list[TrendObservation] = []
        for idea in service.generate_keyword_ideas(request=request):
            metrics = idea.keyword_idea_metrics
            observations.append(
                TrendObservation(
                    term=str(idea.text),
                    raw_term=str(idea.text),
                    normalized_term=" ".join(str(idea.text).casefold().split()),
                    source="google_ads_keywords",
                    platform="google_ads_keywords",
                    date=date.today(),
                    mentions=float(metrics.avg_monthly_searches or 0),
                    search_volume=float(metrics.avg_monthly_searches or 0),
                    commercial_intent=0.75,
                    metadata={
                        "avg_monthly_searches": int(metrics.avg_monthly_searches or 0),
                        "competition": str(metrics.competition.name),
                        "competition_index": int(metrics.competition_index or 0),
                        "monthly_search_volumes": [
                            {
                                "year": int(volume.year),
                                "month": str(volume.month.name),
                                "monthly_searches": int(volume.monthly_searches or 0),
                            }
                            for volume in metrics.monthly_search_volumes
                        ],
                    },
                )
            )
        return observations
