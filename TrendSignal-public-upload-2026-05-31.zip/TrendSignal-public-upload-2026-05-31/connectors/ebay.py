from __future__ import annotations

import base64
import json
import logging
import os
import urllib.parse
import urllib.request
from datetime import date, datetime, timezone

from models import TrendObservation

LOGGER = logging.getLogger(__name__)


class EbayConnector:
    """Optional eBay Browse API marketplace validator.

    Browse data describes active listings. It does not expose private buyer
    identity or prove completed purchase flow.
    """

    def __init__(self, terms: list[str] | None = None, max_results_per_term: int = 25) -> None:
        self.terms = terms or []
        self.max_results_per_term = max_results_per_term
        self.client_id = os.getenv("EBAY_CLIENT_ID")
        self.client_secret = os.getenv("EBAY_CLIENT_SECRET")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)

    def fetch(self) -> list[TrendObservation]:
        if not self.enabled:
            raise RuntimeError("EBAY_CLIENT_ID and EBAY_CLIENT_SECRET are required for eBay Browse API data.")
        if not self.terms:
            LOGGER.info("eBay has no candidate terms yet; skipping marketplace validation.")
            return []
        token = self._access_token()
        observations: list[TrendObservation] = []
        for term in self.terms:
            payload = self._search(token, term)
            listings = payload.get("itemSummaries", [])
            prices = [_number(item.get("price", {}).get("value")) for item in listings]
            prices = [price for price in prices if price is not None]
            observations.append(
                TrendObservation(
                    term=term,
                    raw_term=term,
                    normalized_term=_normalize(term),
                    source="ebay",
                    platform="ebay",
                    date=date.today(),
                    mentions=float(payload.get("total") or len(listings)),
                    engagement=float(len(listings)),
                    price=sum(prices) / len(prices) if prices else None,
                    commercial_intent=0.75,
                    raw_payload_json=json.dumps(payload, ensure_ascii=True),
                    metadata={
                        "active_listing_count": payload.get("total") or len(listings),
                        "marketplace_listing_signal": min(1.0, len(listings) / max(self.max_results_per_term, 1)),
                        "inventory_signal": min(1.0, float(payload.get("total") or 0) / 1000),
                        "resale_price_signal": round(sum(prices) / len(prices), 2) if prices else 0,
                        "item_urls": [item.get("itemWebUrl") for item in listings if item.get("itemWebUrl")],
                        "conditions": sorted({str(item.get("condition") or "") for item in listings if item.get("condition")}),
                        "categories": [
                            category.get("categoryName")
                            for item in listings
                            for category in item.get("categories", [])
                            if category.get("categoryName")
                        ],
                        "source_score": float(payload.get("total") or len(listings)),
                    },
                )
            )
        return observations

    def _access_token(self) -> str:
        credentials = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode()).decode()
        request = urllib.request.Request(
            "https://api.ebay.com/identity/v1/oauth2/token",
            data=urllib.parse.urlencode(
                {"grant_type": "client_credentials", "scope": "https://api.ebay.com/oauth/api_scope"}
            ).encode(),
            headers={
                "Authorization": f"Basic {credentials}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            return str(json.loads(response.read().decode())["access_token"])

    def _search(self, token: str, term: str) -> dict:
        params = urllib.parse.urlencode({"q": term, "limit": str(self.max_results_per_term)})
        request = urllib.request.Request(
            f"https://api.ebay.com/buy/browse/v1/item_summary/search?{params}",
            headers={"Authorization": f"Bearer {token}", "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"},
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode())


def _normalize(value: str) -> str:
    return " ".join(value.casefold().split())


def _number(value: object) -> float | None:
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None
