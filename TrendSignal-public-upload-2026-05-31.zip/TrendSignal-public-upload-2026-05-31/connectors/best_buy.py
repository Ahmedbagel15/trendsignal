from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from datetime import date

from models import TrendObservation


class BestBuyConnector:
    """Optional Best Buy Recommendations API product-native discovery connector."""

    def __init__(self, max_results: int = 50) -> None:
        self.api_key = os.getenv("BEST_BUY_API_KEY")
        self.max_results = max_results

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    def fetch(self) -> list[TrendObservation]:
        if not self.enabled:
            raise RuntimeError("BEST_BUY_API_KEY is required for Best Buy Recommendations API data.")
        observations: list[TrendObservation] = []
        for feed_name in ("trendingViewed", "mostViewed"):
            payload = self._fetch_feed(feed_name)
            for rank, product in enumerate(_products(payload)[: self.max_results], start=1):
                name = str(product.get("name") or product.get("productName") or "").strip()
                if not name:
                    continue
                sku = str(product.get("sku") or "")
                url = str(product.get("url") or product.get("productUrl") or "") or None
                observations.append(
                    TrendObservation(
                        term=name,
                        raw_term=name,
                        normalized_term=" ".join(name.casefold().split()),
                        source="best_buy",
                        platform="best_buy",
                        date=date.today(),
                        title=name,
                        url=url,
                        mentions=float(max(self.max_results - rank + 1, 1)),
                        rank=float(rank),
                        price=_number(product.get("salePrice") or product.get("regularPrice")),
                        commercial_intent=0.9,
                        raw_payload_json=json.dumps(product, ensure_ascii=True),
                        metadata={
                            "feed": feed_name,
                            "sku": sku,
                            "rank": rank,
                            "category": product.get("categoryPath") or product.get("category"),
                            "source_score": float(max(self.max_results - rank + 1, 1)),
                        },
                    )
                )
        return observations

    def _fetch_feed(self, feed_name: str) -> object:
        params = urllib.parse.urlencode({"apiKey": str(self.api_key)})
        request = urllib.request.Request(
            f"https://api.bestbuy.com/beta/products/{feed_name}?{params}",
            headers={"User-Agent": "TrendSignal/0.1"},
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))


def _products(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("results", "products", "items"):
        rows = payload.get(key)
        if isinstance(rows, list):
            return [row for row in rows if isinstance(row, dict)]
    return []


def _number(value: object) -> float | None:
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None
