"""Data source connectors for TrendSignal."""

