from __future__ import annotations

from pathlib import Path

from connectors.csv_social import load_social_csv
from models import TrendObservation


class InstagramPlaceholderConnector:
    """CSV-backed connector until official or third-party Instagram access is added."""

    def __init__(self, csv_path: Path) -> None:
        self.csv_path = csv_path

    def fetch(self) -> list[TrendObservation]:
        return load_social_csv(self.csv_path)

