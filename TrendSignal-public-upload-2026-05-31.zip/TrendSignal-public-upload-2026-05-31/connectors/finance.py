from __future__ import annotations

import logging
from datetime import date, datetime

from models import FinanceSnapshot

LOGGER = logging.getLogger(__name__)


class FinanceConnector:
    def __init__(self, use_live: bool = False) -> None:
        self.use_live = use_live

    def fetch_snapshot(self, ticker: str) -> FinanceSnapshot:
        if not self.use_live:
            return FinanceSnapshot(ticker=ticker)
        try:
            import yfinance as yf

            stock = yf.Ticker(ticker)
            info = stock.info or {}
            earnings_date = self._extract_earnings_date(stock)
            history = stock.history(period="35d")
            price_change_30d = None
            if len(history) > 1:
                start = float(history["Close"].iloc[0])
                end = float(history["Close"].iloc[-1])
                price_change_30d = (end - start) / max(start, 0.01)
            return FinanceSnapshot(
                ticker=ticker,
                company_name=info.get("shortName") or info.get("longName"),
                market_cap=info.get("marketCap"),
                price_change_30d=price_change_30d,
                earnings_date=earnings_date,
                metadata={"currency": info.get("currency"), "sector": info.get("sector")},
            )
        except Exception:
            LOGGER.exception("Finance lookup failed for %s", ticker)
            return FinanceSnapshot(ticker=ticker)

    @staticmethod
    def _extract_earnings_date(stock: object) -> date | None:
        try:
            dates = stock.get_earnings_dates(limit=1)
            if dates is None or dates.empty:
                return None
            value = dates.index[0]
            if isinstance(value, datetime):
                return value.date()
            return value.to_pydatetime().date()
        except Exception:
            return None

