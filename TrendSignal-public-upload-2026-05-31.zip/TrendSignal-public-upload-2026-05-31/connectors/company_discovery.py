from __future__ import annotations

import logging
import json
import re
from pathlib import Path
from difflib import SequenceMatcher

try:
    import yaml
except ImportError:
    yaml = None

try:
    from rapidfuzz import fuzz, process
except ImportError:
    fuzz = None
    process = None

from models import CompanyExposure, MappingConfidence

LOGGER = logging.getLogger(__name__)


class CompanyDiscoveryConnector:
    """Dynamic-ish company discovery with explicit uncertainty.

    This layer combines known mappings, fuzzy matching, and category exposure
    rules. Future integrations can add Wikidata, OpenFIGI, SEC metadata,
    yfinance search, or web search without changing downstream scoring.
    """

    def __init__(self, mapping_path: Path) -> None:
        with mapping_path.open("r", encoding="utf-8") as handle:
            if yaml is not None:
                self.mapping = yaml.safe_load(handle) or {}
            else:
                self.mapping = json.load(handle)
        self.known = self.mapping.get("known_mappings", {})
        self.categories = self.mapping.get("category_exposures", {})

    def discover(self, trend: str, entities: list[str]) -> list[CompanyExposure]:
        exposures: list[CompanyExposure] = []
        search_terms = [trend, *entities]

        for term in search_terms:
            direct = self._direct_mapping(term)
            if direct:
                exposures.append(direct)

        exposures.extend(self._fuzzy_mappings(search_terms))
        exposures.extend(self._category_mappings(trend))
        if _contains_phrase(trend, "stanley cup"):
            exposures = [exposure for exposure in exposures if exposure.ticker != "SWK"]
        return _dedupe_exposures(exposures)

    def _direct_mapping(self, term: str) -> CompanyExposure | None:
        for brand, data in self.known.items():
            if brand.lower() == "stanley" and "cup" in term.lower():
                continue
            if _contains_phrase(term, brand):
                return CompanyExposure(
                    ticker=str(data["ticker"]),
                    company_name=data.get("company_name"),
                    brand_entity=brand,
                    relationship=data.get("relationship", "direct"),
                    confidence=MappingConfidence.DIRECT,
                    ticker_purity=0.95,
                    revenue_relevance=0.75,
                    source="brand_to_ticker.yaml",
                )
        return None

    def _fuzzy_mappings(self, terms: list[str]) -> list[CompanyExposure]:
        brand_names = list(self.known.keys())
        exposures: list[CompanyExposure] = []
        for term in terms:
            match = _extract_one(term, brand_names)
            if not match:
                continue
            brand, score, _ = match
            if score < 90 or not _shares_meaningful_token(term, brand):
                continue
            data = self.known[brand]
            exposures.append(
                CompanyExposure(
                    ticker=str(data["ticker"]),
                    company_name=data.get("company_name"),
                    brand_entity=brand,
                    relationship=data.get("relationship", "fuzzy brand match"),
                    confidence=MappingConfidence.PROBABLE,
                    ticker_purity=0.8,
                    revenue_relevance=0.65,
                    source="rapidfuzz",
                    notes=f"Fuzzy score {score}. Validate before relying on mapping.",
                )
            )
        return exposures

    def _category_mappings(self, trend: str) -> list[CompanyExposure]:
        exposures: list[CompanyExposure] = []
        lower = trend.lower()
        for category, rows in self.categories.items():
            if not _contains_phrase(lower, category):
                continue
            for row in rows:
                confidence = MappingConfidence(row.get("confidence", "speculative"))
                exposures.append(
                    CompanyExposure(
                        ticker=str(row["ticker"]),
                        company_name=row.get("company_name"),
                        brand_entity=category,
                        relationship=row.get("relationship", "category exposure"),
                        confidence=confidence,
                        ticker_purity=_purity_for_confidence(confidence),
                        revenue_relevance=_revenue_for_confidence(confidence),
                        source="category_exposures",
                    )
                )
        return exposures


def _purity_for_confidence(confidence: MappingConfidence) -> float:
    return {
        MappingConfidence.DIRECT: 0.95,
        MappingConfidence.PROBABLE: 0.72,
        MappingConfidence.WEAK: 0.42,
        MappingConfidence.SPECULATIVE: 0.22,
    }[confidence]


def _revenue_for_confidence(confidence: MappingConfidence) -> float:
    return {
        MappingConfidence.DIRECT: 0.75,
        MappingConfidence.PROBABLE: 0.55,
        MappingConfidence.WEAK: 0.3,
        MappingConfidence.SPECULATIVE: 0.15,
    }[confidence]


def _dedupe_exposures(exposures: list[CompanyExposure]) -> list[CompanyExposure]:
    best: dict[str, CompanyExposure] = {}
    for exposure in exposures:
        current = best.get(exposure.ticker)
        if current is None or exposure.ticker_purity > current.ticker_purity:
            best[exposure.ticker] = exposure
    return sorted(best.values(), key=lambda item: item.ticker_purity, reverse=True)


def _extract_one(term: str, choices: list[str]) -> tuple[str, float, int] | None:
    if process is not None and fuzz is not None:
        return process.extractOne(term, choices, scorer=fuzz.WRatio)
    if not choices:
        return None
    scored = [
        (choice, 100 * SequenceMatcher(None, term.lower(), choice.lower()).ratio(), index)
        for index, choice in enumerate(choices)
    ]
    return max(scored, key=lambda item: item[1])


def _contains_phrase(text: str, phrase: str) -> bool:
    return re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", text, re.IGNORECASE) is not None


def _shares_meaningful_token(term: str, brand: str) -> bool:
    term_tokens = {token for token in re.findall(r"[a-z0-9]+", term.lower()) if len(token) >= 3}
    brand_tokens = {token for token in re.findall(r"[a-z0-9]+", brand.lower()) if len(token) >= 3}
    return bool(term_tokens & brand_tokens)
