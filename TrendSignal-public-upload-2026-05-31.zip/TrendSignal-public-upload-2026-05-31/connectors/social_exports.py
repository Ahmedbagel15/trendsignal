from __future__ import annotations

import logging
from datetime import date
from pathlib import Path

import pandas as pd

from models import TrendObservation

LOGGER = logging.getLogger(__name__)

ALIASES = {
    "term": ("term", "hashtag", "query", "title", "name"),
    "platform": ("platform", "source", "network"),
    "views": ("views", "play_count", "plays"),
    "likes": ("likes", "favorites", "favourites"),
    "comments": ("comments", "replies"),
    "shares": ("shares", "reposts"),
    "saves": ("saves", "bookmarks"),
    "mentions": ("mentions", "post_count", "posts", "count"),
    "engagement": ("engagement", "engagements"),
    "growth_rate": ("growth_rate", "growth_rate_optional", "growth", "change"),
    "date": ("date", "observed_at", "exported_at", "created_at"),
    "url": ("url", "url_optional", "link"),
    "description": ("description", "caption", "notes"),
    "rank": ("rank", "position"),
    "category": ("category",),
    "creator": ("creator", "author", "channel"),
}
PLATFORM_WEIGHTS = {
    "tiktok_creative_center": 1.30,
    "tiktok_trending_searches": 1.25,
    "instagram_explore": 1.00,
    "x_twitter_export": 0.85,
    "generic_csv": 0.75,
}


class SocialExportsConnector:
    """Ingests manual social exports without scraping restricted platforms."""

    def __init__(self, input_dir: Path) -> None:
        self.input_dir = input_dir

    def fetch(self) -> list[TrendObservation]:
        if not self.input_dir.exists():
            LOGGER.warning("Social export directory missing: %s", self.input_dir)
            return []
        observations: list[TrendObservation] = []
        for path in sorted(self.input_dir.glob("*.csv")):
            try:
                observations.extend(self._load(path))
            except Exception:
                LOGGER.exception("Skipping unreadable social export: %s", path)
        return observations

    def _load(self, path: Path) -> list[TrendObservation]:
        frame = pd.read_csv(path, keep_default_na=False)
        columns = {str(column).strip().lower(): str(column) for column in frame.columns}
        term_column = _column(columns, "term")
        if term_column is None:
            raise ValueError("No term-like column found.")

        observations: list[TrendObservation] = []
        for raw in frame.to_dict("records"):
            term = _text(raw.get(term_column))
            if not term:
                continue
            platform = _text(_value(raw, columns, "platform")) or _platform_from_filename(path)
            views = _number(_value(raw, columns, "views"))
            likes = _number(_value(raw, columns, "likes"))
            comments = _number(_value(raw, columns, "comments"))
            shares = _number(_value(raw, columns, "shares"))
            saves = _number(_value(raw, columns, "saves"))
            mentions = _number(_value(raw, columns, "mentions")) or views
            engagement = _number(_value(raw, columns, "engagement")) or likes + comments + shares + saves
            growth = _optional_number(_value(raw, columns, "growth_rate"))
            rank = _optional_number(_value(raw, columns, "rank"))
            weight = _platform_weight(platform)
            weighted_engagement = weight * (likes + 2 * comments + 3 * shares + 2 * saves)
            export_rank_score = 0.0 if not rank else max(0.0, 1.0 - (rank - 1) / 100)
            velocity = max(0.0, growth or 0.0) * max(mentions, 1.0)
            virality = weighted_engagement + velocity + export_rank_score * 100
            observations.append(
                TrendObservation(
                    term=term,
                    raw_term=term,
                    normalized_term=_normalize(term),
                    source="social_exports",
                    platform=platform,
                    date=_parsed_date(_value(raw, columns, "date")),
                    mentions=mentions,
                    engagement=engagement,
                    growth_rate=growth,
                    url=_text(_value(raw, columns, "url")) or None,
                    title=term,
                    description=_text(_value(raw, columns, "description")) or None,
                    views=views,
                    likes=likes,
                    comments=comments,
                    shares=shares,
                    saves=saves,
                    rank=rank,
                    source_file=path.name,
                    raw_payload_json=pd.Series(raw).to_json(),
                    velocity=velocity,
                    commercial_intent=_commercial_intent(term),
                    metadata={
                        "shares": shares,
                        "saves": saves,
                        "rank": rank,
                        "category": _text(_value(raw, columns, "category")),
                        "creator": _text(_value(raw, columns, "creator")),
                        "source_file": path.name,
                        "platform_weight": weight,
                        "platform_weighted_engagement": round(weighted_engagement, 3),
                        "export_rank_score": round(export_rank_score, 3),
                        "social_export_velocity_score": round(velocity, 3),
                        "early_social_virality_score": round(virality, 3),
                        "source_score": round(virality, 3),
                    },
                )
            )
        return observations


def _column(columns: dict[str, str], key: str) -> str | None:
    return next((columns[alias] for alias in ALIASES[key] if alias in columns), None)


def _value(raw: dict[str, object], columns: dict[str, str], key: str) -> object:
    column = _column(columns, key)
    return raw.get(column) if column else None


def _platform_from_filename(path: Path) -> str:
    stem = path.stem.lower()
    if "creative" in stem and "tiktok" in stem:
        return "tiktok_creative_center"
    if "tiktok" in stem:
        return "tiktok_trending_searches"
    if "instagram" in stem:
        return "instagram_explore"
    if "twitter" in stem or stem.startswith("x_"):
        return "x_twitter_export"
    return "generic_csv"


def _platform_weight(platform: str) -> float:
    normalized = platform.strip().lower().replace(" ", "_").replace("/", "_")
    return PLATFORM_WEIGHTS.get(normalized, PLATFORM_WEIGHTS["generic_csv"])


def _commercial_intent(text: str) -> float:
    lower = text.lower()
    cues = ("review", "buy", "dupe", "unboxing", "worth it", "finds", "product", "gadget", "device")
    return min(1.0, 0.35 + 0.12 * sum(cue in lower for cue in cues))


def _normalize(value: str) -> str:
    return " ".join(value.casefold().lstrip("#").split())


def _parsed_date(value: object) -> date:
    if value is None or _text(value) == "":
        return date.today()
    parsed = pd.to_datetime(value, errors="coerce")
    return date.today() if pd.isna(parsed) else parsed.date()


def _number(value: object) -> float:
    parsed = _optional_number(value)
    return parsed or 0.0


def _optional_number(value: object) -> float | None:
    if value is None or _text(value) == "":
        return None
    try:
        return float(str(value).replace(",", "").replace("%", ""))
    except ValueError:
        return None


def _text(value: object) -> str:
    return "" if value is None else str(value).strip()
