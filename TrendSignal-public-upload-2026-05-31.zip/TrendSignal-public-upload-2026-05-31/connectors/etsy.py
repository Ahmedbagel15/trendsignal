from __future__ import annotations

import json
import logging
import os
import urllib.parse
import urllib.request
from datetime import date, datetime, timezone

from models import TrendObservation

LOGGER = logging.getLogger(__name__)


class EtsyConnector:
    """Optional Etsy Open API v3 niche-product discovery connector."""

    def __init__(self, max_results: int = 100) -> None:
        self.keystring = os.getenv("ETSY_KEYSTRING")
        self.shared_secret = os.getenv("ETSY_SHARED_SECRET")
        self.max_results = min(max_results, 100)

    @property
    def enabled(self) -> bool:
        return bool(self.keystring and self.shared_secret)

    def fetch(self) -> list[TrendObservation]:
        if not self.enabled:
            raise RuntimeError("ETSY_KEYSTRING and ETSY_SHARED_SECRET are required for Etsy Open API data.")
        params = urllib.parse.urlencode({"limit": str(self.max_results), "sort_on": "created", "sort_order": "desc"})
        request = urllib.request.Request(
            f"https://openapi.etsy.com/v3/application/listings/active?{params}",
            headers={"x-api-key": f"{self.keystring}:{self.shared_secret}"},
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode())
        observations: list[TrendObservation] = []
        for listing in payload.get("results", []):
            title = str(listing.get("title") or "").strip()
            if not title:
                continue
            timestamp = _timestamp(listing.get("created_timestamp") or listing.get("creation_timestamp"))
            price = listing.get("price", {})
            observations.append(
                TrendObservation(
                    term=title,
                    raw_term=title,
                    normalized_term=" ".join(title.casefold().split()),
                    source="etsy",
                    platform="etsy",
                    date=date.today(),
                    title=title,
                    description=str(listing.get("description") or "")[:1000],
                    url=str(listing.get("url") or "") or None,
                    timestamp=timestamp,
                    price=_etsy_price(price),
                    mentions=1,
                    commercial_intent=0.8,
                    raw_payload_json=json.dumps(listing, ensure_ascii=True),
                    metadata={
                        "listing_id": listing.get("listing_id"),
                        "shop_id": listing.get("shop_id"),
                        "tags": listing.get("tags", []),
                        "taxonomy_id": listing.get("taxonomy_id"),
                        "updated_timestamp": listing.get("updated_timestamp"),
                        "source_score": 1.0,
                    },
                )
            )
        return observations


def _timestamp(value: object) -> datetime | None:
    try:
        return datetime.fromtimestamp(float(value), tz=timezone.utc)
    except (TypeError, ValueError, OSError):
        return None


def _etsy_price(value: object) -> float | None:
    if not isinstance(value, dict):
        return None
    try:
        return float(value.get("amount", 0)) / float(value.get("divisor", 100))
    except (TypeError, ValueError, ZeroDivisionError):
        return None
