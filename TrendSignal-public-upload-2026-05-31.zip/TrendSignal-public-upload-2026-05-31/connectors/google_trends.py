from __future__ import annotations

import logging
import json
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date

from models import TrendObservation

LOGGER = logging.getLogger(__name__)


class GoogleTrendsConnector:
    """Google Trends abstraction.

    pytrends can be fragile, so this connector is kept behind a narrow fetch
    contract. Swap this class with SerpApi, DataForSEO, or Glimpse without
    touching core ranking logic.
    """

    def __init__(
        self,
        terms: list[str],
        timeframe: str = "today 3-m",
        geo: str = "US",
        recent_days: int = 7,
        baseline_days: int = 30,
        batch_size: int = 1,
        request_delay_seconds: float = 20.0,
        max_attempts: int = 3,
        backoff_seconds: float = 120.0,
        discover_trending_searches: bool = True,
        trending_geo: str = "united_states",
        realtime_geo: str = "US",
        max_discovered_terms: int = 250,
        comprehensive_hours: int = 168,
        use_comprehensive_export: bool = True,
        allow_shallow_discovery_fallback: bool = False,
    ) -> None:
        self.terms = terms
        self.timeframe = timeframe
        self.geo = geo
        self.recent_days = recent_days
        self.baseline_days = baseline_days
        self.batch_size = batch_size
        self.request_delay_seconds = request_delay_seconds
        self.max_attempts = max_attempts
        self.backoff_seconds = backoff_seconds
        self.discover_trending_searches = discover_trending_searches
        self.trending_geo = trending_geo
        self.realtime_geo = realtime_geo
        self.max_discovered_terms = max_discovered_terms
        self.comprehensive_hours = comprehensive_hours
        self.use_comprehensive_export = use_comprehensive_export
        self.allow_shallow_discovery_fallback = allow_shallow_discovery_fallback

    def fetch(self) -> list[TrendObservation]:
        if self.discover_trending_searches and self.use_comprehensive_export:
            observations = self._fetch_comprehensive_export()
            if observations:
                LOGGER.info("Using %s comprehensive Google Trending Now observations.", len(observations))
                return observations
            if not self.allow_shallow_discovery_fallback:
                raise RuntimeError(
                    "Comprehensive Google Trending Now export failed. "
                    "Shallow RSS fallback is disabled because it cannot reliably scan for product trends."
                )
            LOGGER.warning("Comprehensive Google Trending Now export failed; trying shallow discovery fallback.")

        try:
            from pytrends.request import TrendReq
        except ImportError as exc:
            raise RuntimeError("pytrends is required for live Google Trends data. Run `pip install -r requirements.txt`.") from exc

        if self.discover_trending_searches:
            discovered_terms = self._discover_terms(TrendReq)
            if not discovered_terms:
                raise RuntimeError("Google trend discovery returned no terms. No seed fallback is enabled.")
            terms = discovered_terms
            LOGGER.info("Using %s Google-discovered trending searches.", len(terms))
        else:
            terms = self.terms
            if not terms:
                raise RuntimeError("No configured terms were provided and discovery mode is disabled.")

        observations: list[TrendObservation] = []
        chunks = _chunks(terms, self.batch_size)
        discovery_ranks = {term.casefold(): index for index, term in enumerate(terms, start=1)}
        for index, chunk in enumerate(chunks, start=1):
            LOGGER.info("Fetching Google Trends chunk: %s", ", ".join(chunk))
            frame = self._fetch_chunk(TrendReq, chunk)
            if frame is None:
                continue
            if frame.empty:
                LOGGER.warning("Google Trends returned no rows for chunk: %s", chunk)
                continue
            recent = frame.tail(self.recent_days)
            baseline = frame.iloc[: -self.recent_days].tail(self.baseline_days)
            for term in chunk:
                if term not in frame.columns:
                    continue
                recent_mean = float(recent[term].mean())
                baseline_mean = float(baseline[term].mean()) if not baseline.empty else recent_mean
                growth = (recent_mean - baseline_mean) / max(baseline_mean, 1)
                observations.append(
                    TrendObservation(
                        term=term,
                        raw_term=term,
                        normalized_term=term.casefold(),
                        source="google_trends",
                        platform="google_trends",
                        date=date.today(),
                        mentions=recent_mean,
                        search_volume=recent_mean,
                        engagement=recent_mean,
                        growth_rate=growth,
                        metadata={
                            "timeframe": self.timeframe,
                            "geo": self.geo,
                            "recent_days": self.recent_days,
                            "baseline_days": self.baseline_days,
                            "discovery_source": "google_trending_searches"
                            if self.discover_trending_searches
                            else "configured_terms",
                            "discovery_rank": discovery_ranks.get(term.casefold()),
                        },
                    )
                )
            if index < len(chunks):
                time.sleep(self.request_delay_seconds)
        return observations

    def _discover_terms(self, trend_req_class: object) -> list[str]:
        terms = self._discover_from_rss()
        if terms:
            return terms
        terms = self._discover_from_trending_searches(trend_req_class)
        if terms:
            return terms
        terms = self._discover_from_today_searches(trend_req_class)
        if terms:
            return terms
        return self._discover_from_realtime_searches(trend_req_class)

    def _fetch_comprehensive_export(self) -> list[TrendObservation]:
        try:
            from trendspyg import download_google_trends_csv

            envelope = download_google_trends_csv(
                geo=self.realtime_geo,
                hours=self.comprehensive_hours,
                category="all",
                sort_by="volume",
                headless=True,
                output_format="dict",
                normalize=True,
            )
            trends = envelope.get("trends", []) if isinstance(envelope, dict) else []
            ranked_trends = sorted(
                trends,
                key=lambda trend: float(trend.get("volume_min") or 0),
                reverse=True,
            )
            observations: list[TrendObservation] = []
            for rank, trend in enumerate(ranked_trends[: self.max_discovered_terms], start=1):
                term = str(trend.get("keyword") or "").strip()
                if not term:
                    continue
                observations.append(
                    TrendObservation(
                        term=term,
                        raw_term=term,
                        normalized_term=term.casefold(),
                        source="google_trends",
                        platform="google_trends",
                        date=date.today(),
                        mentions=float(trend.get("volume_min") or 0),
                        search_volume=float(trend.get("volume_min") or 0),
                        engagement=float(trend.get("volume_min") or 0),
                        raw_payload_json=json.dumps(trend, ensure_ascii=True),
                        metadata={
                            "discovery_source": "google_trending_now_comprehensive",
                            "discovery_rank": rank,
                            "source_rank": trend.get("rank"),
                            "volume_text": trend.get("volume_text"),
                            "started_at": trend.get("started_at"),
                            "ended_at": trend.get("ended_at"),
                            "is_active": trend.get("is_active"),
                            "related_queries": trend.get("related_queries", []),
                            "explore_url": trend.get("explore_url"),
                            "hours": self.comprehensive_hours,
                        },
                    )
                )
            return observations
        except Exception:
            LOGGER.exception("Comprehensive Google Trending Now export failed.")
            return []

    def _discover_from_rss(self) -> list[str]:
        url = f"https://trends.google.com/trending/rss?geo={self.realtime_geo}"
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=30) as response:
                raw = response.read()
            root = ET.fromstring(raw)
            terms: list[str] = []
            for item in root.findall(".//item"):
                title = item.findtext("title")
                if title and title.strip():
                    terms.append(title.strip())
            return _dedupe(terms)[: self.max_discovered_terms]
        except Exception as exc:
            LOGGER.warning("Google Trends RSS discovery failed: %s", exc)
            return []

    def _discover_from_trending_searches(self, trend_req_class: object) -> list[str]:
        try:
            pytrends = trend_req_class(hl="en-US", tz=360)
            frame = pytrends.trending_searches(pn=self.trending_geo)
            if frame.empty:
                return []
            terms = [str(value).strip() for value in frame.iloc[:, 0].tolist() if str(value).strip()]
            return _dedupe(terms)[: self.max_discovered_terms]
        except Exception as exc:
            LOGGER.warning("Google trending_searches discovery failed: %s", exc)
            return []

    def _discover_from_today_searches(self, trend_req_class: object) -> list[str]:
        try:
            pytrends = trend_req_class(hl="en-US", tz=360)
            frame = pytrends.today_searches(pn=self.realtime_geo)
            terms = [str(value).strip() for value in frame.tolist() if str(value).strip()]
            return _dedupe(terms)[: self.max_discovered_terms]
        except Exception as exc:
            LOGGER.warning("Google today_searches discovery failed: %s", exc)
            return []

    def _discover_from_realtime_searches(self, trend_req_class: object) -> list[str]:
        try:
            pytrends = trend_req_class(hl="en-US", tz=360)
            frame = pytrends.realtime_trending_searches(pn=self.realtime_geo, cat="all", count=self.max_discovered_terms)
            if frame.empty:
                return []
            candidate_columns = ["title", "entityNames"]
            terms: list[str] = []
            for column in candidate_columns:
                if column not in frame.columns:
                    continue
                for value in frame[column].tolist():
                    if isinstance(value, list):
                        terms.extend(str(item).strip() for item in value if str(item).strip())
                    elif str(value).strip():
                        terms.append(str(value).strip())
            return _dedupe(terms)[: self.max_discovered_terms]
        except Exception as exc:
            LOGGER.error("Google realtime_trending_searches discovery failed: %s", exc)
            return []

    def _fetch_chunk(self, trend_req_class: object, chunk: list[str]):
        last_error: Exception | None = None
        for attempt in range(1, self.max_attempts + 1):
            try:
                pytrends = trend_req_class(hl="en-US", tz=360)
                pytrends.build_payload(chunk, timeframe=self.timeframe, geo=self.geo)
                return pytrends.interest_over_time()
            except Exception as exc:
                last_error = exc
                message = str(exc).lower()
                rate_limited = "429" in message or "too many" in message
                if attempt >= self.max_attempts:
                    break
                wait = self.backoff_seconds * attempt if rate_limited else self.request_delay_seconds * attempt
                LOGGER.warning(
                    "Google Trends chunk failed on attempt %s/%s for %s. Waiting %.0fs before retry.",
                    attempt,
                    self.max_attempts,
                    ", ".join(chunk),
                    wait,
                )
                time.sleep(wait)
        LOGGER.error("Google Trends chunk failed permanently for %s: %s", ", ".join(chunk), last_error)
        return None


def _chunks(items: list[str], size: int) -> list[list[str]]:
    return [items[index : index + size] for index in range(0, len(items), size)]


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        key = item.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result
