from __future__ import annotations

import hashlib
import html
import json
import logging
import os
import re
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from models import TrendObservation

LOGGER = logging.getLogger(__name__)
API_ROOT = "https://www.googleapis.com/youtube/v3"
REVIEW_TERMS = ("review", "unboxing", "worth it", " vs ", "comparison", "test", "bought", "tried")
LEADING_NOISE = re.compile(
    r"^(?:is|are|the|best|new|viral|i tried|i bought|tiktok made me buy|amazon finds?|reviewing)\s+",
    re.IGNORECASE,
)
TRAILING_NOISE = re.compile(
    r"\s+(?:review|unboxing|worth it|comparison|test|viral|2026)(?:\b.*)?$",
    re.IGNORECASE,
)
GENERIC_CANDIDATE_WORDS = {
    "and",
    "best",
    "budget",
    "comparison",
    "full",
    "it",
    "new",
    "review",
    "test",
    "unboxing",
    "viral",
    "worth",
}
GENERIC_SINGLE_WORD_CANDIDATES = {
    "phone",
    "smartphone",
}
SENTENCE_FRAGMENT_WORDS = {
    "changed",
    "everything",
    "how",
    "live",
    "my",
    "this",
    "was",
    "what",
    "why",
    "you",
}


class YouTubeConnector:
    """Official YouTube Data API v3 discovery and manual-validation connector."""

    def __init__(
        self,
        recent_days: int = 7,
        baseline_days: int = 30,
        max_results: int = 25,
        max_terms_per_run: int = 10,
        region_code: str = "US",
        relevance_language: str = "en",
        query_groups: list[str] | None = None,
        query_templates: list[str] | None = None,
        max_queries_per_run: int = 40,
        cache_dir: Path | None = None,
        cache_ttl_hours: int = 24,
    ) -> None:
        self.api_key = os.getenv("YOUTUBE_API_KEY")
        self.recent_days = recent_days
        self.baseline_days = baseline_days
        self.max_results = max_results
        self.max_terms_per_run = max_terms_per_run
        self.region_code = region_code
        self.relevance_language = relevance_language
        self.query_groups = query_groups or []
        self.query_templates = query_templates or ["{query}"]
        self.max_queries_per_run = max_queries_per_run
        self.cache_dir = cache_dir
        self.cache_ttl_hours = cache_ttl_hours
        self.terms_queried = 0

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    def fetch(self) -> list[TrendObservation]:
        if not self.enabled:
            raise RuntimeError("YOUTUBE_API_KEY is required for YouTube discovery.")
        return self.fetch_youtube_discoveries(
            self.query_groups,
            published_after_days=self.recent_days,
            max_results_per_query=self.max_results,
        )

    def fetch_youtube_discoveries(
        self,
        query_groups: list[str],
        published_after_days: int,
        max_results_per_query: int,
    ) -> list[TrendObservation]:
        queries = self._expanded_queries(query_groups)[: self.max_queries_per_run]
        if not queries:
            return []
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(days=published_after_days)
        videos: dict[str, dict] = {}
        failed_queries: list[tuple[str, str]] = []
        workers = min(8, len(queries))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(self._search_cached, query, cutoff, now, max_results_per_query): query
                for query in queries
            }
            for future in as_completed(futures):
                query = futures[future]
                try:
                    for item in future.result().get("items", []):
                        video_id = item.get("id", {}).get("videoId")
                        if video_id:
                            videos[str(video_id)] = item
                except Exception:
                    error = str(future.exception())
                    failed_queries.append((query, error))
                    LOGGER.warning("YouTube discovery query failed: %s (%s)", query, error)

        if failed_queries and len(failed_queries) == len(queries):
            raise RuntimeError(
                f"All {len(queries)} YouTube discovery queries failed. "
                f"First error: {failed_queries[0][1]}"
            )
        if failed_queries:
            LOGGER.warning(
                "%s/%s YouTube discovery queries failed; continuing with successful responses.",
                len(failed_queries),
                len(queries),
            )

        statistics = self._statistics(list(videos))
        observations: list[TrendObservation] = []
        for video_id, item in videos.items():
            snippet = item.get("snippet", {})
            title = html.unescape(str(snippet.get("title") or "")).strip()
            description = html.unescape(str(snippet.get("description") or "")).strip()
            channel = html.unescape(str(snippet.get("channelTitle") or "")).strip()
            published_at = _parse_datetime(snippet.get("publishedAt")) or now
            stats = statistics.get(video_id, {})
            views = _int(stats.get("viewCount"))
            likes = _int(stats.get("likeCount"))
            comments = _int(stats.get("commentCount"))
            age_hours = max((now - published_at).total_seconds() / 3600, 1.0)
            views_per_hour = views / age_hours
            likes_per_hour = likes / age_hours
            comments_per_hour = comments / age_hours
            velocity = views_per_hour + 5 * likes_per_hour + 10 * comments_per_hour
            review_intent = min(1.0, 0.2 + 0.16 * sum(term in f" {title.lower()} " for term in REVIEW_TERMS))
            for candidate in _extract_candidates(title, description, channel):
                observations.append(
                    TrendObservation(
                        term=candidate,
                        raw_term=candidate,
                        normalized_term=_normalize(candidate),
                        source="youtube",
                        platform="youtube",
                        date=date.today(),
                        mentions=1,
                        engagement=float(views + likes + comments),
                        growth_rate=min(1.0, velocity / 10_000),
                        url=f"https://www.youtube.com/watch?v={video_id}",
                        title=title,
                        description=description,
                        timestamp=published_at,
                        raw_payload_json=json.dumps(item, ensure_ascii=True),
                        views=float(views),
                        likes=float(likes),
                        comments=float(comments),
                        velocity=velocity,
                        commercial_intent=review_intent,
                        metadata={
                            "video_id": video_id,
                            "channel_title": channel,
                            "published_at": published_at.isoformat(),
                            "video_age_hours": round(age_hours, 3),
                            "views_per_hour": round(views_per_hour, 3),
                            "likes_per_hour": round(likes_per_hour, 3),
                            "comments_per_hour": round(comments_per_hour, 3),
                            "youtube_velocity_score": round(velocity, 3),
                            "youtube_review_intent_score": round(review_intent, 3),
                            "source_score": round(velocity * max(review_intent, 0.25), 3),
                        },
                    )
                )
        return observations

    def fetch_for_term(self, term: str) -> TrendObservation | None:
        if not self.enabled:
            return None
        if self.terms_queried >= self.max_terms_per_run:
            LOGGER.info("YouTube query cap reached; skipping %s.", term)
            return None
        self.terms_queried += 1
        now = datetime.now(timezone.utc)
        recent_cutoff = now - timedelta(days=self.recent_days)
        baseline_cutoff = now - timedelta(days=self.baseline_days)
        recent = self._search(term, recent_cutoff, now)
        baseline = self._search(term, baseline_cutoff, recent_cutoff)
        recent_ids = [item["id"]["videoId"] for item in recent.get("items", []) if item.get("id", {}).get("videoId")]
        statistics = self._statistics(recent_ids)
        recent_count = len(recent_ids)
        baseline_count = len([item for item in baseline.get("items", []) if item.get("id", {}).get("videoId")])
        recent_daily = recent_count / max(self.recent_days, 1)
        baseline_daily = baseline_count / max(self.baseline_days - self.recent_days, 1)
        growth = (recent_daily - baseline_daily) / max(baseline_daily, 0.1)
        engagement = sum(
            _int(stats.get("viewCount")) + _int(stats.get("likeCount")) + _int(stats.get("commentCount"))
            for stats in statistics.values()
        )
        return TrendObservation(
            term=term,
            source="youtube",
            platform="youtube",
            date=date.today(),
            mentions=float(recent_count),
            engagement=float(engagement),
            growth_rate=growth,
            metadata={
                "recent_days": self.recent_days,
                "baseline_days": self.baseline_days,
                "recent_video_count": recent_count,
                "baseline_video_count": baseline_count,
                "recent_views": sum(_int(stats.get("viewCount")) for stats in statistics.values()),
                "quota_estimate_units": 201,
            },
        )

    def _expanded_queries(self, groups: list[str]) -> list[str]:
        seen: set[str] = set()
        queries: list[str] = []
        for group in groups:
            for template in self.query_templates:
                query = template.format(query=group).strip()
                key = query.casefold()
                if query and key not in seen:
                    seen.add(key)
                    queries.append(query)
        return queries

    def _search_cached(
        self,
        term: str,
        published_after: datetime,
        published_before: datetime,
        max_results: int,
    ) -> dict:
        cache_path = self._cache_path(term)
        if cache_path and cache_path.exists():
            age = datetime.now(timezone.utc).timestamp() - cache_path.stat().st_mtime
            if age <= self.cache_ttl_hours * 3600:
                return json.loads(cache_path.read_text(encoding="utf-8"))
        response = self._search(term, published_after, published_before, max_results=max_results)
        if cache_path:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(response), encoding="utf-8")
        return response

    def _cache_path(self, term: str) -> Path | None:
        if self.cache_dir is None:
            return None
        digest = hashlib.sha1(term.casefold().encode("utf-8")).hexdigest()[:16]
        return self.cache_dir / f"{digest}.json"

    def _search(
        self,
        term: str,
        published_after: datetime,
        published_before: datetime,
        max_results: int | None = None,
    ) -> dict:
        return self._get(
            "search",
            {
                "part": "snippet",
                "type": "video",
                "q": term,
                "publishedAfter": published_after.isoformat().replace("+00:00", "Z"),
                "publishedBefore": published_before.isoformat().replace("+00:00", "Z"),
                "order": "date",
                "maxResults": str(max_results or self.max_results),
                "regionCode": self.region_code,
                "relevanceLanguage": self.relevance_language,
                "safeSearch": "moderate",
            },
        )

    def _statistics(self, video_ids: list[str]) -> dict[str, dict]:
        result: dict[str, dict] = {}
        for index in range(0, len(video_ids), 50):
            chunk = video_ids[index : index + 50]
            if not chunk:
                continue
            response = self._get("videos", {"part": "statistics", "id": ",".join(chunk)})
            result.update({item["id"]: item.get("statistics", {}) for item in response.get("items", [])})
        return result

    def _get(self, path: str, params: dict[str, str]) -> dict:
        params["key"] = str(self.api_key)
        url = f"{API_ROOT}/{path}?{urllib.parse.urlencode(params)}"
        request = urllib.request.Request(url, headers={"User-Agent": "TrendSignal/0.1"})
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                return json.loads(response.read().decode("utf-8"))
        except Exception as exc:
            raise RuntimeError(f"YouTube API request failed for {path}: {exc}") from exc


def _extract_candidates(title: str, description: str, channel: str) -> list[str]:
    title = html.unescape(title)
    description = html.unescape(description)
    channel = html.unescape(channel)
    cleaned = re.sub(r"[\[\]#!?:]", " ", title)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    segments = re.split(r"\s+\bvs\.?\b\s+|\s+-\s+|\s+\|\s+", cleaned, flags=re.IGNORECASE)
    candidates: list[str] = []
    for segment in segments[:3]:
        candidate = LEADING_NOISE.sub("", segment).strip()
        candidate = TRAILING_NOISE.sub("", candidate).strip(" -")
        words = candidate.split()
        if _is_useful_candidate(candidate):
            candidates.append(candidate)
    evidence_text = f"{title}. {description[:600]}"
    patterns = [
        r"\bbest\s+(?P<item>[a-z0-9][a-z0-9 &+'-]{2,60}?)(?:\s*\||[.,;]|$)",
        r"(?P<item>[a-z0-9][a-z0-9 &+'-]{2,60}?)\s+(?:review|unboxing|comparison|worth it)",
        r"(?:tried|bought|buying|testing)\s+(?P<item>[a-z0-9][a-z0-9 &+'-]{2,60}?)(?:\s+and\s+|[.,;]|$)",
        r"tiktok made me buy\s+(?P<item>[a-z0-9][a-z0-9 &+'-]{2,60}?)(?:\s+and\s+|[.,;]|$)",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, evidence_text, re.IGNORECASE):
            candidate = _trim_candidate(match.group("item"))
            if candidate:
                candidates.append(candidate)
    for phrase in _repeated_phrases(title, description):
        candidates.append(phrase)
    if any(term in channel.lower() for term in ("review", "unbox", "finds")):
        candidates.extend(_repeated_phrases(channel, title))
    return _dedupe(candidates)


def _normalize(value: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9 ]+", " ", value.casefold()).split())


def _trim_candidate(value: str) -> str:
    candidate = LEADING_NOISE.sub("", value).strip(" -.,")
    return candidate if _is_useful_candidate(candidate) else ""


def _is_useful_candidate(value: str) -> bool:
    words = re.findall(r"[a-z0-9]+", value.casefold())
    meaningful = [word for word in words if word not in GENERIC_CANDIDATE_WORDS and not word.isdigit()]
    topical = [word for word in meaningful if word not in SENTENCE_FRAGMENT_WORDS]
    fragment_count = sum(word in SENTENCE_FRAGMENT_WORDS for word in words)
    return (
        1 <= len(words) <= 7
        and len(value) >= 3
        and bool(meaningful)
        and not (len(words) == 1 and words[0] in GENERIC_SINGLE_WORD_CANDIDATES)
        and not all(word in SENTENCE_FRAGMENT_WORDS or word in GENERIC_CANDIDATE_WORDS for word in words)
        and not (fragment_count >= 2 and len(topical) <= 1)
    )


def _repeated_phrases(left: str, right: str) -> list[str]:
    left_words = re.findall(r"[A-Za-z0-9][A-Za-z0-9+'-]*", left)
    right_lower = right.casefold()
    phrases: list[str] = []
    for size in (3, 2):
        for index in range(len(left_words) - size + 1):
            phrase = " ".join(left_words[index : index + size])
            if phrase.casefold() in right_lower and not any(term in phrase.casefold() for term in REVIEW_TERMS):
                phrases.append(phrase)
    return _dedupe(phrases)[:3]


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        key = item.casefold()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def _parse_datetime(value: object) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _int(value: object) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0
