from __future__ import annotations

from pathlib import Path

from connectors.csv_social import load_social_csv
from models import TrendObservation


class FacebookMarketplacePlaceholderConnector:
    """CSV-backed connector for exported listing/engagement trend data."""

    def __init__(self, csv_path: Path) -> None:
        self.csv_path = csv_path

    def fetch(self) -> list[TrendObservation]:
        return load_social_csv(self.csv_path)

