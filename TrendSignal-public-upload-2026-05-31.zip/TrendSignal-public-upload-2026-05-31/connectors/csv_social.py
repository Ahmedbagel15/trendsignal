from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from models import TrendObservation

LOGGER = logging.getLogger(__name__)


REQUIRED_COLUMNS = {"term", "platform", "mentions", "engagement", "date"}


def load_social_csv(path: Path) -> list[TrendObservation]:
    """Load manually exported social trend CSVs used by placeholder connectors."""
    if not path.exists():
        LOGGER.warning("CSV input missing: %s", path)
        return []

    frame = pd.read_csv(path)
    missing = REQUIRED_COLUMNS - set(frame.columns)
    if missing:
        raise ValueError(f"{path} is missing required columns: {sorted(missing)}")

    observations: list[TrendObservation] = []
    for row in frame.to_dict("records"):
        observations.append(
            TrendObservation(
                term=str(row["term"]).strip(),
                platform=str(row["platform"]).strip(),
                date=pd.to_datetime(row["date"]).date(),
                mentions=float(row.get("mentions") or 0),
                engagement=float(row.get("engagement") or 0),
                growth_rate=_optional_float(row.get("growth_rate_optional")),
                url=_optional_string(row.get("url_optional")),
            )
        )
    return observations


def load_social_csv_dir(directory: Path) -> list[TrendObservation]:
    if not directory.exists():
        LOGGER.warning("Social CSV input directory missing: %s", directory)
        return []
    observations: list[TrendObservation] = []
    for path in sorted(directory.glob("*.csv")):
        observations.extend(load_social_csv(path))
    return observations


def _optional_float(value: object) -> float | None:
    if value is None or pd.isna(value) or value == "":
        return None
    return float(value)


def _optional_string(value: object) -> str | None:
    if value is None or pd.isna(value) or value == "":
        return None
    return str(value)
