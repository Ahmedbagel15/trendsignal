# TrendSignal

TrendSignal is a Python research screener that generates a ranked watchlist of public stocks connected to accelerating consumer and social trends. It is not an auto-trading bot, does not connect to brokerages, and does not claim guaranteed alpha.

The MVP optimizes for one question: could this trend realistically affect company revenue or earnings? It intentionally deprioritizes pure virality, memes, dances, celebrity gossip, and other attention spikes with weak commercial linkage.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Add Reddit credentials to `.env` before running live Reddit collection:

```text
REDDIT_CLIENT_ID=your_app_client_id
REDDIT_CLIENT_SECRET=your_app_client_secret
REDDIT_USER_AGENT=TrendSignal/0.1 by your_reddit_username
```

Add a YouTube Data API v3 key to `.env` for official YouTube discovery and optional second-stage validation:

```text
YOUTUBE_API_KEY=your_api_key
```

## Run

For the local review dashboard, double-click `start_dashboard.command` in Finder. It starts TrendSignal in the background and opens a browser at:

```text
http://127.0.0.1:8765
```

The dashboard keeps API keys and collected files on your computer. Use **Run discovery** to collect new candidates, review decisions directly in the table, then use **Run validation** after approving the products worth deeper research. Labels such as **Too broad**, **Reject**, and **Adverse event** are written into the feedback memory immediately so later runs can avoid repeating known noise. The reports panel links to the generated Markdown and CSV files.

Double-click `stop_dashboard.command` when you want to stop the local dashboard.

The command-line workflow remains available for automation and troubleshooting.

Run broad discovery first:

```bash
python main.py discover
```

Review `data/processed/validation_queue.csv`. It includes cluster traceability, representative raw terms, cross-platform strength, evidence URLs, materiality, and preliminary public-company mapping. Set `decision` to `approve` only for products worth additional validation:

```csv
date,collection_run_id,cluster_id,canonical_term,raw_representative_term,sources_present,source_count,strongest_source,strongest_source_score,cross_platform_score,single_platform_breakout_score,commercial_intent_score,revenue_materiality_score,candidate_product,candidate_brand,candidate_company,candidate_ticker,investable_status,mapping_confidence,raw_observation_count,evidence_urls,hidden_signal_flag,decision,notes
2026-05-31,2026-05-31-abcd1234,21f7,oura ring 5,oura ring 5,google_trends,1,google_trends,200000,0.25,1.0,0.65,0,oura ring 5,,,,needs_mapping,,1,,,private_brand,good product signal but privately traded
```

Then run the second screener:

```bash
python main.py validate
```

Running `python main.py` without a mode is equivalent to `python main.py discover`.

The `decision` column can also preserve useful discoveries without spending API requests:

- `approve`: send this item to the second-stage APIs.
- `keep`: store this as a useful discovery and teach future ranking, but do not validate it.
- `watch`: store it with a smaller learning boost.
- `private_brand`: store a useful product signal with no clean public-equity path.
- `needs_mapping`: store a useful signal that needs more company research.
- `split_cluster`: preserve the cluster and flag a member term that deserves separate review next run.
- `merge_cluster`: flag canonical terms that should be reviewed for a manual merge.

Saved non-validation rows are copied to `data/processed/useful_discoveries.csv` when you next run either command. This is useful for products such as Oura Ring: the consumer signal may be good even when it is not directly investable.

Outputs are written to:

- `data/reports/YYYY-MM-DD_trend_report.md`
- `data/reports/YYYY-MM-DD_trend_report.csv`
- `data/reports/YYYY-MM-DD_discovery_audit.md`
- `data/reports/YYYY-MM-DD_discovery_audit.csv`
- `data/reports/YYYY-MM-DD_validation_audit.md`
- `data/reports/YYYY-MM-DD_validation_audit.csv`
- `data/reports/YYYY-MM-DD_source_errors.md`
- `data/reports/YYYY-MM-DD_youtube_discoveries.csv`
- `data/reports/YYYY-MM-DD_hidden_signal_report.md`
- `data/processed/raw_discoveries.csv`
- `data/processed/clustered_discoveries.csv`
- `data/processed/cluster_members.csv`
- `data/processed/orphan_signals.csv`
- `data/processed/useful_discoveries.csv`

If no discovered trend passes the commercial relevance, company mapping, and score filters, TrendSignal still writes the discovery audit and does not fabricate a watchlist.

The discovery audit includes two search views:

- Today's top discovered searches from the current live Google Trends discovery feed.
- Rolling 30-day recurring searches, based on the local archive in `data/processed/discovery_archive.csv`.

The 30-day view starts accumulating from the first day you run discovery mode. It cannot reconstruct old daily discovery feeds retroactively without a paid historical data provider.

## Teaching TrendSignal Over Time

After a run, review the discoveries in `data/reports/YYYY-MM-DD_discovery_audit.md`. Add useful or noisy terms to `data/processed/trend_feedback.csv`:

```csv
date,term,label,notes
2026-05-30,oura ring 5,valuable,strong purchasable product
2026-05-30,superfood supplement salmonella recall,adverse_event,recall is not positive demand
2026-05-30,flood watch,reject,weather search
```

Supported labels:

- `valuable`: strongly boost this item on future runs.
- `watch`: apply a smaller boost while you gather evidence.
- `private_brand`: preserve a useful discovery even when public stock exposure is unclear.
- `needs_mapping`: preserve a useful discovery that needs company research.
- `reject`: exclude the exact item on future runs.
- `adverse_event`: exclude recall, lawsuit, or other negative-demand noise.
- `too_broad`: exclude searches that are not specific enough to research.

TrendSignal checks this file during discovery and before YouTube validation, so repeated rejects do not consume YouTube quota. Exact labels have the strongest effect. Similar past searches receive a smaller, visible adjustment. The discovery audit shows the label, adjustment, and reason so the learning remains inspectable.

Cron example for every 3 days at 8am:

```cron
0 8 */3 * * cd /path/to/TrendSignal && /path/to/TrendSignal/.venv/bin/python main.py
```

## Architecture

- `connectors/`: source-specific data adapters.
- `core/trend_clusterer.py`: clusters related terms like `protein coffee`, `proffee`, and `high protein latte`.
- `core/commercial_filter.py`: filters for monetizable consumer behavior before scoring.
- `core/entity_mapper.py`: extracts brands, products, and candidate entities from trend text.
- `core/company_mapper.py`: maps trend entities to public-company exposure.
- `core/signal_scorer.py`: computes the final weighted score.
- `core/report_generator.py`: writes Markdown and CSV reports.
- `core/signal_aggregator.py`: computes strongest-source and cross-platform breakout metrics.
- `core/discovery_ledger.py`: preserves raw observations and writes inspectable cluster, orphan, and hidden-signal artifacts.
- `core/feedback.py`: learns cautious ranking adjustments from your review labels.
- `config/brand_to_ticker.yaml`: starter known mappings and category exposure rules. This is not a whitelist.
- `config/tracked_terms.yaml`: optional manual screening terms only when Google discovery is explicitly disabled.

## APIs and Inputs

Required now:

- `YOUTUBE_API_KEY` in `.env` for YouTube Data API v3 discovery and approved-candidate validation.

Already supported:

- Google Trends Trending Now broad discovery through the existing connector.
- Manual TikTok, Instagram, and X/Twitter CSV exports in `data/raw/social_exports/`.

Pending or optional:

- Reddit API credentials once approved.
- Best Buy developer key for product-native trending and most-viewed discovery: `BEST_BUY_API_KEY`.
- eBay developer credentials for Browse API marketplace validation: `EBAY_CLIENT_ID` and `EBAY_CLIENT_SECRET`.
- Etsy Open API v3 credentials for niche listing discovery: `ETSY_KEYSTRING` and `ETSY_SHARED_SECRET`.
- Google Ads API credentials and `google-ads.yaml` for Keyword Planner validation. Install the optional `google-ads` package before enabling it.

Every source independently produces `TrendObservation` rows. Aggregation is an inspectable convenience view, not a destructive step. Each discovery run preserves original rows in `data/processed/raw_discoveries.csv`, cluster assignments in `data/processed/cluster_members.csv`, and high-scoring singletons in `data/processed/orphan_signals.csv`.

## Data Sources

Each enabled source independently produces `TrendObservation` rows. TrendSignal ingests free manual social exports first, then runs the official YouTube API, Google Trends, and credentialed Reddit collection concurrently where possible. One source failure does not block the remaining sources. Connector-level issues are written to `data/reports/YYYY-MM-DD_source_errors.md`.

Google Trends is abstracted behind `connectors/google_trends.py`. Discovery mode uses the comprehensive free Google Trending Now table for the past seven days and re-sorts it by exported search-volume floor. Google is an independent discovery and confirmation source, not a gatekeeper. If its deeper export is unavailable, its connector reports an error without silently screening preset terms or falling back to the smaller RSS preview.

Best Buy uses the official Recommendations API only when enabled and credentialed. It contributes trending and most-viewed product feeds as product-native discovery evidence.

Reddit uses the official OAuth API with app credentials from `.env`. In discovery mode it scans recent discussions from the configured consumer and investing subreddits. Credentials are optional: missing credentials skip Reddit without blocking other sources.

YouTube uses the official YouTube Data API v3 for independent discovery. It runs the query groups in `config/youtube_queries.yaml`, caches query responses for 24 hours, deduplicates video IDs, enriches videos with public statistics, and extracts candidate products from review, comparison, unboxing, and purchase-intent titles. It also remains available for optional second-stage validation of manually approved queue rows.

eBay uses the official Browse API only when enabled and credentialed. It validates active listing counts, listing prices, item URLs, conditions, and categories for approved terms. These are marketplace signals, not claims about exact completed sales.

Etsy uses Open API v3 only when enabled and credentialed. It contributes newest active listings for niche-product discovery and captures titles, prices, shops, tags, categories, timestamps, and URLs. It does not pretend Etsy exposes exact sales velocity.

Google Ads Keyword Planner is optional and validation-only. It expands approved product candidates into keyword ideas and historical search-volume metrics. It is not treated as an unrestricted search-query firehose.

## Manual TikTok/Instagram Inputs

Do not scrape TikTok or Instagram pages directly. Download TikTok Creative Center or TikTok Trending Searches exports when available and place them in `data/raw/social_exports/`. For Instagram Explore screenshots, manually transcribe observed trends into CSV rows. X/Twitter exports and other normalized social CSVs can use the same folder.

The canonical schema is:

```text
term,platform,mentions,engagement,growth_rate,date,url,notes
```

The connector also maps common flexible fields such as `hashtag`, `query`, `title`, `views`, `play_count`, `likes`, `favorites`, `comments`, `shares`, `saves`, `rank`, `observed_at`, `exported_at`, and `link`. These files are treated as early social-virality signals. Sample TikTok and Instagram inputs live in `data/raw/sample_inputs/` and are not loaded automatically.

Finance data uses live `yfinance` by default. The scorer can use ticker metadata, market cap, recent performance, and earnings dates when available.

If a live connector fails, TrendSignal logs the error and continues with the remaining sources. It only stops when every enabled source fails or returns no observations. It does not silently replace failed live APIs with generated mock data.

## Scoring

Signal Score =

```text
0.15 * raw_attention_velocity
+ 0.15 * single_platform_breakout_score
+ 0.15 * cross_platform_confirmation_score
+ 0.15 * commercial_intent_score
+ 0.15 * consumer_purchase_signal
+ 0.10 * public_equity_mapping_score
+ 0.10 * revenue_materiality_score
+ 0.05 * novelty_score
- noise_penalty
```

The score is then adjusted for mapping confidence. Direct and probable mappings retain more score than weak or speculative mappings.

## Commercial Relevance Filtering

TrendSignal allows product, brand, service, and strong commerce-linked aesthetic trends into final scoring. It boosts purchase intent cues such as product names, brand names, shopping language, resale activity, reviews, comparison language, and marketplace listings.

It penalizes entertainment-only virality including dances, meme audios, lip syncs, reaction formats, celebrity drama, political discourse, and slang with no purchasable item or company exposure.

## Dynamic Company Discovery

The MVP supports:

- Known direct mappings from `brand_to_ticker.yaml`.
- Fuzzy brand/entity matching with RapidFuzz.
- Multi-company category exposure mapping.
- Indirect beneficiary mappings for suppliers, retailers, parent companies, and category leaders.
- Explicit confidence labels: direct, probable, weak, speculative.

The starter mappings are examples for testing and are not a stock universe restriction. Future versions can add Wikidata, OpenFIGI, SEC/company metadata, yfinance search, and web search integrations.

Optional OpenAI-compatible summarization lives in `core/llm_assistant.py`. Set `llm_enabled: true` in `config.yaml` and provide `OPENAI_API_KEY`, with optional `OPENAI_BASE_URL` and `OPENAI_MODEL`, to generate richer bull/bear narratives. Any LLM-only relationship should be marked uncertain until validated by structured data.

## Adding New Sources

Create a connector with a `fetch() -> list[TrendObservation]` method, register it in `config/sources.yaml`, then add its construction to `_collect_observations` in `main.py`. Keeping source logic behind connectors lets you swap providers without rewriting filtering, aggregation, mapping, scoring, or reporting.

## Legal and API Caveats

Respect source terms of service and API rate limits. TikTok, Instagram, and Facebook Marketplace access is restricted and can break if scraped. This MVP intentionally avoids brittle scraping and prefers official APIs, third-party APIs with permission, or manual exports. Google Trends via pytrends is unofficial and may rate-limit or fail; lower `batch_size`, increase `request_delay_seconds`, or use a paid Trends API if reliability matters.

## Limitations

Trend investing is noisy. Consumer attention may not translate into revenue, margins, or earnings. Public-company exposure may be indirect, already priced in, too small to matter, or difficult to validate. TrendSignal should be used as a research queue for manual review, never as a trading instruction.

## Future TODOs

- X/Twitter integration
- YouTube Shorts integration
- Amazon Movers & Shakers
- Shopify trend APIs
- Discord trend monitoring
- Earnings surprise backtesting
- Historical signal performance dashboard
- Portfolio simulation mode
- Alert system
- Dashboard charts and historical comparison views
