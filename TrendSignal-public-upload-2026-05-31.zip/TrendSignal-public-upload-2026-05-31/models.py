from __future__ import annotations

from datetime import date, datetime, timezone
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class TrendType(str, Enum):
    PRODUCT = "product"
    BRAND = "brand"
    SERVICE = "service"
    AESTHETIC = "aesthetic"
    ENTERTAINMENT = "entertainment"
    MEME = "meme"
    CREATOR_DRIVEN = "creator-driven"
    UNCLEAR = "unclear"


class MappingConfidence(str, Enum):
    DIRECT = "direct"
    PROBABLE = "probable"
    WEAK = "weak"
    SPECULATIVE = "speculative"


class InvestableStatus(str, Enum):
    PUBLIC_DIRECT = "public_direct"
    PUBLIC_INDIRECT = "public_indirect"
    PRIVATE_KNOWN = "private_known"
    UNKNOWN_COMPANY = "unknown_company"
    NEEDS_MAPPING = "needs_mapping"
    NO_INVESTABLE_PATH = "no_investable_path"


class TrendObservation(BaseModel):
    observation_id: str = Field(default_factory=lambda: uuid4().hex)
    term: str
    platform: str
    date: date
    source: str | None = None
    raw_term: str | None = None
    normalized_term: str | None = None
    timestamp: datetime | None = None
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    raw_payload_json: str | None = None
    source_file: str | None = None
    collection_run_id: str = ""
    mentions: float = 0
    search_volume: float = 0
    engagement: float = 0
    growth_rate: float | None = None
    url: str | None = None
    title: str | None = None
    description: str | None = None
    views: float = 0
    likes: float = 0
    comments: float = 0
    shares: float = 0
    saves: float = 0
    price: float | None = None
    rank: float | None = None
    velocity: float = 0
    commercial_intent: float = 0
    metadata: dict[str, Any] = Field(default_factory=dict)


class TrendCluster(BaseModel):
    cluster_id: str
    canonical_term: str
    terms: list[str]
    observations: list[TrendObservation]
    attention_velocity: float
    platforms: list[str]
    novelty: float = 0.5
    member_observation_ids: list[str] = Field(default_factory=list)
    evidence_urls: list[str] = Field(default_factory=list)
    evidence_sources: list[str] = Field(default_factory=list)
    earliest_seen_at: datetime | None = None
    earliest_seen_source: str = ""
    strongest_source: str = ""
    strongest_source_observation_id: str = ""


class ClusterAssignment(BaseModel):
    raw_observation_id: str
    cluster_id: str
    canonical_term: str
    raw_term: str
    source: str
    assignment_confidence: float
    assignment_reason: str


class CommercialAssessment(BaseModel):
    trend_type: TrendType
    commercial_intent: float
    purchase_intent: float
    rationale: str
    allowed_for_scoring: bool


class CompanyExposure(BaseModel):
    ticker: str
    company_name: str | None = None
    brand_entity: str
    relationship: str = "direct"
    confidence: MappingConfidence
    ticker_purity: float
    revenue_relevance: float
    source: str = "unknown"
    notes: str | None = None


class FinanceSnapshot(BaseModel):
    ticker: str
    company_name: str | None = None
    market_cap: float | None = None
    price_change_30d: float | None = None
    earnings_date: date | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Signal(BaseModel):
    run_date: date
    rank: int = 0
    trend: str
    brand_entity: str
    primary_ticker: str
    secondary_tickers: list[str] = Field(default_factory=list)
    mapping_confidence: MappingConfidence
    signal_score: float
    attention_velocity: float
    cross_platform_confirmation: float
    commercial_intent: float
    ticker_purity: float
    revenue_relevance: float
    novelty: float
    earnings_timing: float
    feedback_adjustment: float = 0.0
    feedback_reason: str = "No matching feedback."
    platforms: list[str]
    trend_type: TrendType
    confidence_level: str
    why_interesting: str
    bull_thesis: str
    bear_thesis: str
    confirm_signal: str
    invalidate_signal: str
    follow_up_research: str
    disclaimer: str = "Research signal only. Not financial advice."
