#!/bin/zsh
cd "$(dirname "$0")"
if [[ -f .trendsignal-dashboard.pid ]]; then
  kill "$(cat .trendsignal-dashboard.pid)" >/dev/null 2>&1
  rm .trendsignal-dashboard.pid
fi
