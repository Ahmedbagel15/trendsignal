from __future__ import annotations

import os
import unittest
from datetime import datetime, timezone
from unittest.mock import patch

from connectors.youtube import YouTubeConnector


class YouTubeConnectorTests(unittest.TestCase):
    @patch.dict(os.environ, {"YOUTUBE_API_KEY": "test-key"})
    def test_builds_confirmation_observation(self) -> None:
        connector = YouTubeConnector(recent_days=7, baseline_days=30, max_terms_per_run=1)
        connector._search = lambda term, after, before: {
            "items": [{"id": {"videoId": "a"}}, {"id": {"videoId": "b"}}]
            if (before - after).days <= 7
            else [{"id": {"videoId": "c"}}]
        }
        connector._statistics = lambda ids: {
            "a": {"viewCount": "100", "likeCount": "10", "commentCount": "2"},
            "b": {"viewCount": "50", "likeCount": "5", "commentCount": "1"},
        }

        observation = connector.fetch_for_term("oura ring 5")

        self.assertIsNotNone(observation)
        self.assertEqual("youtube", observation.platform)
        self.assertEqual(2, observation.mentions)
        self.assertEqual(168, observation.engagement)
        self.assertGreater(observation.growth_rate, 0)
        self.assertEqual(201, observation.metadata["quota_estimate_units"])

    @patch.dict(os.environ, {"YOUTUBE_API_KEY": "test-key"})
    def test_respects_term_query_cap(self) -> None:
        connector = YouTubeConnector(max_terms_per_run=0)
        self.assertIsNone(connector.fetch_for_term("oura ring 5"))

    @patch.dict(os.environ, {"YOUTUBE_API_KEY": "test-key"})
    def test_discovers_candidate_from_review_title(self) -> None:
        connector = YouTubeConnector(query_groups=["viral product"], max_queries_per_run=1)
        connector._search_cached = lambda term, after, before, max_results: {
            "items": [
                {
                    "id": {"videoId": "abc"},
                    "snippet": {
                        "title": "LED Face Mask Review",
                        "description": "I tested it",
                        "channelTitle": "Beauty Lab",
                        "publishedAt": datetime.now(timezone.utc).isoformat(),
                    },
                }
            ]
        }
        connector._statistics = lambda ids: {
            "abc": {"viewCount": "500", "likeCount": "50", "commentCount": "10"}
        }

        observations = connector.fetch()

        self.assertEqual("LED Face Mask", observations[0].term)
        self.assertEqual("youtube", observations[0].source)
        self.assertGreater(observations[0].velocity, 0)

    def test_extracts_candidate_from_purchase_intent_description(self) -> None:
        from connectors.youtube import _extract_candidates

        candidates = _extract_candidates(
            "My honest thoughts",
            "TikTok made me buy LED face mask and I tested it for a week.",
            "Beauty Lab",
        )

        self.assertIn("LED face mask", candidates)

    def test_does_not_extract_year_only_candidate(self) -> None:
        from connectors.youtube import _extract_candidates

        candidates = _extract_candidates(
            "AIR JORDAN 4 &quot;TORO BRAVO&quot; REVIEW AND COMPARISON 2013 VS 2026",
            "",
            "Sneaker Reviews",
        )

        self.assertNotIn("2026", candidates)
        self.assertNotIn("REVIEW AND", candidates)

    def test_extracts_specific_smartphone_phrase_instead_of_bare_phone(self) -> None:
        from connectors.youtube import _extract_candidates

        candidates = _extract_candidates(
            "Phone Unboxing 🔥 Best Budget Smartphone | Full Review &amp; First Impression",
            "",
            "Tech Reviews",
        )

        self.assertIn("Budget Smartphone", candidates)
        self.assertNotIn("Phone", candidates)

    def test_does_not_extract_sentence_scraps_from_worth_it_title(self) -> None:
        from connectors.youtube import _extract_candidates

        candidates = _extract_candidates(
            "PHOENIX CHANGED EVERYTHING... WAS IT WORTH IT? LIVE",
            "",
            "General Reviews",
        )

        self.assertNotIn("WAS IT", candidates)
        self.assertNotIn("PHOENIX CHANGED EVERYTHING... WAS IT", candidates)

    @patch.dict(os.environ, {"YOUTUBE_API_KEY": "test-key"})
    def test_discovery_raises_when_every_query_fails(self) -> None:
        connector = YouTubeConnector(query_groups=["viral product"], max_queries_per_run=1)
        connector._search_cached = lambda term, after, before, max_results: (_ for _ in ()).throw(
            RuntimeError("network unavailable")
        )

        with self.assertRaisesRegex(RuntimeError, "All 1 YouTube discovery queries failed"):
            connector.fetch()


if __name__ == "__main__":
    unittest.main()
