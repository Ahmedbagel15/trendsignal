from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from connectors.social_exports import SocialExportsConnector


class SocialExportsConnectorTests(unittest.TestCase):
    def test_maps_flexible_tiktok_export_columns(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tiktok_creative_center.csv"
            path.write_text(
                "hashtag,views,likes,comments,shares,observed_at\n"
                "ledfacemask,1000,100,10,5,2026-05-30\n",
                encoding="utf-8",
            )

            observations = SocialExportsConnector(Path(directory)).fetch()

            self.assertEqual(1, len(observations))
            self.assertEqual("ledfacemask", observations[0].term)
            self.assertEqual("tiktok_creative_center", observations[0].platform)
            self.assertGreater(observations[0].metadata["early_social_virality_score"], 0)
