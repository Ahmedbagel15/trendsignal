from __future__ import annotations

import tempfile
import unittest
from datetime import date
from pathlib import Path

from core.review_queue import ReviewQueue
from models import CommercialAssessment, TrendCluster, TrendObservation, TrendType


class ReviewQueueTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.queue = ReviewQueue(Path(self.temp_dir.name) / "validation_queue.csv")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_only_approved_rows_enter_second_screener(self) -> None:
        rows = [
            self._row("oura ring 5"),
            self._row("viral dress"),
        ]
        self.queue.upsert(rows)
        frame = self.queue.load()
        frame.loc[frame["canonical_term"] == "oura ring 5", "decision"] = "approve"
        frame.to_csv(self.queue.path, index=False)

        approved = self.queue.approved()

        self.assertEqual(["oura ring 5"], [row["canonical_term"] for row in approved])

    def test_new_discovery_preserves_existing_decision_and_notes(self) -> None:
        self.queue.upsert([self._row("oura ring 5")])
        frame = self.queue.load()
        frame.loc[0, "decision"] = "approve"
        frame.loc[0, "notes"] = "keep checking"
        frame.to_csv(self.queue.path, index=False)

        updated = self._row("oura ring 5")
        updated["strongest_source_score"] = 250000
        self.queue.upsert([updated])
        row = self.queue.load().iloc[0]

        self.assertEqual("approve", row["decision"])
        self.assertEqual("keep checking", row["notes"])
        self.assertEqual(250000, row["strongest_source_score"])

    def test_private_brand_is_archived_but_not_validated(self) -> None:
        self.queue.upsert([self._row("oura ring 5")])
        frame = self.queue.load()
        frame.loc[0, "decision"] = "private_brand"
        frame.loc[0, "notes"] = "good product signal but no direct public ticker"
        frame.to_csv(self.queue.path, index=False)
        archive_path = Path(self.temp_dir.name) / "useful_discoveries.csv"
        feedback_path = Path(self.temp_dir.name) / "trend_feedback.csv"

        saved_count = self.queue.archive_saved(archive_path, feedback_path)

        self.assertEqual(1, saved_count)
        self.assertEqual([], self.queue.approved())
        archive = archive_path.read_text(encoding="utf-8")
        feedback = feedback_path.read_text(encoding="utf-8")
        self.assertIn("oura ring 5,private_brand,private_brand", archive)
        self.assertIn("oura ring 5,private_brand", feedback)

    def test_refresh_run_replaces_stale_rows_including_prior_saved_choices(self) -> None:
        old_row = self._row("old stale noise")
        old_row["date"] = "2026-05-30"
        self.queue.upsert([old_row, self._row("saved product")])
        frame = self.queue.load()
        frame.loc[frame["canonical_term"] == "saved product", "decision"] = "watch"
        frame.to_csv(self.queue.path, index=False)

        self.queue.refresh_run([self._row("fresh product")], date.today())

        refreshed = self.queue.load()
        self.assertEqual(["fresh product"], sorted(refreshed["canonical_term"].tolist()))

    def test_keep_is_archived_as_valuable_feedback(self) -> None:
        self.queue.upsert([self._row("running vest")])
        frame = self.queue.load()
        frame.loc[0, "decision"] = "keep"
        frame.to_csv(self.queue.path, index=False)
        archive_path = Path(self.temp_dir.name) / "useful_discoveries.csv"
        feedback_path = Path(self.temp_dir.name) / "trend_feedback.csv"

        self.queue.archive_saved(archive_path, feedback_path)

        self.assertIn("running vest,valuable", feedback_path.read_text(encoding="utf-8"))

    @staticmethod
    def _row(term: str) -> dict[str, object]:
        cluster = TrendCluster(
            cluster_id="test",
            canonical_term=term,
            terms=[term],
            observations=[
                TrendObservation(term=term, platform="google_trends", date=date.today(), mentions=100)
            ],
            attention_velocity=0.5,
            platforms=["google_trends"],
        )
        assessment = CommercialAssessment(
            trend_type=TrendType.PRODUCT,
            commercial_intent=0.7,
            purchase_intent=0.7,
            rationale="test",
            allowed_for_scoring=True,
        )
        return ReviewQueue.row(date.today(), cluster, assessment, [])


if __name__ == "__main__":
    unittest.main()
