from __future__ import annotations

import tempfile
import unittest
from datetime import date
from pathlib import Path

from main import _collect_observations, _write_source_errors


class DiscoveryModeTests(unittest.TestCase):
    def test_source_error_report_preserves_connector_failure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = _write_source_errors(
                date.today(),
                [{"source": "google_trends", "error": "export failed"}],
                Path(directory),
            )

            self.assertIn("google_trends", path.read_text(encoding="utf-8"))
            self.assertIn("export failed", path.read_text(encoding="utf-8"))

    def test_manual_social_export_can_discover_without_google(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            export_dir = Path(directory)
            (export_dir / "instagram_explore.csv").write_text(
                "title,likes,comments,observed_at\npilates grip socks,500,20,2026-05-30\n",
                encoding="utf-8",
            )
            sources = {
                "social_exports": {"enabled": True, "input_dir": str(export_dir)},
                "youtube": {"enabled": False},
                "google_trends": {"enabled": False},
                "reddit": {"enabled": False},
            }
            config = {"paths": {"social_exports_dir": "data/raw/social_exports"}}

            observations, errors = _collect_observations(config, sources, [])

            self.assertEqual(1, len(observations))
            self.assertEqual("instagram_explore", observations[0].platform)
            self.assertEqual([], errors)


if __name__ == "__main__":
    unittest.main()
