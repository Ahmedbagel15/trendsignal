from __future__ import annotations

import unittest
from datetime import date

from core.signal_aggregator import SignalAggregator
from models import TrendCluster, TrendObservation


class SignalAggregatorTests(unittest.TestCase):
    def test_tracks_cross_platform_evidence(self) -> None:
        observations = [
            TrendObservation(
                term="led face mask",
                platform="youtube",
                source="youtube",
                date=date.today(),
                metadata={"source_score": 9000},
                title="LED Face Mask Review",
                url="https://example.com/video",
            ),
            TrendObservation(
                term="led face mask",
                platform="tiktok_creative_center",
                source="social_exports",
                date=date.today(),
                metadata={"source_score": 5000, "source_file": "tiktok.csv"},
            ),
        ]
        cluster = TrendCluster(
            cluster_id="test",
            canonical_term="led face mask",
            terms=["led face mask"],
            observations=observations,
            attention_velocity=0.5,
            platforms=["tiktok_creative_center", "youtube"],
        )

        result = SignalAggregator().aggregate(cluster)

        self.assertEqual(2, result.source_count)
        self.assertEqual("youtube", result.strongest_source)
        self.assertEqual(["tiktok_creative_center", "youtube"], result.sources_present)
        self.assertEqual("LED Face Mask Review", result.youtube_top_video_title)
        self.assertEqual("tiktok.csv", result.social_export_source_file)
