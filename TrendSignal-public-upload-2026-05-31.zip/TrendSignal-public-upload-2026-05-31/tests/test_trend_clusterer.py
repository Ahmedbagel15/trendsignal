from __future__ import annotations

import unittest
from datetime import date

from core.trend_clusterer import TrendClusterer
from models import TrendObservation


class TrendClustererTests(unittest.TestCase):
    def test_year_only_youtube_fragment_does_not_merge_unrelated_google_terms(self) -> None:
        observations = [
            TrendObservation(term="memorial day 2026", platform="google_trends", date=date.today()),
            TrendObservation(term="american music awards 2026", platform="google_trends", date=date.today()),
            TrendObservation(
                term="2026",
                normalized_term="2026",
                platform="youtube",
                source="youtube",
                date=date.today(),
                title="Air Jordan 4 Review and Comparison 2013 vs 2026",
            ),
        ]

        clusters = TrendClusterer().cluster(observations)
        by_term = {cluster.canonical_term: cluster for cluster in clusters}

        self.assertEqual(3, len(clusters))
        self.assertEqual(["google_trends"], by_term["memorial day 2026"].platforms)
        self.assertEqual(["google_trends"], by_term["american music awards 2026"].platforms)

    def test_distinctive_shared_product_words_can_still_cluster(self) -> None:
        observations = [
            TrendObservation(term="oura ring", platform="google_trends", date=date.today()),
            TrendObservation(term="oura ring gen 5", platform="youtube", date=date.today()),
        ]

        clusters = TrendClusterer().cluster(observations)

        self.assertEqual(1, len(clusters))
        self.assertEqual(["google_trends", "youtube"], clusters[0].platforms)

    def test_single_ordinary_word_does_not_merge_unrelated_sources(self) -> None:
        observations = [
            TrendObservation(term="kevin costner horizon prime video", platform="google_trends", date=date.today()),
            TrendObservation(term="prime vs aonic fuel", platform="youtube", date=date.today()),
            TrendObservation(term="clash in italy 2026", platform="google_trends", date=date.today()),
            TrendObservation(term="ps5 unboxing setup experience in 2026", platform="youtube", date=date.today()),
        ]

        clusters = TrendClusterer().cluster(observations)

        self.assertEqual(4, len(clusters))
        self.assertTrue(all(len(cluster.platforms) == 1 for cluster in clusters))

    def test_shared_brand_words_do_not_merge_distinct_shoe_models(self) -> None:
        observations = [
            TrendObservation(
                term="air jordan 1 travis scott shy pink",
                platform="google_trends",
                date=date.today(),
            ),
            TrendObservation(
                term='air jordan 4 "toro bravo"',
                platform="youtube",
                source="youtube",
                date=date.today(),
            ),
        ]

        clusters = TrendClusterer().cluster(observations)

        self.assertEqual(2, len(clusters))
        self.assertTrue(all(len(cluster.platforms) == 1 for cluster in clusters))


if __name__ == "__main__":
    unittest.main()
