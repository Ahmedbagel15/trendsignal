from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from connectors.best_buy import BestBuyConnector


class BestBuyConnectorTests(unittest.TestCase):
    @patch.dict(os.environ, {"BEST_BUY_API_KEY": "test-key"})
    def test_builds_product_native_observations_from_recommendation_feeds(self) -> None:
        connector = BestBuyConnector(max_results=5)
        connector._fetch_feed = lambda feed: [
            {"sku": "123", "name": f"LED Face Mask {feed}", "salePrice": 99.99, "url": "https://example.com/item"}
        ]

        observations = connector.fetch()

        self.assertEqual(2, len(observations))
        self.assertTrue(all(observation.source == "best_buy" for observation in observations))
        self.assertTrue(all(observation.price == 99.99 for observation in observations))
        self.assertEqual({"mostViewed", "trendingViewed"}, {observation.metadata["feed"] for observation in observations})


if __name__ == "__main__":
    unittest.main()
