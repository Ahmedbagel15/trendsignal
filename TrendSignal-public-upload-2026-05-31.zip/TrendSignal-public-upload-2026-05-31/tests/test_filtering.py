from __future__ import annotations

import unittest
from datetime import date
from pathlib import Path

from connectors.company_discovery import CompanyDiscoveryConnector
from core.commercial_filter import CommercialFilter
from core.entity_mapper import EntityMapper
from models import TrendCluster, TrendObservation


ROOT = Path(__file__).parents[1]


def cluster(term: str, related_queries: list[str] | None = None) -> TrendCluster:
    observation = TrendObservation(
        term=term,
        platform="google_trends",
        date=date.today(),
        metadata={"related_queries": related_queries or []},
    )
    return TrendCluster(
        cluster_id="test",
        canonical_term=term,
        terms=[term],
        observations=[observation],
        attention_velocity=0.5,
        platforms=["google_trends"],
    )


class FilteringTests(unittest.TestCase):
    def setUp(self) -> None:
        self.filter = CommercialFilter()
        self.entities = EntityMapper()
        self.discovery = CompanyDiscoveryConnector(ROOT / "config" / "brand_to_ticker.yaml")

    def test_sports_schedule_does_not_map_to_stanley(self) -> None:
        trend = cluster("stanley cup finals schedule")
        assessment = self.filter.assess(trend, [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_cavaliers_does_not_extract_or_map_cava(self) -> None:
        entities = self.entities.extract_entities("knicks vs cavaliers", ["knicks vs cavaliers"])
        self.assertNotIn("Cava", entities)
        self.assertEqual([], self.discovery.discover("knicks vs cavaliers", entities))

    def test_recall_is_not_positive_demand(self) -> None:
        trend = cluster("superfood supplement salmonella recall")
        assessment = self.filter.assess(trend, [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_real_product_still_passes(self) -> None:
        trend = cluster("oura ring 5", ["oura ring gen 5", "oura ring"])
        assessment = self.filter.assess(trend, [])
        self.assertTrue(assessment.allowed_for_scoring)

    def test_related_query_cannot_promote_person_to_product(self) -> None:
        trend = cluster("claude lemieux", ["claude lemieux ring"])
        assessment = self.filter.assess(trend, [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_stanley_drinkware_does_not_map_to_tools_company(self) -> None:
        self.assertEqual([], self.discovery.discover("stanley cup", ["Stanley"]))

    def test_ambiguous_watch_is_not_a_product(self) -> None:
        assessment = self.filter.assess(cluster("flood watch"), [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_sports_world_cup_is_not_a_product(self) -> None:
        assessment = self.filter.assess(cluster("2026 fifa world cup transit"), [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_market_commentary_is_not_a_product(self) -> None:
        assessment = self.filter.assess(cluster("one million new car buyers are gone"), [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_generic_one_word_product_is_not_a_useful_signal(self) -> None:
        assessment = self.filter.assess(cluster("jeans"), [])
        self.assertFalse(assessment.allowed_for_scoring)

    def test_specific_product_phrase_still_passes(self) -> None:
        assessment = self.filter.assess(cluster("olivia rodrigo babydoll dress"), [])
        self.assertTrue(assessment.allowed_for_scoring)

    def test_other_one_word_product_can_still_pass(self) -> None:
        assessment = self.filter.assess(cluster("sunscreen"), [])
        self.assertTrue(assessment.allowed_for_scoring)

    def test_youtube_review_can_surface_unknown_emerging_brand(self) -> None:
        trend = cluster("Glowforge Mini")
        trend.observations[0] = trend.observations[0].model_copy(
            update={
                "platform": "youtube",
                "source": "youtube",
                "title": "Glowforge Mini Review",
                "commercial_intent": 0.6,
            }
        )
        trend.platforms = ["youtube"]

        assessment = self.filter.assess(trend, [])

        self.assertTrue(assessment.allowed_for_scoring)


if __name__ == "__main__":
    unittest.main()
