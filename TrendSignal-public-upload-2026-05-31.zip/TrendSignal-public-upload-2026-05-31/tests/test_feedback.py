from __future__ import annotations

import csv
import tempfile
import unittest
from datetime import date
from pathlib import Path

from core.commercial_filter import CommercialFilter
from core.feedback import TrendFeedbackStore
from main import _apply_positive_feedback
from models import TrendCluster, TrendObservation, TrendType


def cluster(term: str) -> TrendCluster:
    return TrendCluster(
        cluster_id="test",
        canonical_term=term,
        terms=[term],
        observations=[
            TrendObservation(term=term, platform="google_trends", date=date.today())
        ],
        attention_velocity=0.5,
        platforms=["google_trends"],
    )


class TrendFeedbackStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.path = Path(self.temp_dir.name) / "trend_feedback.csv"
        with self.path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=TrendFeedbackStore.COLUMNS)
            writer.writeheader()
            writer.writerow(
                {"date": "2026-05-30", "term": "oura ring 5", "label": "valuable", "notes": ""}
            )
            writer.writerow(
                {"date": "2026-05-30", "term": "flood watch", "label": "reject", "notes": ""}
            )

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_exact_positive_feedback_boosts_score(self) -> None:
        feedback = TrendFeedbackStore(self.path).assess("oura ring 5")
        self.assertEqual("valuable", feedback.exact_label)
        self.assertEqual(12.0, feedback.score_adjustment)

    def test_exact_reject_blocks_term(self) -> None:
        feedback = TrendFeedbackStore(self.path).assess("flood watch")
        self.assertTrue(feedback.should_reject)

    def test_similar_positive_feedback_adds_cautious_boost(self) -> None:
        feedback = TrendFeedbackStore(self.path).assess("oura ring gen 5")
        self.assertEqual("valuable", feedback.similar_label)
        self.assertGreater(feedback.score_adjustment, 0)
        self.assertLess(feedback.score_adjustment, 12.0)

    def test_positive_feedback_promotes_unclear_item_for_review(self) -> None:
        store = TrendFeedbackStore(self.path)
        feedback = store.assess("oura ring 5")
        assessment = CommercialFilter().assess(cluster("glow wand"), [])
        promoted = _apply_positive_feedback(assessment, feedback)
        self.assertTrue(promoted.allowed_for_scoring)
        self.assertEqual(TrendType.PRODUCT, promoted.trend_type)

    def test_positive_feedback_does_not_override_hard_reject(self) -> None:
        store = TrendFeedbackStore(self.path)
        feedback = store.assess("oura ring 5")
        assessment = CommercialFilter().assess(cluster("flood watch"), [])
        promoted = _apply_positive_feedback(assessment, feedback)
        self.assertFalse(promoted.allowed_for_scoring)


if __name__ == "__main__":
    unittest.main()
