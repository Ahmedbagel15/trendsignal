from __future__ import annotations

import tempfile
import unittest
from datetime import date
from pathlib import Path

import pandas as pd

from core.discovery_ledger import DiscoveryLedger
from core.trend_clusterer import TrendClusterer
from models import TrendObservation


class DiscoveryLedgerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.ledger = DiscoveryLedger(root / "processed", root / "reports")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_raw_ledger_preserves_distinct_source_rows(self) -> None:
        observations = [
            TrendObservation(
                term="fairlife coffee",
                raw_term="Fairlife coffee",
                platform="google_trends",
                source="google_trends",
                date=date.today(),
                url="https://example.com/search",
            ),
            TrendObservation(
                term="fairlife coffee",
                raw_term="Fairlife coffee review",
                platform="youtube",
                source="youtube",
                date=date.today(),
                url="https://example.com/video",
            ),
        ]

        path = self.ledger.write_raw(observations)
        frame = pd.read_csv(path, keep_default_na=False)

        self.assertEqual(2, len(frame))
        self.assertEqual({"google_trends", "youtube"}, set(frame["source"]))
        self.assertTrue(all(frame["observation_id"]))

    def test_high_scoring_singleton_is_preserved_as_orphan(self) -> None:
        observation = TrendObservation(
            term="fairlife coffee",
            raw_term="Fairlife coffee",
            platform="google_trends",
            source="google_trends",
            date=date.today(),
            mentions=50000,
        )
        _, assignments = TrendClusterer().cluster_with_assignments([observation])

        path = self.ledger.write_orphans([observation], assignments)
        frame = pd.read_csv(path, keep_default_na=False)

        self.assertEqual(["Fairlife coffee"], frame["raw_term"].tolist())


if __name__ == "__main__":
    unittest.main()
