#!/bin/zsh
cd "$(dirname "$0")"
if curl --silent --fail http://127.0.0.1:8765/api/status >/dev/null 2>&1; then
  open http://127.0.0.1:8765
  exit 0
fi

source .venv/bin/activate
nohup python dashboard.py --no-browser > data/reports/dashboard.log 2>&1 &
echo $! > .trendsignal-dashboard.pid
sleep 1
open http://127.0.0.1:8765
