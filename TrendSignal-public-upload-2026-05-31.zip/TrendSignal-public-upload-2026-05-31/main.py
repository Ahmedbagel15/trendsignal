from __future__ import annotations

import argparse
import logging
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timezone
from pathlib import Path
from uuid import uuid4

try:
    import yaml
except ImportError:
    yaml = None

from connectors.company_discovery import CompanyDiscoveryConnector
from connectors.finance import FinanceConnector
from connectors.best_buy import BestBuyConnector
from connectors.ebay import EbayConnector
from connectors.etsy import EtsyConnector
from connectors.google_ads_keywords import GoogleAdsKeywordsConnector
from connectors.google_trends import GoogleTrendsConnector
from connectors.reddit import RedditConnector
from connectors.social_exports import SocialExportsConnector
from connectors.youtube import YouTubeConnector
from core.commercial_filter import CommercialFilter
from core.company_mapper import CompanyMapper
from core.discovery_archive import DiscoveryArchive
from core.discovery_ledger import ClusterContext, DiscoveryLedger
from core.entity_mapper import EntityMapper
from core.feedback import FeedbackAssessment, TrendFeedbackStore
from core.llm_assistant import OpenAICompatibleAssistant
from core.report_generator import ReportGenerator
from core.review_queue import ReviewQueue
from core.signal_aggregator import AggregatedSignal, SignalAggregator
from core.signal_scorer import SignalScorer
from core.trend_clusterer import TrendClusterer
from models import CommercialAssessment, Signal, TrendCluster, TrendObservation, TrendType


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s - %(message)s",
)
LOGGER = logging.getLogger("trendsignal")
ROOT = Path(__file__).parent


def main() -> None:
    parser = argparse.ArgumentParser(description="TrendSignal consumer-trend research screener")
    parser.add_argument(
        "mode",
        choices=["discover", "validate"],
        nargs="?",
        default="discover",
        help="discover writes the manual review queue; validate checks only approved queue rows",
    )
    args = parser.parse_args()
    _load_dotenv(ROOT / ".env")
    config = _load_yaml(ROOT / "config.yaml")
    sources_config = _load_yaml(ROOT / "config" / "sources.yaml")
    if args.mode == "validate":
        _run_validation(config, sources_config)
        return

    terms = _configured_terms(config)
    collection_run_id = f"{date.today().isoformat()}-{uuid4().hex[:10]}"
    observations, source_errors = _collect_observations(config, sources_config, terms)
    observations = _stamp_observations(observations, collection_run_id)
    run_date = date.today()
    errors_path = _write_source_errors(run_date, source_errors, ROOT / config["paths"]["reports_dir"])
    LOGGER.info("Wrote source error report: %s", errors_path)
    if not observations:
        LOGGER.error("Discovery stopped: all enabled sources failed or returned no observations.")
        return
    ledger = DiscoveryLedger(
        ROOT / config["paths"]["processed_dir"],
        ROOT / config["paths"]["reports_dir"],
    )
    raw_path = ledger.write_raw(observations)
    LOGGER.info("Wrote raw discovery ledger: %s", raw_path)
    archive = DiscoveryArchive(
        ROOT / config["paths"]["discovery_archive_path"],
        window_days=int(config["run"].get("discovery_window_days", 30)),
    )
    archive.append(observations)
    clusters, assignments = TrendClusterer().cluster_with_assignments(observations)
    LOGGER.info("Built %s trend clusters from %s observations.", len(clusters), len(observations))

    entity_mapper = EntityMapper()
    discovery = CompanyDiscoveryConnector(ROOT / "config" / "brand_to_ticker.yaml")
    company_mapper = CompanyMapper(discovery)
    aggregator = SignalAggregator()
    commercial_filter = CommercialFilter()
    feedback_config = config.get("feedback", {})
    feedback_store = TrendFeedbackStore(
        ROOT / config["paths"]["feedback_path"],
        similarity_threshold=float(feedback_config.get("similarity_threshold", 0.72)),
        negative_similarity_threshold=float(feedback_config.get("negative_similarity_threshold", 0.90)),
    )
    LOGGER.info("Loaded %s user feedback labels.", len(feedback_store.rows))
    review_queue = ReviewQueue(ROOT / config["paths"]["validation_queue_path"])
    _archive_saved_queue_rows(review_queue, config)

    queue_rows: list[dict[str, object]] = []
    audit_rows: list[dict[str, object]] = []
    cluster_contexts: list[ClusterContext] = []
    for cluster in clusters:
        feedback = feedback_store.assess(cluster.canonical_term)
        aggregate = aggregator.aggregate(cluster)
        entities = entity_mapper.extract_entities(cluster.canonical_term, cluster.terms)
        commercial = commercial_filter.assess(cluster, entities)
        commercial = _apply_positive_feedback(commercial, feedback)
        exposures = company_mapper.map_cluster(cluster, entities)
        status = _investable_status(exposures)
        materiality = max((exposure.revenue_relevance for exposure in exposures), default=0.0)
        cluster_contexts.append(
            ClusterContext(
                cluster=cluster,
                aggregate=aggregate,
                commercial=commercial,
                exposures=exposures,
                investable_status=status,
                revenue_materiality_score=materiality,
            )
        )
        if feedback.should_reject:
            LOGGER.info("Filtered by prior feedback: %s (%s)", cluster.canonical_term, feedback.exact_label)
            audit_rows.append(
                _audit_row(
                    cluster=cluster,
                    commercial=commercial,
                    entities=entities,
                    status="feedback_rejected",
                    reason=feedback.reason,
                    feedback=feedback,
                    aggregate=aggregate,
                )
            )
            continue
        if not commercial.allowed_for_scoring:
            LOGGER.info("Filtered low-commercial trend: %s (%s)", cluster.canonical_term, commercial.trend_type)
            audit_rows.append(
                _audit_row(
                    cluster=cluster,
                    commercial=commercial,
                    entities=entities,
                    status="rejected",
                    reason=commercial.rationale,
                    feedback=feedback,
                    aggregate=aggregate,
                )
            )
            continue

        has_clean_mapping = any(exposure.confidence.value in {"direct", "probable"} for exposure in exposures)
        if not aggregator.should_queue(aggregate, has_clean_mapping, commercial.commercial_intent):
            audit_rows.append(
                _audit_row(
                    cluster=cluster,
                    commercial=commercial,
                    entities=entities,
                    status="below_discovery_threshold",
                    reason="Commercial candidate did not meet breakout, cross-platform, search-demand, or clean-mapping thresholds.",
                    mapped_tickers=[exposure.ticker for exposure in exposures],
                    feedback=feedback,
                    aggregate=aggregate,
                )
            )
            continue
        queue_rows.append(ReviewQueue.row(run_date, cluster, commercial, entities, aggregate, exposures))
        audit_rows.append(
            _audit_row(
                cluster=cluster,
                commercial=commercial,
                entities=entities,
                status="pending_validation",
                reason="Commercial product candidate queued for your manual review before API validation.",
                mapped_tickers=[exposure.ticker for exposure in exposures],
                feedback=feedback,
                aggregate=aggregate,
            )
        )

    review_queue.refresh_run(queue_rows, run_date)
    LOGGER.info("Wrote %s product candidates to manual validation queue: %s", len(queue_rows), review_queue.path)
    clustered_path = ledger.write_clusters(cluster_contexts)
    members_path = ledger.write_members(assignments)
    orphans_path = ledger.write_orphans(observations, assignments)
    hidden_path = ledger.write_hidden_signal_report(run_date, cluster_contexts)
    LOGGER.info("Wrote clustered discovery view: %s", clustered_path)
    LOGGER.info("Wrote cluster membership table: %s", members_path)
    LOGGER.info("Wrote orphan signal view: %s", orphans_path)
    LOGGER.info("Wrote hidden signal report: %s", hidden_path)

    report_generator = ReportGenerator(ROOT / config["paths"]["reports_dir"])
    audit_markdown_path, audit_csv_path = report_generator.write_audit(
        run_date,
        observations,
        audit_rows,
        [],
        today_top_searches=archive.today_top(run_date, limit=int(config["run"].get("top_search_limit", 10))),
        rolling_top_searches=archive.rolling_top(run_date, limit=int(config["run"].get("top_search_limit", 10))),
    )
    LOGGER.info("Wrote discovery audit: %s", audit_markdown_path)
    LOGGER.info("Wrote discovery audit CSV: %s", audit_csv_path)
    youtube_csv_path = report_generator.write_youtube_discoveries(run_date, audit_rows)
    LOGGER.info("Wrote YouTube discovery CSV: %s", youtube_csv_path)

    LOGGER.info("Discovery complete. Mark queue rows as approve, then run: python main.py validate")


def _run_validation(config: dict, sources_config: dict | None = None) -> None:
    run_date = date.today()
    review_queue = ReviewQueue(ROOT / config["paths"]["validation_queue_path"])
    _archive_saved_queue_rows(review_queue, config)
    approved_rows = review_queue.approved()
    if not approved_rows:
        LOGGER.warning("No approved validation queue rows found. Mark decision=approve before running validation.")
        return

    youtube = _youtube_connector(config)
    if not youtube.enabled:
        LOGGER.error("Validation requires YOUTUBE_API_KEY in .env. No API requests were sent.")
        return

    archive = DiscoveryArchive(
        ROOT / config["paths"]["discovery_archive_path"],
        window_days=int(config["run"].get("discovery_window_days", 30)),
    )
    discovery = CompanyDiscoveryConnector(ROOT / "config" / "brand_to_ticker.yaml")
    company_mapper = CompanyMapper(discovery)
    finance = FinanceConnector(use_live=config["run"].get("use_live_finance", True))
    llm_assistant = OpenAICompatibleAssistant(enabled=config["run"].get("llm_enabled", False))
    scorer = SignalScorer(config["scoring"]["weights"], llm_assistant=llm_assistant)
    feedback_config = config.get("feedback", {})
    feedback_store = TrendFeedbackStore(
        ROOT / config["paths"]["feedback_path"],
        similarity_threshold=float(feedback_config.get("similarity_threshold", 0.72)),
        negative_similarity_threshold=float(feedback_config.get("negative_similarity_threshold", 0.90)),
    )
    approved_terms = [str(row["canonical_term"]) for row in approved_rows]
    optional_validation = _optional_validation_observations(approved_terms, sources_config or {})

    signals: list[Signal] = []
    audit_rows: list[dict[str, object]] = []
    observations: list[TrendObservation] = []
    for row in approved_rows:
        cluster = _queue_cluster(row, run_date)
        matching_optional = [
            observation
            for observation in optional_validation
            if observation.normalized_term == cluster.canonical_term.casefold()
        ]
        if matching_optional:
            cluster = cluster.model_copy(
                update={
                    "observations": [*cluster.observations, *matching_optional],
                    "platforms": sorted({*cluster.platforms, *(observation.platform for observation in matching_optional)}),
                }
            )
        observations.extend(cluster.observations)
        feedback = feedback_store.assess(cluster.canonical_term)
        entities = [item.strip() for item in str(row.get("candidate_company") or "").split(",") if item.strip()]
        commercial = CommercialAssessment(
            trend_type=TrendType(str(row.get("trend_type") or TrendType.PRODUCT.value)),
            commercial_intent=_float_value(row.get("commercial_intent_score"), 0.65),
            purchase_intent=_float_value(row.get("commercial_intent_score"), 0.65),
            rationale="Manually approved from the discovery validation queue.",
            allowed_for_scoring=True,
        )
        youtube_observation = _youtube_observation(youtube, cluster.canonical_term)
        if youtube_observation is not None:
            cluster = cluster.model_copy(
                update={
                    "observations": [*cluster.observations, youtube_observation],
                    "platforms": sorted({*cluster.platforms, youtube_observation.platform}),
                    "attention_velocity": max(cluster.attention_velocity, _bounded_growth(youtube_observation.growth_rate)),
                }
            )
            observations.append(youtube_observation)
            archive.append([youtube_observation])

        exposures = company_mapper.map_cluster(cluster, entities)
        if not exposures:
            audit_rows.append(
                _audit_row(
                    cluster=cluster,
                    commercial=commercial,
                    entities=entities,
                    status="validated_product_discovery",
                    reason="Validated product candidate, but no public-company mapping was found.",
                    feedback=feedback,
                )
            )
            continue

        tickers = {exposure.ticker for exposure in exposures}
        finance_snapshots = {ticker: finance.fetch_snapshot(ticker) for ticker in tickers}
        scored_signals = scorer.score(
            run_date,
            cluster,
            commercial,
            exposures,
            finance_snapshots,
            feedback_adjustment=feedback.score_adjustment,
            feedback_reason=feedback.reason,
        )
        signals.extend(scored_signals)
        audit_rows.append(
            _audit_row(
                cluster=cluster,
                commercial=commercial,
                entities=entities,
                status="validated_candidate",
                reason="Manually approved, API validated, and mapped to public-company exposure.",
                mapped_tickers=[signal.primary_ticker for signal in scored_signals],
                best_score=max((signal.signal_score for signal in scored_signals), default=0),
                feedback=feedback,
            )
        )

    min_score = float(config["run"].get("min_signal_score", 35))
    max_signals = int(config["run"].get("max_signals", 25))
    ranked = sorted(
        (signal for signal in signals if signal.signal_score >= min_score),
        key=lambda item: item.signal_score,
        reverse=True,
    )[:max_signals]
    for index, signal in enumerate(ranked, start=1):
        signal.rank = index

    report_generator = ReportGenerator(ROOT / config["paths"]["reports_dir"])
    audit_markdown_path, audit_csv_path = report_generator.write_audit(
        run_date,
        observations,
        audit_rows,
        ranked,
        audit_name="validation",
    )
    LOGGER.info("Wrote validation audit: %s", audit_markdown_path)
    LOGGER.info("Wrote validation audit CSV: %s", audit_csv_path)
    if not ranked:
        LOGGER.warning("No validated stock signals passed the score threshold. The validated product audit was still written.")
        return
    markdown_path, csv_path = report_generator.write(ranked)
    LOGGER.info("Wrote Markdown report: %s", markdown_path)
    LOGGER.info("Wrote CSV report: %s", csv_path)


def _youtube_connector(config: dict, sources_config: dict | None = None) -> YouTubeConnector:
    youtube_config = config["connectors"].get("youtube", {})
    source_config = (sources_config or {}).get("youtube", {})
    query_config = _load_yaml(ROOT / "config" / "youtube_queries.yaml")
    return YouTubeConnector(
        recent_days=int(source_config.get("published_after_days", youtube_config.get("recent_days", 7))),
        baseline_days=int(youtube_config.get("baseline_days", 30)),
        max_results=int(source_config.get("max_results_per_query", youtube_config.get("max_results", 25))),
        max_terms_per_run=int(youtube_config.get("max_terms_per_run", 10)),
        region_code=youtube_config.get("region_code", "US"),
        relevance_language=youtube_config.get("relevance_language", "en"),
        query_groups=query_config.get("product_discovery", []),
        query_templates=query_config.get("query_templates", ["{query}"]),
        max_queries_per_run=int(source_config.get("max_queries_per_run", 40)),
        cache_dir=ROOT / "data" / "processed" / "cache" / "youtube",
        cache_ttl_hours=int(source_config.get("cache_ttl_hours", 24)),
    )


def _archive_saved_queue_rows(review_queue: ReviewQueue, config: dict) -> None:
    saved_count = review_queue.archive_saved(
        ROOT / config["paths"]["useful_discoveries_path"],
        ROOT / config["paths"]["feedback_path"],
    )
    if saved_count:
        LOGGER.info("Archived %s useful non-validation discoveries.", saved_count)


def _queue_cluster(row: dict[str, object], run_date: date) -> TrendCluster:
    term = str(row["canonical_term"])
    observation = TrendObservation(
        term=term,
        platform=str(row.get("strongest_source") or "manual_validation_queue"),
        date=run_date,
        mentions=_float_value(row.get("strongest_source_score"), 0.0),
        growth_rate=_float_value(row.get("cross_platform_score"), 0.0),
        metadata={"discovery_source": "manual_validation_queue"},
    )
    return TrendCluster(
        cluster_id=str(row.get("cluster_id") or f"queue-{term.casefold()}"),
        canonical_term=term,
        terms=[term],
        observations=[observation],
        attention_velocity=_float_value(row.get("cross_platform_score"), 0.0),
        platforms=[item for item in str(row.get("sources_present") or "").split(",") if item]
        or ["manual_validation_queue"],
    )


def _float_value(value: object, default: float) -> float:
    try:
        parsed = float(value)
        return default if parsed != parsed else parsed
    except (TypeError, ValueError):
        return default


def _stamp_observations(observations: list[TrendObservation], collection_run_id: str) -> list[TrendObservation]:
    stamped: list[TrendObservation] = []
    for observation in observations:
        stamped.append(
            observation.model_copy(
                update={
                    "collection_run_id": observation.collection_run_id or collection_run_id,
                    "raw_term": observation.raw_term or observation.term,
                    "normalized_term": observation.normalized_term or observation.term.casefold(),
                    "search_volume": observation.search_volume or observation.mentions,
                }
            )
        )
    return stamped


def _investable_status(exposures: list[object]) -> str:
    if not exposures:
        return "needs_mapping"
    return "public_direct" if exposures[0].relationship == "direct" else "public_indirect"


def _investable_status_from_tickers(tickers: list[str]) -> str:
    return "public_indirect" if tickers else "needs_mapping"


def _collect_observations(
    config: dict,
    sources_config: dict,
    terms: list[str],
) -> tuple[list[TrendObservation], list[dict[str, str]]]:
    observations: list[TrendObservation] = []
    errors: list[dict[str, str]] = []
    jobs: dict[str, object] = {}

    social_config = sources_config.get("social_exports", {})
    if social_config.get("enabled", True):
        input_dir = ROOT / str(social_config.get("input_dir", config["paths"]["social_exports_dir"]))
        _collect_source("social_exports", SocialExportsConnector(input_dir), observations, errors)

    google_source = sources_config.get("google_trends", {})
    if google_source.get("enabled", True):
        google_config = config["connectors"]["google_trends"]
        jobs["google_trends"] = GoogleTrendsConnector(
            terms=terms,
            timeframe=google_config["timeframe"],
            geo=google_config["geo"],
            recent_days=int(google_config.get("recent_days", 7)),
            baseline_days=int(google_config.get("baseline_days", 30)),
            batch_size=int(google_config.get("batch_size", 1)),
            request_delay_seconds=float(google_config.get("request_delay_seconds", 20)),
            max_attempts=int(google_config.get("max_attempts", 3)),
            backoff_seconds=float(google_config.get("backoff_seconds", 120)),
            discover_trending_searches=bool(google_config.get("discover_trending_searches", True)),
            trending_geo=google_config.get("trending_geo", "united_states"),
            realtime_geo=google_config.get("realtime_geo", "US"),
            max_discovered_terms=int(google_source.get("max_discovered_terms", 250)),
            comprehensive_hours=int(google_config.get("comprehensive_hours", 168)),
            use_comprehensive_export=bool(google_config.get("use_comprehensive_export", True)),
            allow_shallow_discovery_fallback=bool(google_config.get("allow_shallow_discovery_fallback", False)),
        )

    youtube_source = sources_config.get("youtube", {})
    if youtube_source.get("enabled", True):
        youtube = _youtube_connector(config, sources_config)
        if youtube.enabled:
            jobs["youtube"] = youtube
        else:
            errors.append({"source": "youtube", "error": "Skipped: YOUTUBE_API_KEY is not configured."})

    reddit_source = sources_config.get("reddit", {})
    if reddit_source.get("enabled", True):
        reddit = RedditConnector(
            terms=terms,
            subreddits=config["connectors"]["reddit"]["subreddits"],
            recent_days=int(config["connectors"]["reddit"].get("recent_days", 3)),
            baseline_days=int(config["connectors"]["reddit"].get("baseline_days", 21)),
            limit_per_query=int(config["connectors"]["reddit"].get("limit_per_query", 100)),
        )
        if reddit.client_id and reddit.client_secret:
            jobs["reddit"] = reddit
        else:
            errors.append({"source": "reddit", "error": "Skipped: Reddit credentials are not configured."})

    etsy_source = sources_config.get("etsy", {})
    if etsy_source.get("enabled", False):
        etsy = EtsyConnector(max_results=int(etsy_source.get("max_results_per_run", 100)))
        if etsy.enabled:
            jobs["etsy"] = etsy
        else:
            errors.append({"source": "etsy", "error": "Skipped: Etsy keystring and shared secret are not configured."})

    best_buy_source = sources_config.get("best_buy", {})
    if best_buy_source.get("enabled", False):
        best_buy = BestBuyConnector(max_results=int(best_buy_source.get("max_results_per_feed", 50)))
        if best_buy.enabled:
            jobs["best_buy"] = best_buy
        else:
            errors.append({"source": "best_buy", "error": "Skipped: BEST_BUY_API_KEY is not configured."})

    ebay_source = sources_config.get("ebay", {})
    if ebay_source.get("enabled", False):
        ebay = EbayConnector(terms=terms, max_results_per_term=int(ebay_source.get("max_results_per_term", 25)))
        if ebay.enabled:
            jobs["ebay"] = ebay
        else:
            errors.append({"source": "ebay", "error": "Skipped: eBay credentials are not configured."})

    google_ads_source = sources_config.get("google_ads_keywords", {})
    if google_ads_source.get("enabled", False):
        google_ads = GoogleAdsKeywordsConnector()
        if google_ads.enabled:
            jobs["google_ads_keywords"] = google_ads
        else:
            errors.append({"source": "google_ads_keywords", "error": "Skipped: Google Ads credentials are not configured."})

    if jobs:
        with ThreadPoolExecutor(max_workers=len(jobs)) as executor:
            futures = {executor.submit(connector.fetch): source for source, connector in jobs.items()}
            for future in as_completed(futures):
                source = futures[future]
                try:
                    fetched = future.result()
                    LOGGER.info("%s returned %s observations.", source, len(fetched))
                    observations.extend(fetched)
                except Exception as exc:
                    LOGGER.exception("%s failed; continuing pipeline.", source)
                    errors.append({"source": source, "error": str(exc)})
    return observations, errors


def _optional_validation_observations(terms: list[str], sources_config: dict) -> list[TrendObservation]:
    observations: list[TrendObservation] = []
    ebay_config = sources_config.get("ebay", {})
    if ebay_config.get("enabled", False):
        ebay = EbayConnector(terms=terms, max_results_per_term=int(ebay_config.get("max_results_per_term", 25)))
        if ebay.enabled:
            try:
                observations.extend(ebay.fetch())
            except Exception:
                LOGGER.exception("eBay marketplace validation failed; continuing without eBay evidence.")
    ads_config = sources_config.get("google_ads_keywords", {})
    if ads_config.get("enabled", False):
        google_ads = GoogleAdsKeywordsConnector()
        if google_ads.enabled:
            try:
                observations.extend(google_ads.validate_terms(terms))
            except Exception:
                LOGGER.exception("Google Ads keyword validation failed; continuing without keyword evidence.")
    return observations


def _collect_source(
    source: str,
    connector: object,
    observations: list[TrendObservation],
    errors: list[dict[str, str]],
) -> None:
    try:
        fetched = connector.fetch()
        LOGGER.info("%s returned %s observations.", source, len(fetched))
        observations.extend(fetched)
    except Exception as exc:
        LOGGER.exception("%s failed; continuing pipeline.", source)
        errors.append({"source": source, "error": str(exc)})


def _configured_terms(config: dict) -> list[str]:
    google_config = config["connectors"]["google_trends"]
    if google_config.get("discover_trending_searches", True):
        return []
    tracked_terms = _load_yaml(ROOT / "config" / "tracked_terms.yaml")
    return tracked_terms["consumer_terms"]


def _write_source_errors(run_date: date, errors: list[dict[str, str]], reports_dir: Path) -> Path:
    reports_dir.mkdir(parents=True, exist_ok=True)
    path = reports_dir / f"{run_date.isoformat()}_source_errors.md"
    lines = [f"# TrendSignal Source Errors - {run_date.isoformat()}", ""]
    if not errors:
        lines.append("No connector-level errors.")
    else:
        for row in errors:
            lines.extend([f"## {row['source']}", "", row["error"], ""])
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _youtube_observation(youtube: YouTubeConnector, term: str) -> TrendObservation | None:
    try:
        return youtube.fetch_for_term(term)
    except Exception:
        LOGGER.exception("YouTube validation failed for %s; continuing pipeline.", term)
        return None


def _bounded_growth(value: float | None) -> float:
    if value is None:
        return 0.0
    return max(0.0, min(1.0, value))


def _audit_row(
    cluster: object,
    commercial: object,
    entities: list[str],
    status: str,
    reason: str,
    mapped_tickers: list[str] | None = None,
    best_score: float | None = None,
    feedback: FeedbackAssessment | None = None,
    aggregate: AggregatedSignal | None = None,
) -> dict[str, object]:
    feedback = feedback or FeedbackAssessment()
    return {
        "date": date.today().isoformat(),
        "collection_run_id": cluster.observations[0].collection_run_id if cluster.observations else "",
        "cluster_id": cluster.cluster_id,
        "trend": cluster.canonical_term,
        "status": status,
        "reason": reason,
        "platforms": ",".join(cluster.platforms),
        "attention_velocity": round(cluster.attention_velocity, 3),
        "trend_type": commercial.trend_type.value,
        "commercial_intent": commercial.commercial_intent,
        "search_volume": max((observation.mentions for observation in cluster.observations), default=0),
        "entities": ",".join(entities),
        "mapped_tickers": ",".join(mapped_tickers or []),
        "best_score": best_score if best_score is not None else "",
        "feedback_label": feedback.display_label,
        "feedback_similar_term": feedback.similar_term,
        "feedback_similarity": round(feedback.similarity, 3),
        "feedback_adjustment": feedback.score_adjustment,
        "feedback_reason": feedback.reason,
        "source_origin": aggregate.earliest_seen_source if aggregate else "",
        "sources_present": ",".join(aggregate.sources_present) if aggregate else ",".join(cluster.platforms),
        "strongest_source": aggregate.strongest_source if aggregate else "",
        "strongest_source_score": aggregate.strongest_source_score if aggregate else "",
        "cross_platform_score": aggregate.cross_platform_score if aggregate else "",
        "single_platform_breakout_score": aggregate.single_platform_breakout_score if aggregate else "",
        "youtube_top_video_title": aggregate.youtube_top_video_title if aggregate else "",
        "youtube_top_video_url": aggregate.youtube_top_video_url if aggregate else "",
        "social_export_source_file": aggregate.social_export_source_file if aggregate else "",
        "google_search_volume": aggregate.google_search_volume if aggregate else "",
        "reddit_mentions": aggregate.reddit_mentions if aggregate else "",
        "raw_observation_count": len(cluster.observations),
        "evidence_urls": ",".join(aggregate.evidence_urls) if aggregate else "",
        "investable_status": _investable_status_from_tickers(mapped_tickers or []),
    }


def _apply_positive_feedback(commercial: object, feedback: FeedbackAssessment) -> object:
    if not feedback.has_exact_positive_label:
        return commercial
    if commercial.allowed_for_scoring:
        return commercial.model_copy(
            update={
                "commercial_intent": max(commercial.commercial_intent, 0.65),
                "purchase_intent": max(commercial.purchase_intent, 0.65),
                "rationale": f"{commercial.rationale} Prior positive user feedback reinforced this item.",
            }
        )
    if commercial.rationale.startswith("Rejected "):
        return commercial
    return commercial.model_copy(
        update={
            "trend_type": TrendType.PRODUCT,
            "commercial_intent": max(commercial.commercial_intent, 0.65),
            "purchase_intent": max(commercial.purchase_intent, 0.65),
            "allowed_for_scoring": True,
            "rationale": f"{commercial.rationale} Prior positive user feedback promoted this item for review.",
        }
    )


def _load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        if yaml is not None:
            return yaml.safe_load(handle) or {}
        return json.load(handle)


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


if __name__ == "__main__":
    main()
