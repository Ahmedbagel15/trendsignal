from __future__ import annotations

import hashlib
import logging
import re
from collections import defaultdict
from difflib import SequenceMatcher

import numpy as np

try:
    from rapidfuzz import fuzz
except ImportError:
    fuzz = None

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
except ImportError:
    TfidfVectorizer = None
    cosine_similarity = None

from models import ClusterAssignment, TrendCluster, TrendObservation

LOGGER = logging.getLogger(__name__)


ALIASES = {
    "proffee": "protein coffee",
    "high protein latte": "protein coffee",
    "hoka shoes": "Hoka shoes",
    "on running shoes": "On running shoes",
}
GENERIC_PRODUCT_TOKENS = {
    "a",
    "an",
    "and",
    "are",
    "at",
    "best",
    "budget",
    "by",
    "shoe",
    "shoes",
    "cup",
    "coffee",
    "latte",
    "gummies",
    "paddle",
    "vest",
    "mask",
    "bowl",
    "full",
    "for",
    "from",
    "in",
    "is",
    "it",
    "new",
    "of",
    "on",
    "or",
    "review",
    "setup",
    "the",
    "to",
    "unboxing",
    "viral",
    "with",
    "worth",
}


class TrendClusterer:
    def __init__(self, similarity_threshold: float = 0.52) -> None:
        self.similarity_threshold = similarity_threshold

    def cluster(self, observations: list[TrendObservation]) -> list[TrendCluster]:
        clusters, _ = self.cluster_with_assignments(observations)
        return clusters

    def cluster_with_assignments(
        self,
        observations: list[TrendObservation],
    ) -> tuple[list[TrendCluster], list[ClusterAssignment]]:
        grouped: dict[str, list[TrendObservation]] = defaultdict(list)
        for observation in observations:
            normalized = observation.normalized_term or observation.term
            grouped[ALIASES.get(normalized.lower(), normalized)].append(observation)

        canonical_terms = list(grouped.keys())
        if not canonical_terms:
            return [], []

        similarity = self._similarity_matrix(canonical_terms)
        visited: set[int] = set()
        clusters: list[TrendCluster] = []
        assignments: list[ClusterAssignment] = []

        for index, term in enumerate(canonical_terms):
            if index in visited:
                continue
            neighbors = {
                other_index
                for other_index, other_term in enumerate(canonical_terms)
                if other_index == index
                or _can_merge(
                    term,
                    other_term,
                    similarity[index, other_index],
                    self.similarity_threshold,
                )
            }
            visited.update(neighbors)
            terms = [canonical_terms[item] for item in sorted(neighbors)]
            cluster_observations = [obs for cluster_term in terms for obs in grouped[cluster_term]]
            canonical = self._choose_canonical(terms, cluster_observations)
            cluster_id = _cluster_id(canonical)
            strongest = max(cluster_observations, key=_observation_strength)
            clusters.append(
                TrendCluster(
                    cluster_id=cluster_id,
                    canonical_term=canonical,
                    terms=sorted(set([obs.term for obs in cluster_observations] + terms)),
                    observations=cluster_observations,
                    attention_velocity=self._attention_velocity(cluster_observations),
                    platforms=sorted({obs.platform for obs in cluster_observations}),
                    novelty=self._novelty(cluster_observations),
                    member_observation_ids=[obs.observation_id for obs in cluster_observations],
                    evidence_urls=sorted({obs.url for obs in cluster_observations if obs.url}),
                    evidence_sources=sorted({obs.source or obs.platform for obs in cluster_observations}),
                    earliest_seen_at=min(obs.observed_at for obs in cluster_observations),
                    earliest_seen_source=min(cluster_observations, key=lambda obs: obs.observed_at).source
                    or min(cluster_observations, key=lambda obs: obs.observed_at).platform,
                    strongest_source=strongest.source or strongest.platform,
                    strongest_source_observation_id=strongest.observation_id,
                )
            )
            for observation in cluster_observations:
                confidence, reason = _assignment_detail(observation, canonical, len(cluster_observations))
                assignments.append(
                    ClusterAssignment(
                        raw_observation_id=observation.observation_id,
                        cluster_id=cluster_id,
                        canonical_term=canonical,
                        raw_term=observation.raw_term or observation.term,
                        source=observation.source or observation.platform,
                        assignment_confidence=confidence,
                        assignment_reason=reason,
                    )
                )
        return sorted(clusters, key=lambda cluster: cluster.attention_velocity, reverse=True), assignments

    @staticmethod
    def _similarity_matrix(terms: list[str]) -> np.ndarray:
        if TfidfVectorizer is not None and cosine_similarity is not None:
            try:
                vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words="english")
                vectors = vectorizer.fit_transform(terms)
                return cosine_similarity(vectors)
            except ValueError:
                LOGGER.warning("TF-IDF clustering had no usable vocabulary; using token fallback.")
        size = len(terms)
        matrix = np.eye(size)
        for left in range(size):
            for right in range(size):
                if left == right:
                    continue
                left_tokens = _meaningful_tokens(terms[left])
                right_tokens = _meaningful_tokens(terms[right])
                overlap = len(left_tokens & right_tokens)
                if overlap == 0:
                    matrix[left, right] = 0.0
                    continue
                token_score = overlap / max(len(left_tokens), len(right_tokens))
                sequence_score = SequenceMatcher(None, terms[left].lower(), terms[right].lower()).ratio()
                matrix[left, right] = max(token_score, sequence_score * token_score)
        return matrix

    @staticmethod
    def _choose_canonical(terms: list[str], observations: list[TrendObservation]) -> str:
        scores = defaultdict(float)
        for observation in observations:
            scores[observation.term] += observation.mentions + observation.engagement * 0.01
        if scores:
            return max(scores.items(), key=lambda item: item[1])[0]
        return sorted(terms, key=len)[0]

    @staticmethod
    def _attention_velocity(observations: list[TrendObservation]) -> float:
        growth_values = [obs.growth_rate for obs in observations if obs.growth_rate is not None]
        if not growth_values:
            return 0.0
        raw = float(np.mean(growth_values))
        return max(0.0, min(1.0, raw))

    @staticmethod
    def _novelty(observations: list[TrendObservation]) -> float:
        total_mentions = sum(obs.mentions for obs in observations)
        if total_mentions > 200_000:
            return 0.15
        if total_mentions > 50_000:
            return 0.35
        if total_mentions > 10_000:
            return 0.65
        return 0.85


def _cluster_id(value: str) -> str:
    return hashlib.sha1(value.lower().encode("utf-8")).hexdigest()[:10]


def _token_set_ratio(left: str, right: str) -> float:
    if fuzz is not None:
        return float(fuzz.token_set_ratio(left, right))
    left_tokens = _meaningful_tokens(left)
    right_tokens = _meaningful_tokens(right)
    if not left_tokens or not right_tokens:
        return 0.0
    overlap = len(left_tokens & right_tokens)
    return 100 * overlap / max(len(left_tokens), len(right_tokens))


def _can_merge(left: str, right: str, similarity: float, threshold: float) -> bool:
    left_tokens = _meaningful_tokens(left)
    right_tokens = _meaningful_tokens(right)
    overlap = left_tokens & right_tokens
    if not overlap:
        return False
    if left_tokens == right_tokens:
        return True
    if _specificity_conflict(left_tokens, right_tokens):
        return False
    if len(overlap) < 2:
        return False
    smaller_coverage = len(overlap) / min(len(left_tokens), len(right_tokens))
    larger_coverage = len(overlap) / max(len(left_tokens), len(right_tokens))
    if smaller_coverage < 0.75 or larger_coverage < 0.50:
        return False
    return similarity >= threshold or _token_set_ratio(left, right) >= 86


def _specificity_conflict(left_tokens: set[str], right_tokens: set[str]) -> bool:
    left_numbers = {token for token in left_tokens if token.isdigit()}
    right_numbers = {token for token in right_tokens if token.isdigit()}
    if left_numbers and right_numbers and left_numbers != right_numbers:
        return True
    if min(len(left_tokens), len(right_tokens)) <= 1 < max(len(left_tokens), len(right_tokens)):
        return True
    return False


def _meaningful_tokens(value: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z0-9]+", value.casefold())
        if token not in GENERIC_PRODUCT_TOKENS
    }


def _assignment_detail(observation: TrendObservation, canonical: str, member_count: int) -> tuple[float, str]:
    if member_count == 1:
        return 0.0, "No confident related observation; preserved as a singleton orphan signal."
    if observation.normalized_term == canonical.casefold() or observation.term.casefold() == canonical.casefold():
        return 1.0, "Exact canonical term."
    left = _meaningful_tokens(observation.raw_term or observation.term)
    right = _meaningful_tokens(canonical)
    overlap = left & right
    confidence = len(overlap) / max(len(left | right), 1)
    return round(max(0.5, confidence), 3), "High-confidence lexical variant assignment."


def _observation_strength(observation: TrendObservation) -> float:
    return float(
        observation.metadata.get("source_score")
        or observation.search_volume
        or observation.velocity
        or observation.engagement
        or observation.mentions
    )
