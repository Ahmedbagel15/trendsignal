from __future__ import annotations

import re


BRAND_HINTS = {
    "alani nu",
    "celsius",
    "elf",
    "hoka",
    "on running",
    "cava",
    "chipotle",
    "nike",
    "lululemon",
    "starbucks",
    "dutch bros",
    "nestle",
    "stanley",
}


class EntityMapper:
    def extract_entities(self, text: str, terms: list[str]) -> list[str]:
        candidates = set()
        combined = " ".join([text, *terms])
        lower = combined.lower()
        for brand in BRAND_HINTS:
            if _contains_phrase(lower, brand):
                candidates.add(_title_brand(brand))

        title_phrases = re.findall(r"\b[A-Z][A-Za-z0-9&.'-]*(?:\s+[A-Z][A-Za-z0-9&.'-]*){0,3}", combined)
        for phrase in title_phrases:
            cleaned = phrase.strip()
            if len(cleaned) > 2:
                candidates.add(cleaned)

        product_patterns = [
            r"\b[\w\s-]+(?:shoes|gummies|latte|coffee|paddle|vest|mask|cup|bowl)\b",
        ]
        for pattern in product_patterns:
            for match in re.findall(pattern, lower):
                candidates.add(match.strip())

        return sorted(candidates)


def _title_brand(value: str) -> str:
    special = {"elf": "ELF", "hoka": "Hoka", "cava": "Cava"}
    return special.get(value, value.title())


def _contains_phrase(text: str, phrase: str) -> bool:
    return re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", text, re.IGNORECASE) is not None
