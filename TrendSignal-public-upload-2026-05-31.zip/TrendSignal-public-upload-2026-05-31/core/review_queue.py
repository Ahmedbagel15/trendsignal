from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd

from core.signal_aggregator import AggregatedSignal
from models import CommercialAssessment, CompanyExposure, TrendCluster


QUEUE_COLUMNS = [
    "date",
    "collection_run_id",
    "cluster_id",
    "canonical_term",
    "raw_representative_term",
    "sources_present",
    "source_count",
    "strongest_source",
    "strongest_source_score",
    "cross_platform_score",
    "single_platform_breakout_score",
    "commercial_intent_score",
    "revenue_materiality_score",
    "candidate_product",
    "candidate_brand",
    "candidate_company",
    "candidate_ticker",
    "investable_status",
    "mapping_confidence",
    "raw_observation_count",
    "evidence_urls",
    "hidden_signal_flag",
    "decision",
    "notes",
]
APPROVED_DECISIONS = {"approve", "approved", "validate"}
SAVED_DECISION_TO_FEEDBACK_LABEL = {
    "keep": "valuable",
    "saved": "valuable",
    "valuable": "valuable",
    "watch": "watch",
    "private_brand": "private_brand",
    "needs_mapping": "needs_mapping",
    "split_cluster": "needs_mapping",
    "merge_cluster": "needs_mapping",
}
USEFUL_ARCHIVE_COLUMNS = [
    "date",
    "canonical_term",
    "decision",
    "feedback_label",
    "notes",
    "source_origin",
    "sources_present",
    "strongest_source",
    "strongest_source_score",
    "google_search_volume",
    "reddit_mentions",
    "commercial_intent_score",
]


class ReviewQueue:
    """Stores multi-source discoveries until the user chooses their next step."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            pd.DataFrame(columns=QUEUE_COLUMNS).to_csv(self.path, index=False)

    def upsert(self, rows: list[dict[str, object]]) -> None:
        if not rows:
            return
        existing = self.load()
        incoming = pd.DataFrame(rows, columns=QUEUE_COLUMNS)
        if existing.empty:
            incoming.to_csv(self.path, index=False)
            return
        existing = existing.set_index("canonical_term", drop=False)
        for _, row in incoming.iterrows():
            term = str(row["canonical_term"])
            if term in existing.index:
                decision = existing.at[term, "decision"]
                notes = existing.at[term, "notes"]
                existing.loc[term] = row
                existing.at[term, "decision"] = decision
                existing.at[term, "notes"] = notes
            else:
                existing.loc[term] = row
        existing.reset_index(drop=True).to_csv(self.path, index=False)

    def refresh_run(self, rows: list[dict[str, object]], run_date: date) -> None:
        """Replace the visible inbox so stale evidence from earlier runs cannot linger."""
        pd.DataFrame(columns=QUEUE_COLUMNS).to_csv(self.path, index=False)
        self.upsert(rows)

    def approved(self) -> list[dict[str, object]]:
        frame = self.load()
        if frame.empty:
            return []
        decisions = frame["decision"].fillna("").astype(str).str.strip().str.lower()
        return frame[decisions.isin(APPROVED_DECISIONS)].to_dict("records")

    def archive_saved(self, archive_path: Path, feedback_path: Path) -> int:
        frame = self.load()
        if frame.empty:
            return 0
        decisions = frame["decision"].fillna("").astype(str).str.strip().str.lower()
        saved = frame[decisions.isin(SAVED_DECISION_TO_FEEDBACK_LABEL)].copy()
        if saved.empty:
            return 0
        saved["decision"] = saved["decision"].astype(str).str.strip().str.lower()
        saved["feedback_label"] = saved["decision"].map(SAVED_DECISION_TO_FEEDBACK_LABEL)
        useful_rows = saved.reindex(columns=USEFUL_ARCHIVE_COLUMNS)
        archive_path.parent.mkdir(parents=True, exist_ok=True)
        existing_archive = (
            pd.read_csv(archive_path, keep_default_na=False)
            if archive_path.exists()
            else pd.DataFrame(columns=USEFUL_ARCHIVE_COLUMNS)
        )
        existing_archive = _migrate_useful_archive(existing_archive)
        combined_archive = pd.concat([existing_archive, useful_rows], ignore_index=True)
        combined_archive = combined_archive.drop_duplicates(
            subset=["date", "canonical_term", "decision"],
            keep="last",
        )
        combined_archive.reindex(columns=USEFUL_ARCHIVE_COLUMNS).to_csv(archive_path, index=False)

        feedback_path.parent.mkdir(parents=True, exist_ok=True)
        feedback_rows = saved[["date", "canonical_term", "feedback_label", "notes"]].rename(
            columns={"canonical_term": "term", "feedback_label": "label"}
        )
        existing_feedback = (
            pd.read_csv(feedback_path, keep_default_na=False)
            if feedback_path.exists()
            else pd.DataFrame(columns=["date", "term", "label", "notes"])
        )
        combined_feedback = pd.concat([existing_feedback, feedback_rows], ignore_index=True)
        combined_feedback = combined_feedback.drop_duplicates(subset=["date", "term", "label"], keep="last")
        combined_feedback[["date", "term", "label", "notes"]].to_csv(feedback_path, index=False)
        return len(useful_rows)

    def load(self) -> pd.DataFrame:
        if not self.path.exists():
            return pd.DataFrame(columns=QUEUE_COLUMNS)
        frame = pd.read_csv(self.path, keep_default_na=False)
        frame = _migrate_queue(frame)
        return frame.reindex(columns=QUEUE_COLUMNS)

    @staticmethod
    def row(
        run_date: date,
        cluster: TrendCluster,
        commercial: CommercialAssessment,
        entities: list[str],
        aggregate: AggregatedSignal | None = None,
        exposures: list[CompanyExposure] | None = None,
    ) -> dict[str, object]:
        exposures = exposures or []
        primary = exposures[0] if exposures else None
        aggregate = aggregate or _fallback_aggregate(cluster, commercial)
        return {
            "date": run_date.isoformat(),
            "collection_run_id": cluster.observations[0].collection_run_id if cluster.observations else "",
            "cluster_id": cluster.cluster_id,
            "canonical_term": cluster.canonical_term,
            "raw_representative_term": cluster.observations[0].raw_term or cluster.canonical_term,
            "sources_present": ",".join(aggregate.sources_present),
            "source_count": aggregate.source_count,
            "strongest_source": aggregate.strongest_source,
            "strongest_source_score": aggregate.strongest_source_score,
            "cross_platform_score": aggregate.cross_platform_score,
            "single_platform_breakout_score": aggregate.single_platform_breakout_score,
            "commercial_intent_score": max(commercial.commercial_intent, aggregate.commercial_intent_score),
            "revenue_materiality_score": max((exposure.revenue_relevance for exposure in exposures), default=0),
            "candidate_product": cluster.canonical_term,
            "candidate_brand": primary.brand_entity if primary else "",
            "candidate_company": primary.company_name or primary.brand_entity if primary else "",
            "candidate_ticker": primary.ticker if primary else "",
            "investable_status": _investable_status(primary),
            "mapping_confidence": primary.confidence.value if primary else "",
            "raw_observation_count": len(cluster.observations),
            "evidence_urls": ",".join(aggregate.evidence_urls),
            "hidden_signal_flag": "yes" if len({obs.normalized_term or obs.term.casefold() for obs in cluster.observations}) > 1 else "",
            "decision": "",
            "notes": "",
        }


def _migrate_queue(frame: pd.DataFrame) -> pd.DataFrame:
    if "canonical_term" not in frame.columns and "term" in frame.columns:
        frame = frame.rename(
            columns={
                "term": "canonical_term",
                "search_volume": "google_search_volume",
                "commercial_intent": "commercial_intent_score",
            }
        )
    for column in QUEUE_COLUMNS:
        if column not in frame.columns:
            frame[column] = ""
    return frame


def _migrate_useful_archive(frame: pd.DataFrame) -> pd.DataFrame:
    if "canonical_term" not in frame.columns and "term" in frame.columns:
        frame = frame.rename(columns={"term": "canonical_term"})
    for column in USEFUL_ARCHIVE_COLUMNS:
        if column not in frame.columns:
            frame[column] = ""
    return frame


def _fallback_aggregate(cluster: TrendCluster, commercial: CommercialAssessment) -> AggregatedSignal:
    first = cluster.observations[0]
    return AggregatedSignal(
        canonical_term=cluster.canonical_term,
        sources_present=cluster.platforms,
        strongest_source=first.source or first.platform,
        strongest_source_score=max((observation.mentions for observation in cluster.observations), default=0),
        source_count=len(cluster.platforms),
        cross_platform_score=min(1.0, len(cluster.platforms) / 4),
        single_platform_breakout_score=0,
        earliest_seen_source=first.source or first.platform,
        earliest_seen_at=first.observed_at,
        evidence=cluster.observations,
        google_search_volume=max(
            (observation.mentions for observation in cluster.observations if observation.platform == "google_trends"),
            default=0,
        ),
        reddit_mentions=sum(
            observation.mentions for observation in cluster.observations if observation.platform == "reddit"
        ),
        commercial_intent_score=commercial.commercial_intent,
    )


def _investable_status(primary: CompanyExposure | None) -> str:
    if primary is None:
        return "needs_mapping"
    return "public_direct" if primary.relationship == "direct" else "public_indirect"
