"""Core pipeline modules for TrendSignal."""

