from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd

from models import Signal, TrendObservation


CSV_COLUMNS = [
    "date",
    "rank",
    "trend",
    "brand_entity",
    "primary_ticker",
    "secondary_tickers",
    "mapping_confidence",
    "signal_score",
    "attention_velocity",
    "cross_platform_confirmation",
    "commercial_intent",
    "ticker_purity",
    "revenue_relevance",
    "novelty",
    "earnings_timing",
    "feedback_adjustment",
    "feedback_reason",
    "confidence_level",
    "bull_thesis",
    "bear_thesis",
    "confirm_signal",
    "invalidate_signal",
]
YOUTUBE_DISCOVERY_COLUMNS = [
    "date",
    "candidate_term",
    "status",
    "reason",
    "sources_present",
    "strongest_source",
    "strongest_source_score",
    "cross_platform_score",
    "single_platform_breakout_score",
    "commercial_intent",
    "youtube_top_video_title",
    "youtube_top_video_url",
    "google_search_volume",
    "reddit_mentions",
    "mapped_tickers",
]


class ReportGenerator:
    def __init__(self, reports_dir: Path) -> None:
        self.reports_dir = reports_dir
        self.reports_dir.mkdir(parents=True, exist_ok=True)

    def write(self, signals: list[Signal]) -> tuple[Path, Path]:
        if not signals:
            raise ValueError("No signals available for report generation.")
        report_date = signals[0].run_date.isoformat()
        markdown_path = self.reports_dir / f"{report_date}_trend_report.md"
        csv_path = self.reports_dir / f"{report_date}_trend_report.csv"
        markdown_path.write_text(self._markdown(signals), encoding="utf-8")
        pd.DataFrame([self._csv_row(signal) for signal in signals], columns=CSV_COLUMNS).to_csv(
            csv_path, index=False
        )
        return markdown_path, csv_path

    def write_audit(
        self,
        run_date: date,
        observations: list[TrendObservation],
        audit_rows: list[dict[str, object]],
        signals: list[Signal],
        today_top_searches: list[dict[str, object]] | None = None,
        rolling_top_searches: list[dict[str, object]] | None = None,
        audit_name: str = "discovery",
    ) -> tuple[Path, Path]:
        report_date = run_date.isoformat()
        markdown_path = self.reports_dir / f"{report_date}_{audit_name}_audit.md"
        csv_path = self.reports_dir / f"{report_date}_{audit_name}_audit.csv"
        markdown_path.write_text(
            self._audit_markdown(
                run_date,
                observations,
                audit_rows,
                signals,
                today_top_searches or [],
                rolling_top_searches or [],
                audit_name,
            ),
            encoding="utf-8",
        )
        pd.DataFrame(audit_rows).to_csv(csv_path, index=False)
        return markdown_path, csv_path

    def write_youtube_discoveries(
        self,
        run_date: date,
        audit_rows: list[dict[str, object]],
    ) -> Path:
        path = self.reports_dir / f"{run_date.isoformat()}_youtube_discoveries.csv"
        youtube_rows = [
            {
                "date": row.get("date"),
                "candidate_term": row.get("trend"),
                "status": row.get("status"),
                "reason": row.get("reason"),
                "sources_present": row.get("sources_present"),
                "strongest_source": row.get("strongest_source"),
                "strongest_source_score": row.get("strongest_source_score"),
                "cross_platform_score": row.get("cross_platform_score"),
                "single_platform_breakout_score": row.get("single_platform_breakout_score"),
                "commercial_intent": row.get("commercial_intent"),
                "youtube_top_video_title": row.get("youtube_top_video_title"),
                "youtube_top_video_url": row.get("youtube_top_video_url"),
                "google_search_volume": row.get("google_search_volume"),
                "reddit_mentions": row.get("reddit_mentions"),
                "mapped_tickers": row.get("mapped_tickers"),
            }
            for row in audit_rows
            if "youtube" in str(row.get("sources_present") or "").split(",")
        ]
        pd.DataFrame(youtube_rows, columns=YOUTUBE_DISCOVERY_COLUMNS).to_csv(path, index=False)
        return path

    @staticmethod
    def _markdown(signals: list[Signal]) -> str:
        report_date = signals[0].run_date.isoformat()
        lines = [
            f"# TrendSignal Report - {report_date}",
            "",
            "Research signal only. Not financial advice. This watchlist does not place trades or claim guaranteed alpha.",
            "",
            "## Top Signals",
            "",
        ]
        for signal in signals:
            lines.extend(
                [
                    f"### {signal.rank}. {signal.trend} -> {signal.primary_ticker}",
                    "",
                    f"- Rank: {signal.rank}",
                    f"- Trend / search term: {signal.trend}",
                    f"- Related brand/entity: {signal.brand_entity}",
                    f"- Primary ticker: {signal.primary_ticker}",
                    f"- Secondary tickers if relevant: {', '.join(signal.secondary_tickers) or 'None'}",
                    f"- Mapping confidence: {signal.mapping_confidence.value}",
                    f"- Signal score: {signal.signal_score}",
                    f"- Commercial intent score: {signal.commercial_intent}",
                    f"- Feedback adjustment: {signal.feedback_adjustment}",
                    f"- Feedback reason: {signal.feedback_reason}",
                    f"- Platforms confirming signal: {', '.join(signal.platforms)}",
                    f"- Why it is interesting: {signal.why_interesting}",
                    f"- Bull thesis: {signal.bull_thesis}",
                    f"- Bear thesis: {signal.bear_thesis}",
                    f"- What would confirm the thesis: {signal.confirm_signal}",
                    f"- What would invalidate the thesis: {signal.invalidate_signal}",
                    f"- Suggested follow-up research: {signal.follow_up_research}",
                    f"- Confidence level: {signal.confidence_level}",
                    f"- Disclaimer: {signal.disclaimer}",
                    "",
                ]
            )
        return "\n".join(lines)

    @staticmethod
    def _audit_markdown(
        run_date: date,
        observations: list[TrendObservation],
        audit_rows: list[dict[str, object]],
        signals: list[Signal],
        today_top_searches: list[dict[str, object]],
        rolling_top_searches: list[dict[str, object]],
        audit_name: str = "discovery",
    ) -> str:
        lines = [
            f"# TrendSignal {audit_name.title()} Audit - {run_date.isoformat()}",
            "",
            "Research signal only. Not financial advice.",
            "",
            "## Source Summary",
            "",
            f"- Discovered observations reviewed: {len(observations)}",
            f"- Scored watchlist signals generated: {len(signals)}",
            "",
            "## Raw Discovery Feed",
            "",
        ]
        raw_rows = sorted(
            observations,
            key=lambda observation: float(
                observation.metadata.get("source_score")
                or observation.search_volume
                or observation.velocity
                or observation.engagement
                or observation.mentions
            ),
            reverse=True,
        )[:20]
        lines.extend(
            [
                f"- {observation.raw_term or observation.term} "
                f"(source {observation.source or observation.platform}, observation {observation.observation_id}, "
                f"url {observation.url or 'none'})"
                for observation in raw_rows
            ]
            or ["No raw observations were collected."]
        )
        lines.extend(
            [
                "",
                "## Clustered Discovery Feed",
                "",
            ]
        )
        clustered_rows = sorted(
            audit_rows,
            key=lambda row: float(row.get("strongest_source_score") or 0),
            reverse=True,
        )[:20]
        lines.extend(
            [
                f"- {row.get('trend')} "
                f"(cluster {row.get('cluster_id')}, sources {row.get('sources_present')}, "
                f"raw observations {row.get('raw_observation_count')})"
                for row in clustered_rows
            ]
            or ["No clustered discoveries were produced."]
        )
        lines.extend(
            [
                "",
                "## Orphan Signals",
                "",
                "See `data/processed/orphan_signals.csv` for high-scoring raw observations that were preserved without a confident cluster assignment.",
                "",
                "## Hidden Signals",
                "",
                f"See `data/reports/{run_date.isoformat()}_hidden_signal_report.md` for commercially distinct cluster members.",
                "",
            "## Today's Top Discovered Searches",
            "",
            ]
        )
        if today_top_searches:
            for index, row in enumerate(today_top_searches, start=1):
                lines.append(
                    f"{index}. {row.get('term')} "
                    f"(rank {row.get('discovery_rank')}, interest {row.get('mentions')}, growth {row.get('growth_rate')})"
                )
        else:
            lines.append("No searches were archived for today.")
        lines.extend(
            [
                "",
                "## Rolling 30-Day Recurring Searches",
                "",
            ]
        )
        if rolling_top_searches:
            for index, row in enumerate(rolling_top_searches, start=1):
                lines.append(
                    f"{index}. {row.get('term')} "
                    f"(days seen {row.get('days_seen')}, avg rank {row.get('avg_discovery_rank')}, "
                    f"avg interest {row.get('avg_mentions')}, avg growth {row.get('avg_growth_rate')})"
                )
        else:
            lines.append("No rolling search history is available yet.")
        product_rows = sorted(
            (
                row
                for row in audit_rows
                if row.get("status")
                in {
                    "product_discovery",
                    "candidate",
                    "pending_validation",
                    "validated_product_discovery",
                    "validated_candidate",
                }
            ),
            key=lambda row: (
                float(row.get("feedback_adjustment") or 0),
                float(row.get("search_volume") or 0),
                float(row.get("commercial_intent") or 0),
            ),
            reverse=True,
        )[:10]
        lines.extend(
            [
                "",
                "## Top Consumer/Product Discoveries",
                "",
            ]
        )
        if product_rows:
            for index, row in enumerate(product_rows, start=1):
                lines.append(
                    f"{index}. {row.get('trend')} "
                    f"(search volume {row.get('search_volume')}, type {row.get('trend_type')}, "
                    f"commercial intent {row.get('commercial_intent')}, "
                    f"feedback adjustment {row.get('feedback_adjustment')}, "
                    f"mapped tickers {row.get('mapped_tickers') or 'none'})"
                )
        else:
            lines.append("No consumer-product search trends passed the commercial filter.")
        lines.extend(["", "## Top YouTube-Discovered Product Signals", ""])
        lines.extend(_source_rows(audit_rows, "youtube", "No YouTube-discovered product signals passed filtering."))
        lines.extend(["", "## Top TikTok/Instagram Manual Export Signals", ""])
        lines.extend(_social_export_rows(audit_rows))
        lines.extend(["", "## Top Google Trends Confirmation Signals", ""])
        lines.extend(_source_rows(audit_rows, "google_trends", "No Google Trends confirmations passed filtering."))
        lines.extend(["", "## Top Cross-Platform Breakouts", ""])
        lines.extend(_breakout_rows(audit_rows, cross_platform=True))
        lines.extend(["", "## Strong Single-Platform Breakouts", ""])
        lines.extend(_breakout_rows(audit_rows, cross_platform=False))
        lines.extend(["", "## Product Signals With Clean Public-Company Mapping", ""])
        clean = [row for row in audit_rows if row.get("investable_status") in {"public_direct", "public_indirect"}][:20]
        lines.extend(
            [f"- {row.get('trend')} -> {row.get('mapped_tickers')} ({row.get('investable_status')})" for row in clean]
            or ["No clean public-company mappings were recorded."]
        )
        lines.extend(["", "## Strong Demand With Unclear Mapping", ""])
        unclear = [
            row
            for row in audit_rows
            if row.get("investable_status") in {"needs_mapping", "unknown_company", "no_investable_path"}
            and float(row.get("strongest_source_score") or 0) > 0
        ][:20]
        lines.extend(
            [
                f"- {row.get('trend')} (sources {row.get('sources_present')}, strongest score {row.get('strongest_source_score')})"
                for row in unclear
            ]
            or ["No unclear-mapping product signals were recorded."]
        )
        lines.extend(["", "## Commercially Relevant But Private-Company Trends", ""])
        lines.append("See `data/processed/useful_discoveries.csv` for rows labeled `private_brand`.")
        lines.extend(["", "## Rejected/Noisy Viral Trends", ""])
        rejected = [row for row in audit_rows if row.get("status") in {"rejected", "feedback_rejected"}][:20]
        lines.extend(
            [f"- {row.get('trend')}: {row.get('reason')}" for row in rejected]
            or ["No rejected/noisy trends were recorded."]
        )
        lines.extend(
            [
                "",
            "## Discovery Review",
            "",
            ]
        )
        if not audit_rows:
            lines.append("No discovered terms were available for review.")
            return "\n".join(lines)

        for row in audit_rows:
            lines.extend(
                [
                    f"### {row.get('trend')}",
                    "",
                    f"- Status: {row.get('status')}",
                    f"- Reason: {row.get('reason')}",
                    f"- Platforms: {row.get('platforms')}",
                    f"- Attention velocity: {row.get('attention_velocity')}",
                    f"- Trend type: {row.get('trend_type')}",
                    f"- Commercial intent: {row.get('commercial_intent')}",
                    f"- Feedback label: {row.get('feedback_label') or 'none'}",
                    f"- Feedback adjustment: {row.get('feedback_adjustment')}",
                    f"- Feedback reason: {row.get('feedback_reason')}",
                    f"- Entities: {row.get('entities')}",
                    f"- Mapped tickers: {row.get('mapped_tickers')}",
                    "",
                ]
            )
        return "\n".join(lines)

    @staticmethod
    def _csv_row(signal: Signal) -> dict[str, object]:
        return {
            "date": signal.run_date.isoformat(),
            "rank": signal.rank,
            "trend": signal.trend,
            "brand_entity": signal.brand_entity,
            "primary_ticker": signal.primary_ticker,
            "secondary_tickers": ",".join(signal.secondary_tickers),
            "mapping_confidence": signal.mapping_confidence.value,
            "signal_score": signal.signal_score,
            "attention_velocity": signal.attention_velocity,
            "cross_platform_confirmation": signal.cross_platform_confirmation,
            "commercial_intent": signal.commercial_intent,
            "ticker_purity": signal.ticker_purity,
            "revenue_relevance": signal.revenue_relevance,
            "novelty": signal.novelty,
            "earnings_timing": signal.earnings_timing,
            "feedback_adjustment": signal.feedback_adjustment,
            "feedback_reason": signal.feedback_reason,
            "confidence_level": signal.confidence_level,
            "bull_thesis": signal.bull_thesis,
            "bear_thesis": signal.bear_thesis,
            "confirm_signal": signal.confirm_signal,
            "invalidate_signal": signal.invalidate_signal,
        }


def _source_rows(audit_rows: list[dict[str, object]], source: str, empty_message: str) -> list[str]:
    rows = [row for row in audit_rows if source in str(row.get("sources_present") or "").split(",")]
    rows = sorted(rows, key=lambda row: float(row.get("strongest_source_score") or 0), reverse=True)[:10]
    return [
        f"- {row.get('trend')} (sources {row.get('sources_present')}, strongest score {row.get('strongest_source_score')})"
        for row in rows
    ] or [empty_message]


def _social_export_rows(audit_rows: list[dict[str, object]]) -> list[str]:
    rows = [row for row in audit_rows if row.get("social_export_source_file")]
    rows = sorted(rows, key=lambda row: float(row.get("strongest_source_score") or 0), reverse=True)[:10]
    return [
        f"- {row.get('trend')} (file {row.get('social_export_source_file')}, sources {row.get('sources_present')})"
        for row in rows
    ] or ["No TikTok/Instagram manual-export signals passed filtering."]


def _breakout_rows(audit_rows: list[dict[str, object]], cross_platform: bool) -> list[str]:
    field = "cross_platform_score" if cross_platform else "single_platform_breakout_score"
    rows = sorted(audit_rows, key=lambda row: float(row.get(field) or 0), reverse=True)[:10]
    return [
        f"- {row.get('trend')} ({field.replace('_', ' ')} {row.get(field)}, sources {row.get('sources_present')})"
        for row in rows
        if float(row.get(field) or 0) > 0
    ] or ["No breakout signals were recorded."]
