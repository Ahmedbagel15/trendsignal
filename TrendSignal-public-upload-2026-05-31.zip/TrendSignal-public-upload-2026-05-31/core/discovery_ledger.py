from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

import pandas as pd

from core.signal_aggregator import AggregatedSignal
from core.trend_clusterer import _observation_strength
from models import ClusterAssignment, CommercialAssessment, CompanyExposure, TrendCluster, TrendObservation


RAW_COLUMNS = [
    "observation_id", "collection_run_id", "source", "platform", "raw_term", "normalized_term",
    "title", "description", "url", "timestamp", "observed_at", "views", "likes", "comments",
    "shares", "saves", "mentions", "search_volume", "engagement", "growth_rate", "velocity",
    "commercial_intent", "price", "rank", "source_file", "raw_payload_json",
]
CLUSTER_COLUMNS = [
    "collection_run_id", "cluster_id", "canonical_term", "member_observation_ids", "evidence_urls",
    "evidence_sources", "supporting_observation_count", "source_count", "sources_present",
    "earliest_seen_at", "earliest_seen_source", "strongest_source", "strongest_source_observation_id",
    "strongest_source_score", "cross_platform_score", "single_platform_breakout_score",
    "commercial_intent_score", "revenue_materiality_score", "candidate_company", "candidate_ticker",
    "mapping_confidence", "investable_status",
]
MEMBER_COLUMNS = [
    "raw_observation_id", "cluster_id", "canonical_term", "raw_term", "source",
    "assignment_confidence", "assignment_reason",
]


@dataclass
class ClusterContext:
    cluster: TrendCluster
    aggregate: AggregatedSignal
    commercial: CommercialAssessment
    exposures: list[CompanyExposure]
    investable_status: str
    revenue_materiality_score: float


class DiscoveryLedger:
    def __init__(self, processed_dir: Path, reports_dir: Path) -> None:
        self.processed_dir = processed_dir
        self.reports_dir = reports_dir
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        self.reports_dir.mkdir(parents=True, exist_ok=True)

    def write_raw(self, observations: list[TrendObservation]) -> Path:
        path = self.processed_dir / "raw_discoveries.csv"
        rows = [_raw_row(obs) for obs in observations]
        frame = pd.DataFrame(rows, columns=RAW_COLUMNS)
        if not frame.empty:
            frame = frame.drop_duplicates(
                subset=["source", "platform", "raw_term", "url", "source_file", "raw_payload_json"],
                keep="first",
            )
        frame.to_csv(path, index=False)
        return path

    def write_clusters(self, contexts: list[ClusterContext]) -> Path:
        path = self.processed_dir / "clustered_discoveries.csv"
        rows = [_cluster_row(context) for context in contexts]
        pd.DataFrame(rows, columns=CLUSTER_COLUMNS).to_csv(path, index=False)
        return path

    def write_members(self, assignments: list[ClusterAssignment]) -> Path:
        path = self.processed_dir / "cluster_members.csv"
        pd.DataFrame([assignment.model_dump() for assignment in assignments], columns=MEMBER_COLUMNS).to_csv(
            path, index=False
        )
        return path

    def write_orphans(
        self,
        observations: list[TrendObservation],
        assignments: list[ClusterAssignment],
        threshold: float = 1000,
    ) -> Path:
        path = self.processed_dir / "orphan_signals.csv"
        assigned = {assignment.raw_observation_id for assignment in assignments if assignment.assignment_confidence >= 0.75}
        rows = [
            _raw_row(observation)
            for observation in observations
            if observation.observation_id not in assigned and _observation_strength(observation) >= threshold
        ]
        pd.DataFrame(rows, columns=RAW_COLUMNS).to_csv(path, index=False)
        return path

    def write_hidden_signal_report(self, run_date: date, contexts: list[ClusterContext]) -> Path:
        path = self.reports_dir / f"{run_date.isoformat()}_hidden_signal_report.md"
        lines = [
            f"# TrendSignal Hidden Signal Report - {run_date.isoformat()}",
            "",
            "Aggregation review only. Raw observations remain available in `data/processed/raw_discoveries.csv`.",
            "",
            "## Potentially Hidden Signals",
            "",
        ]
        hidden = 0
        for context in contexts:
            canonical = context.cluster.canonical_term.casefold()
            for observation in context.cluster.observations:
                raw = observation.raw_term or observation.term
                if raw.casefold() == canonical:
                    continue
                if _observation_strength(observation) < 1000 and observation.commercial_intent < 0.6:
                    continue
                hidden += 1
                lines.extend(
                    [
                        f"### {raw}",
                        "",
                        f"- Assigned cluster: {context.cluster.canonical_term}",
                        f"- Raw observation ID: {observation.observation_id}",
                        f"- Source: {observation.source or observation.platform}",
                        f"- Source score: {round(_observation_strength(observation), 3)}",
                        f"- Evidence URL: {observation.url or 'none'}",
                        "- Review note: This member may deserve its own product, brand, or ticker investigation.",
                        "",
                    ]
                )
        if not hidden:
            lines.append("No commercially distinct cluster members require manual review.")
        path.write_text("\n".join(lines), encoding="utf-8")
        return path


def _raw_row(observation: TrendObservation) -> dict[str, Any]:
    metadata = observation.metadata
    payload = observation.raw_payload_json or json.dumps(metadata.get("raw_payload") or {}, ensure_ascii=True)
    return {
        "observation_id": observation.observation_id,
        "collection_run_id": observation.collection_run_id,
        "source": observation.source or observation.platform,
        "platform": observation.platform,
        "raw_term": observation.raw_term or observation.term,
        "normalized_term": observation.normalized_term or observation.term.casefold(),
        "title": observation.title or "",
        "description": observation.description or "",
        "url": observation.url or "",
        "timestamp": observation.timestamp.isoformat() if observation.timestamp else "",
        "observed_at": observation.observed_at.isoformat(),
        "views": observation.views,
        "likes": observation.likes,
        "comments": observation.comments,
        "shares": observation.shares or metadata.get("shares", 0),
        "saves": observation.saves or metadata.get("saves", 0),
        "mentions": observation.mentions,
        "search_volume": observation.search_volume or observation.mentions,
        "engagement": observation.engagement,
        "growth_rate": observation.growth_rate,
        "velocity": observation.velocity,
        "commercial_intent": observation.commercial_intent,
        "price": observation.price if observation.price is not None else metadata.get("price", ""),
        "rank": observation.rank if observation.rank is not None else metadata.get("rank", ""),
        "source_file": observation.source_file or metadata.get("source_file", ""),
        "raw_payload_json": payload,
    }


def _cluster_row(context: ClusterContext) -> dict[str, Any]:
    cluster, aggregate = context.cluster, context.aggregate
    primary = context.exposures[0] if context.exposures else None
    run_id = cluster.observations[0].collection_run_id if cluster.observations else ""
    return {
        "collection_run_id": run_id,
        "cluster_id": cluster.cluster_id,
        "canonical_term": cluster.canonical_term,
        "member_observation_ids": ",".join(cluster.member_observation_ids),
        "evidence_urls": ",".join(cluster.evidence_urls),
        "evidence_sources": ",".join(cluster.evidence_sources),
        "supporting_observation_count": len(cluster.observations),
        "source_count": aggregate.source_count,
        "sources_present": ",".join(aggregate.sources_present),
        "earliest_seen_at": cluster.earliest_seen_at.isoformat() if cluster.earliest_seen_at else "",
        "earliest_seen_source": aggregate.earliest_seen_source,
        "strongest_source": aggregate.strongest_source,
        "strongest_source_observation_id": cluster.strongest_source_observation_id,
        "strongest_source_score": aggregate.strongest_source_score,
        "cross_platform_score": aggregate.cross_platform_score,
        "single_platform_breakout_score": aggregate.single_platform_breakout_score,
        "commercial_intent_score": max(context.commercial.commercial_intent, aggregate.commercial_intent_score),
        "revenue_materiality_score": context.revenue_materiality_score,
        "candidate_company": primary.company_name or primary.brand_entity if primary else "",
        "candidate_ticker": primary.ticker if primary else "",
        "mapping_confidence": primary.confidence.value if primary else "",
        "investable_status": context.investable_status,
    }
