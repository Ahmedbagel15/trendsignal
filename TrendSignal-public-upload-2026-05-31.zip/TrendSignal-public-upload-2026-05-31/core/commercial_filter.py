from __future__ import annotations

import re

from models import CommercialAssessment, TrendCluster, TrendType


PRODUCT_WORDS = {
    "cup",
    "shoe",
    "shoes",
    "gummies",
    "coffee",
    "latte",
    "paddle",
    "vest",
    "mask",
    "supplement",
    "skincare",
    "bowl",
    "drink",
    "ring",
    "bottle",
    "tumbler",
    "toy",
    "collectible",
    "bag",
    "backpack",
    "jacket",
    "shirt",
    "jeans",
    "dress",
    "watch",
    "phone",
    "headphones",
    "camera",
    "speaker",
    "gadget",
    "appliance",
    "blender",
    "air fryer",
    "serum",
    "cream",
    "cleanser",
    "lipstick",
    "mascara",
    "sunscreen",
    "snack",
    "candy",
    "soda",
    "car",
    "ev",
    "console",
}
SHOPPING_WORDS = {
    "buy",
    "where to buy",
    "amazon",
    "dupe",
    "review",
    "price",
    "resale",
    "marketplace",
    "recommend",
    "best",
}
ENTERTAINMENT_WORDS = {
    "dance",
    "audio",
    "lip sync",
    "meme",
    "reaction",
    "celebrity",
    "drama",
    "breakup",
    "challenge",
}
BRAND_WORDS = {
    "hoka",
    "celsius",
    "elf",
    "alani",
    "stanley",
    "cava",
    "on running",
    "nike",
    "lululemon",
}
SPORTS_WORDS = {
    "baseball",
    "basketball",
    "football",
    "hockey",
    "soccer",
    "softball",
    "nba",
    "nfl",
    "nhl",
    "mlb",
    "ufc",
    "ncaa",
    "standings",
    "score",
    "scores",
    "schedule",
    "tournament",
    "final",
    "finals",
    "game",
    "roster",
    "playoffs",
    "fifa",
    "world cup",
    "squad",
    "winners",
}
SPORTS_MATCHUP_RE = re.compile(r"\b(?:vs|versus)\b", re.IGNORECASE)
ADVERSE_EVENT_WORDS = {
    "recall",
    "salmonella",
    "lawsuit",
    "litigation",
    "settlement",
    "data breach",
    "closure",
    "closures",
    "arrest",
    "suspension",
    "explosion",
    "theft",
    "prior authorization",
}
NON_COMMERCE_CONTEXT_PHRASES = {
    "traffic enforcement",
    "flood watch",
    "where to watch",
    "car chase",
    "car accident",
    "attorney",
    "transit",
    "toy story",
    "buyers are gone",
}
GENERIC_PRODUCT_TERMS = {"jeans", "mask"}


class CommercialFilter:
    def assess(self, cluster: TrendCluster, entities: list[str]) -> CommercialAssessment:
        related_queries = [
            query
            for observation in cluster.observations
            for query in observation.metadata.get("related_queries", [])
        ]
        source_evidence = [
            value
            for observation in cluster.observations
            for value in [observation.title, observation.description]
            if value
        ]
        primary_text = " ".join([cluster.canonical_term, *cluster.terms]).lower()
        supporting_text = " ".join([*entities, *related_queries, *source_evidence]).lower()
        text = f"{primary_text} {supporting_text}"
        sports_hits = sum(1 for word in SPORTS_WORDS if _contains_phrase(primary_text, word))
        adverse_hits = sum(1 for word in ADVERSE_EVENT_WORDS if _contains_phrase(primary_text, word))
        non_commerce_hits = sum(1 for phrase in NON_COMMERCE_CONTEXT_PHRASES if _contains_phrase(primary_text, phrase))
        if cluster.canonical_term.strip().lower() in GENERIC_PRODUCT_TERMS:
            return CommercialAssessment(
                trend_type=TrendType.UNCLEAR,
                commercial_intent=0.0,
                purchase_intent=0.0,
                rationale="Rejected known generic product category; a more specific product signal is required.",
                allowed_for_scoring=False,
            )
        if SPORTS_MATCHUP_RE.search(primary_text) or sports_hits:
            return CommercialAssessment(
                trend_type=TrendType.UNCLEAR,
                commercial_intent=0.0,
                purchase_intent=0.0,
                rationale="Rejected sports event, matchup, schedule, or score search.",
                allowed_for_scoring=False,
            )
        if non_commerce_hits:
            return CommercialAssessment(
                trend_type=TrendType.UNCLEAR,
                commercial_intent=0.0,
                purchase_intent=0.0,
                rationale="Rejected non-commerce context containing an ambiguous product word.",
                allowed_for_scoring=False,
            )
        if adverse_hits:
            return CommercialAssessment(
                trend_type=TrendType.UNCLEAR,
                commercial_intent=0.0,
                purchase_intent=0.0,
                rationale="Rejected adverse-event search; track separately from positive consumer demand.",
                allowed_for_scoring=False,
            )

        primary_product_hits = sum(1 for word in PRODUCT_WORDS if _contains_phrase(primary_text, word))
        supporting_product_hits = sum(1 for word in PRODUCT_WORDS if _contains_phrase(supporting_text, word))
        product_hits = primary_product_hits + supporting_product_hits
        shopping_hits = sum(1 for word in SHOPPING_WORDS if _contains_phrase(text, word))
        entertainment_hits = sum(1 for word in ENTERTAINMENT_WORDS if _contains_phrase(text, word))
        primary_brand_hits = sum(1 for word in BRAND_WORDS if _contains_phrase(primary_text, word))
        brand_hits = primary_brand_hits + sum(1 for word in BRAND_WORDS if _contains_phrase(supporting_text, word))
        marketplace_boost = 1 if "facebook_marketplace" in cluster.platforms else 0
        source_commercial_intent = max(
            (observation.commercial_intent for observation in cluster.observations),
            default=0.0,
        )
        source_purchase_evidence = source_commercial_intent >= 0.35 and any(
            (observation.source or observation.platform) in {"youtube", "social_exports"}
            for observation in cluster.observations
        )

        positive = (
            product_hits * 0.22
            + shopping_hits * 0.12
            + brand_hits * 0.18
            + marketplace_boost * 0.08
            + source_commercial_intent * 0.25
        )
        negative = entertainment_hits * 0.28
        score = max(0.0, min(1.0, 0.2 + positive - negative))
        purchase_intent = max(0.0, min(1.0, score + marketplace_boost * 0.1 + shopping_hits * 0.05))
        trend_type = self._classify(text, primary_product_hits, primary_brand_hits, entertainment_hits)
        if trend_type == TrendType.UNCLEAR and source_purchase_evidence:
            trend_type = TrendType.PRODUCT
        allowed = trend_type in {TrendType.PRODUCT, TrendType.BRAND, TrendType.SERVICE} or (
            trend_type == TrendType.AESTHETIC and score >= 0.65
        )

        rationale = (
            f"Detected {product_hits} product cues, {brand_hits} brand cues, "
            f"{shopping_hits} shopping cues, {source_commercial_intent:.2f} source commercial intent, "
            f"and {entertainment_hits} entertainment penalties. "
            "Primary search term must contain the product or brand cue."
        )
        return CommercialAssessment(
            trend_type=trend_type,
            commercial_intent=round(score, 3),
            purchase_intent=round(purchase_intent, 3),
            rationale=rationale,
            allowed_for_scoring=allowed,
        )

    @staticmethod
    def _classify(text: str, product_hits: int, brand_hits: int, entertainment_hits: int) -> TrendType:
        if entertainment_hits and not product_hits and not brand_hits:
            if "meme" in text:
                return TrendType.MEME
            return TrendType.ENTERTAINMENT
        if brand_hits:
            return TrendType.BRAND
        if product_hits:
            return TrendType.PRODUCT
        if any(word in text for word in ["aesthetic", "core", "style"]):
            return TrendType.AESTHETIC
        return TrendType.UNCLEAR


def _contains_phrase(text: str, phrase: str) -> bool:
    return re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", text, re.IGNORECASE) is not None
