from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from dataclasses import dataclass

from models import CommercialAssessment, CompanyExposure, TrendCluster

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class LLMNarrative:
    why_interesting: str
    bull_thesis: str
    bear_thesis: str
    confirm_signal: str
    invalidate_signal: str
    follow_up_research: str


class OpenAICompatibleAssistant:
    """Optional OpenAI-compatible narrative helper.

    This module only summarizes and classifies research context. It does not
    place trades. Treat LLM-only company mappings as uncertain until validated
    against structured sources.
    """

    def __init__(self, enabled: bool = False) -> None:
        self.enabled = enabled
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        self.model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")

    def summarize(
        self,
        cluster: TrendCluster,
        commercial: CommercialAssessment,
        exposure: CompanyExposure,
    ) -> LLMNarrative | None:
        if not self.enabled:
            return None
        if not self.api_key:
            LOGGER.warning("LLM support enabled but OPENAI_API_KEY is missing.")
            return None

        prompt = {
            "task": "Create concise financial research signal notes. Do not give trading advice.",
            "trend": cluster.canonical_term,
            "terms": cluster.terms,
            "platforms": cluster.platforms,
            "attention_velocity": cluster.attention_velocity,
            "commercial_assessment": commercial.model_dump(mode="json"),
            "company_exposure": exposure.model_dump(mode="json"),
            "constraints": [
                "Flag uncertainty.",
                "Focus on revenue or earnings linkage.",
                "Avoid claiming guaranteed alpha.",
                "Return strict JSON with keys why_interesting, bull_thesis, bear_thesis, confirm_signal, invalidate_signal, follow_up_research.",
            ],
        }
        try:
            response = self._chat(prompt)
            parsed = json.loads(response)
            return LLMNarrative(**parsed)
        except Exception:
            LOGGER.exception("LLM summarization failed; using deterministic narratives.")
            return None

    def _chat(self, prompt: dict) -> str:
        payload = json.dumps(
            {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a careful equity research assistant. You produce uncertain research notes, never trading instructions.",
                    },
                    {"role": "user", "content": json.dumps(prompt)},
                ],
                "temperature": 0.2,
                "response_format": {"type": "json_object"},
            }
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{self.base_url.rstrip('/')}/chat/completions",
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise RuntimeError(f"OpenAI-compatible request failed: {exc}") from exc
        return data["choices"][0]["message"]["content"]
