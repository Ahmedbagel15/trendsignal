from __future__ import annotations

from datetime import date
from typing import Any

from models import CommercialAssessment, CompanyExposure, FinanceSnapshot, MappingConfidence, Signal, TrendCluster


CONFIDENCE_PENALTY = {
    MappingConfidence.DIRECT: 1.0,
    MappingConfidence.PROBABLE: 0.88,
    MappingConfidence.WEAK: 0.65,
    MappingConfidence.SPECULATIVE: 0.45,
}


class SignalScorer:
    def __init__(self, weights: dict[str, float], llm_assistant: Any | None = None) -> None:
        self.weights = weights
        self.llm_assistant = llm_assistant

    def score(
        self,
        run_date: date,
        cluster: TrendCluster,
        commercial: CommercialAssessment,
        exposures: list[CompanyExposure],
        finance: dict[str, FinanceSnapshot],
        feedback_adjustment: float = 0.0,
        feedback_reason: str = "No matching feedback.",
    ) -> list[Signal]:
        signals: list[Signal] = []
        cross_platform = min(1.0, len(cluster.platforms) / 4)
        strongest_source_score = max(
            (
                float(
                    observation.metadata.get("source_score")
                    or observation.search_volume
                    or observation.velocity
                    or observation.engagement
                    or observation.mentions
                )
                for observation in cluster.observations
            ),
            default=0.0,
        )
        single_platform_breakout = min(1.0, strongest_source_score / 10_000)
        consumer_purchase_signal = max(
            commercial.purchase_intent,
            max((observation.commercial_intent for observation in cluster.observations), default=0.0),
        )

        for index, exposure in enumerate(exposures):
            earnings_timing = self._earnings_timing(run_date, finance.get(exposure.ticker))
            raw_score = (
                self.weights.get("raw_attention_velocity", self.weights.get("attention_velocity", 0.15))
                * cluster.attention_velocity
                + self.weights.get("single_platform_breakout_score", 0.15) * single_platform_breakout
                + self.weights.get("cross_platform_confirmation_score", self.weights.get("cross_platform_confirmation", 0.15))
                * cross_platform
                + self.weights.get("commercial_intent_score", self.weights.get("commercial_intent", 0.15))
                * commercial.commercial_intent
                + self.weights.get("consumer_purchase_signal", 0.15) * consumer_purchase_signal
                + self.weights.get("public_equity_mapping_score", self.weights.get("ticker_purity", 0.10))
                * exposure.ticker_purity
                + self.weights.get("revenue_materiality_score", self.weights.get("revenue_relevance", 0.10))
                * exposure.revenue_relevance
                + self.weights.get("novelty_score", self.weights.get("novelty", 0.05)) * cluster.novelty
            )
            score = raw_score * CONFIDENCE_PENALTY[exposure.confidence] * 100 + feedback_adjustment
            if index > 0:
                score *= 0.92

            narrative = None
            if self.llm_assistant is not None:
                narrative = self.llm_assistant.summarize(cluster, commercial, exposure)

            signals.append(
                Signal(
                    run_date=run_date,
                    trend=cluster.canonical_term,
                    brand_entity=exposure.brand_entity,
                    primary_ticker=exposure.ticker,
                    secondary_tickers=[item.ticker for item in exposures if item.ticker != exposure.ticker],
                    mapping_confidence=exposure.confidence,
                    signal_score=round(score, 2),
                    attention_velocity=round(cluster.attention_velocity, 3),
                    cross_platform_confirmation=round(cross_platform, 3),
                    commercial_intent=commercial.commercial_intent,
                    ticker_purity=round(exposure.ticker_purity, 3),
                    revenue_relevance=round(exposure.revenue_relevance, 3),
                    novelty=round(cluster.novelty, 3),
                    earnings_timing=round(earnings_timing, 3),
                    feedback_adjustment=feedback_adjustment,
                    feedback_reason=feedback_reason,
                    platforms=cluster.platforms,
                    trend_type=commercial.trend_type,
                    confidence_level=self._confidence_level(score, exposure.confidence, commercial.commercial_intent),
                    why_interesting=narrative.why_interesting if narrative else self._why_interesting(cluster, exposure),
                    bull_thesis=narrative.bull_thesis if narrative else self._bull_thesis(cluster.canonical_term, exposure),
                    bear_thesis=narrative.bear_thesis if narrative else self._bear_thesis(cluster.canonical_term, exposure),
                    confirm_signal=narrative.confirm_signal if narrative else self._confirm_signal(cluster.canonical_term, exposure),
                    invalidate_signal=narrative.invalidate_signal if narrative else self._invalidate_signal(cluster.canonical_term, exposure),
                    follow_up_research=narrative.follow_up_research if narrative else self._follow_up(cluster.canonical_term, exposure),
                )
            )
        return signals

    @staticmethod
    def _earnings_timing(run_date: date, snapshot: FinanceSnapshot | None) -> float:
        if not snapshot or not snapshot.earnings_date:
            return 0.2
        days = (snapshot.earnings_date - run_date).days
        if 14 <= days <= 56:
            return 1.0
        if 0 <= days < 14 or 56 < days <= 84:
            return 0.5
        return 0.1

    @staticmethod
    def _confidence_level(score: float, mapping: MappingConfidence, commercial_intent: float) -> str:
        if score >= 70 and mapping in {MappingConfidence.DIRECT, MappingConfidence.PROBABLE} and commercial_intent >= 0.6:
            return "high"
        if score >= 45 and mapping != MappingConfidence.SPECULATIVE:
            return "medium"
        return "low"

    @staticmethod
    def _why_interesting(cluster: TrendCluster, exposure: CompanyExposure) -> str:
        return (
            f"{cluster.canonical_term} is accelerating across {len(cluster.platforms)} platform(s), "
            f"with a {exposure.confidence.value} mapping to {exposure.ticker} via {exposure.relationship}."
        )

    @staticmethod
    def _bull_thesis(trend: str, exposure: CompanyExposure) -> str:
        return (
            f"If {trend} reflects repeatable consumer spending, {exposure.company_name or exposure.ticker} "
            f"could benefit through {exposure.relationship}."
        )

    @staticmethod
    def _bear_thesis(trend: str, exposure: CompanyExposure) -> str:
        return (
            f"The trend may be short-lived, already priced in, or too small to matter for "
            f"{exposure.company_name or exposure.ticker}'s revenue base."
        )

    @staticmethod
    def _confirm_signal(trend: str, exposure: CompanyExposure) -> str:
        return (
            f"Look for sustained search/social growth, retailer sell-through, product reviews, "
            f"and company commentary linking {trend} to {exposure.ticker} demand."
        )

    @staticmethod
    def _invalidate_signal(trend: str, exposure: CompanyExposure) -> str:
        return (
            f"Invalidate if attention fades, purchase-intent language disappears, or the public-company "
            f"link to {trend} cannot be validated."
        )

    @staticmethod
    def _follow_up(trend: str, exposure: CompanyExposure) -> str:
        return (
            f"Validate brand ownership, estimate revenue exposure, compare Google Trends by region, "
            f"and inspect upcoming earnings materials for {exposure.ticker}."
        )
