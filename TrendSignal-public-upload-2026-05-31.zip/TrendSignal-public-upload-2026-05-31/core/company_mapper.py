from __future__ import annotations

from connectors.company_discovery import CompanyDiscoveryConnector
from models import CompanyExposure, TrendCluster


class CompanyMapper:
    def __init__(self, discovery: CompanyDiscoveryConnector) -> None:
        self.discovery = discovery

    def map_cluster(self, cluster: TrendCluster, entities: list[str]) -> list[CompanyExposure]:
        exposures = self.discovery.discover(cluster.canonical_term, entities)
        return sorted(
            exposures,
            key=lambda item: (item.ticker_purity + item.revenue_relevance, item.confidence.value),
            reverse=True,
        )

