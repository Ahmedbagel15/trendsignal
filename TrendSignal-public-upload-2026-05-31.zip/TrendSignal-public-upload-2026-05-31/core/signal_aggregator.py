from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from models import TrendCluster, TrendObservation


class AggregatedSignal(BaseModel):
    canonical_term: str
    sources_present: list[str]
    strongest_source: str
    strongest_source_score: float
    source_count: int
    cross_platform_score: float
    single_platform_breakout_score: float
    earliest_seen_source: str
    earliest_seen_at: datetime
    evidence: list[TrendObservation] = Field(default_factory=list)
    member_observation_ids: list[str] = Field(default_factory=list)
    evidence_urls: list[str] = Field(default_factory=list)
    evidence_sources: list[str] = Field(default_factory=list)
    strongest_source_observation_id: str = ""
    youtube_top_video_title: str = ""
    youtube_top_video_url: str = ""
    social_export_source_file: str = ""
    google_search_volume: float = 0
    reddit_mentions: float = 0
    commercial_intent_score: float = 0


class SignalAggregator:
    """Builds inspectable cross-source strength metrics for each clustered trend."""

    def aggregate(self, cluster: TrendCluster) -> AggregatedSignal:
        evidence = cluster.observations
        source_scores: dict[str, float] = {}
        for observation in evidence:
            source = _source_name(observation)
            source_scores[source] = max(source_scores.get(source, 0.0), _source_score(observation))
        strongest_source, strongest_score = max(source_scores.items(), key=lambda item: item[1])
        sources = sorted(source_scores)
        cross_platform = min(1.0, len(sources) / 4)
        single_breakout = min(1.0, strongest_score / 10_000)
        earliest = min(evidence, key=lambda observation: observation.observed_at)
        strongest_observation = max(evidence, key=_source_score)
        youtube_top = max(
            (observation for observation in evidence if observation.platform == "youtube"),
            key=_source_score,
            default=None,
        )
        social_top = max(
            (observation for observation in evidence if observation.source == "social_exports"),
            key=_source_score,
            default=None,
        )
        return AggregatedSignal(
            canonical_term=cluster.canonical_term,
            sources_present=sources,
            strongest_source=strongest_source,
            strongest_source_score=round(strongest_score, 3),
            source_count=len(sources),
            cross_platform_score=round(cross_platform, 3),
            single_platform_breakout_score=round(single_breakout, 3),
            earliest_seen_source=_source_name(earliest),
            earliest_seen_at=earliest.observed_at,
            member_observation_ids=[observation.observation_id for observation in evidence],
            evidence_urls=sorted({observation.url for observation in evidence if observation.url}),
            evidence_sources=sources,
            strongest_source_observation_id=strongest_observation.observation_id,
            evidence=evidence,
            youtube_top_video_title=youtube_top.title if youtube_top and youtube_top.title else "",
            youtube_top_video_url=youtube_top.url if youtube_top and youtube_top.url else "",
            social_export_source_file=str(social_top.metadata.get("source_file") or "") if social_top else "",
            google_search_volume=max(
                (observation.mentions for observation in evidence if observation.platform == "google_trends"),
                default=0,
            ),
            reddit_mentions=sum(observation.mentions for observation in evidence if observation.platform == "reddit"),
            commercial_intent_score=round(
                max((observation.commercial_intent for observation in evidence), default=0),
                3,
            ),
        )

    @staticmethod
    def should_queue(aggregate: AggregatedSignal, has_clean_mapping: bool, commercial_intent: float) -> bool:
        has_breakout_source = aggregate.strongest_source == "youtube" or any(
            observation.source == "social_exports" for observation in aggregate.evidence
        )
        return (
            (has_breakout_source and aggregate.single_platform_breakout_score >= 0.35)
            or aggregate.source_count >= 2
            or aggregate.google_search_volume >= 10_000
            or (commercial_intent >= 0.6 and has_clean_mapping)
        )


def _source_score(observation: TrendObservation) -> float:
    configured = observation.metadata.get("source_score")
    if configured is not None:
        return float(configured)
    if observation.platform == "google_trends":
        return float(observation.mentions)
    return float(observation.velocity or observation.engagement or observation.mentions)


def _source_name(observation: TrendObservation) -> str:
    if observation.source == "social_exports":
        return observation.platform
    return observation.source or observation.platform
