from __future__ import annotations

import csv
import logging
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

LOGGER = logging.getLogger(__name__)

POSITIVE_LABEL_BOOSTS = {
    "valuable": 12.0,
    "watch": 5.0,
    "private_brand": 4.0,
    "needs_mapping": 3.0,
}
NEGATIVE_LABELS = {"reject", "adverse_event", "too_broad"}
ALLOWED_LABELS = set(POSITIVE_LABEL_BOOSTS) | NEGATIVE_LABELS


@dataclass(frozen=True)
class FeedbackAssessment:
    exact_label: str = ""
    similar_term: str = ""
    similar_label: str = ""
    similarity: float = 0.0
    score_adjustment: float = 0.0
    should_reject: bool = False
    reason: str = "No matching feedback."

    @property
    def display_label(self) -> str:
        return self.exact_label or self.similar_label

    @property
    def has_exact_positive_label(self) -> bool:
        return self.exact_label in POSITIVE_LABEL_BOOSTS


class TrendFeedbackStore:
    """Loads user review labels and applies cautious memory to future discoveries."""

    COLUMNS = ("date", "term", "label", "notes")

    def __init__(
        self,
        path: Path,
        similarity_threshold: float = 0.72,
        negative_similarity_threshold: float = 0.90,
    ) -> None:
        self.path = path
        self.similarity_threshold = similarity_threshold
        self.negative_similarity_threshold = negative_similarity_threshold
        self._ensure_file()
        self.rows = self._load_rows()

    def assess(self, term: str) -> FeedbackAssessment:
        normalized = self._normalize(term)
        if not normalized or not self.rows:
            return FeedbackAssessment()

        exact_matches = [row for row in self.rows if row["normalized_term"] == normalized]
        if exact_matches:
            return self._assessment_for_exact(exact_matches[-1])

        similarities = self._similarities(normalized)
        if not similarities:
            return FeedbackAssessment()

        best_row, similarity = max(similarities, key=lambda item: item[1])
        label = best_row["label"]
        threshold = (
            self.negative_similarity_threshold
            if label in NEGATIVE_LABELS
            else self.similarity_threshold
        )
        if similarity < threshold:
            return FeedbackAssessment()

        if label in POSITIVE_LABEL_BOOSTS:
            adjustment = round(POSITIVE_LABEL_BOOSTS[label] * 0.35 * similarity, 2)
            return FeedbackAssessment(
                similar_term=best_row["term"],
                similar_label=label,
                similarity=similarity,
                score_adjustment=adjustment,
                reason=f"Similar to previously labeled '{label}' trend: {best_row['term']}.",
            )

        return FeedbackAssessment(
            similar_term=best_row["term"],
            similar_label=label,
            similarity=similarity,
            score_adjustment=-8.0,
            reason=f"Similar to previously rejected '{label}' trend: {best_row['term']}.",
        )

    def _assessment_for_exact(self, row: dict[str, str]) -> FeedbackAssessment:
        label = row["label"]
        if label in NEGATIVE_LABELS:
            return FeedbackAssessment(
                exact_label=label,
                should_reject=True,
                reason=f"Exact trend was previously labeled '{label}'.",
            )
        return FeedbackAssessment(
            exact_label=label,
            score_adjustment=POSITIVE_LABEL_BOOSTS[label],
            reason=f"Exact trend was previously labeled '{label}'.",
        )

    def _ensure_file(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            return
        with self.path.open("w", newline="", encoding="utf-8") as handle:
            csv.DictWriter(handle, fieldnames=self.COLUMNS).writeheader()

    def _load_rows(self) -> list[dict[str, str]]:
        rows: list[dict[str, str]] = []
        with self.path.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                term = (row.get("term") or "").strip()
                label = (row.get("label") or "").strip().lower()
                if not term or label not in ALLOWED_LABELS:
                    if term or label:
                        LOGGER.warning("Ignoring invalid feedback row for term=%r label=%r", term, label)
                    continue
                rows.append(
                    {
                        "date": (row.get("date") or "").strip(),
                        "term": term,
                        "normalized_term": self._normalize(term),
                        "label": label,
                        "notes": (row.get("notes") or "").strip(),
                    }
                )
        return rows

    def _similarities(self, term: str) -> list[tuple[dict[str, str], float]]:
        examples = [row["normalized_term"] for row in self.rows]
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity

            matrix = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5)).fit_transform(
                [term, *examples]
            )
            scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten().tolist()
        except (ImportError, ValueError):
            scores = [SequenceMatcher(None, term, example).ratio() for example in examples]
        return list(zip(self.rows, scores, strict=True))

    @staticmethod
    def _normalize(term: str) -> str:
        return " ".join(term.casefold().split())
