from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import pandas as pd

from models import TrendObservation


ARCHIVE_COLUMNS = [
    "date",
    "term",
    "platform",
    "mentions",
    "engagement",
    "growth_rate",
    "discovery_rank",
    "discovery_source",
]


class DiscoveryArchive:
    def __init__(self, archive_path: Path, window_days: int = 30) -> None:
        self.archive_path = archive_path
        self.window_days = window_days
        self.archive_path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, observations: list[TrendObservation]) -> None:
        if not observations:
            return
        existing = self.load_all()
        new_rows = pd.DataFrame([self._row(observation) for observation in observations], columns=ARCHIVE_COLUMNS)
        combined = pd.concat([existing, new_rows], ignore_index=True)
        combined = combined.drop_duplicates(subset=["date", "term", "platform"], keep="last")
        combined.to_csv(self.archive_path, index=False)

    def load_all(self) -> pd.DataFrame:
        if not self.archive_path.exists():
            return pd.DataFrame(columns=ARCHIVE_COLUMNS)
        return pd.read_csv(self.archive_path)

    def rolling_window(self, run_date: date) -> pd.DataFrame:
        frame = self.load_all()
        if frame.empty:
            return frame
        frame["date"] = pd.to_datetime(frame["date"]).dt.date
        cutoff = run_date - timedelta(days=self.window_days - 1)
        return frame[frame["date"] >= cutoff].copy()

    def today_top(self, run_date: date, limit: int = 10) -> list[dict[str, object]]:
        frame = self.rolling_window(run_date)
        if frame.empty:
            return []
        today = frame[frame["date"] == run_date].copy()
        if today.empty:
            return []
        today["sort_rank"] = pd.to_numeric(today["discovery_rank"], errors="coerce").fillna(9999)
        today["sort_mentions"] = pd.to_numeric(today["mentions"], errors="coerce").fillna(0)
        today = today.sort_values(["sort_rank", "sort_mentions"], ascending=[True, False]).head(limit)
        return today[["term", "platform", "mentions", "growth_rate", "discovery_rank", "discovery_source"]].to_dict(
            "records"
        )

    def rolling_top(self, run_date: date, limit: int = 10) -> list[dict[str, object]]:
        frame = self.rolling_window(run_date)
        if frame.empty:
            return []
        frame["mentions"] = pd.to_numeric(frame["mentions"], errors="coerce").fillna(0)
        frame["growth_rate"] = pd.to_numeric(frame["growth_rate"], errors="coerce").fillna(0)
        frame["discovery_rank"] = pd.to_numeric(frame["discovery_rank"], errors="coerce").fillna(9999)
        summary = (
            frame.groupby("term", as_index=False)
            .agg(
                days_seen=("date", "nunique"),
                avg_discovery_rank=("discovery_rank", "mean"),
                best_discovery_rank=("discovery_rank", "min"),
                avg_mentions=("mentions", "mean"),
                avg_growth_rate=("growth_rate", "mean"),
                platforms=("platform", lambda values: ",".join(sorted(set(str(value) for value in values)))),
            )
            .sort_values(["days_seen", "avg_discovery_rank", "avg_mentions"], ascending=[False, True, False])
            .head(limit)
        )
        summary["avg_discovery_rank"] = summary["avg_discovery_rank"].round(2)
        summary["avg_mentions"] = summary["avg_mentions"].round(2)
        summary["avg_growth_rate"] = summary["avg_growth_rate"].round(3)
        return summary.to_dict("records")

    @staticmethod
    def _row(observation: TrendObservation) -> dict[str, object]:
        return {
            "date": observation.date.isoformat(),
            "term": observation.term,
            "platform": observation.platform,
            "mentions": observation.mentions,
            "engagement": observation.engagement,
            "growth_rate": observation.growth_rate if observation.growth_rate is not None else "",
            "discovery_rank": observation.metadata.get("discovery_rank", ""),
            "discovery_source": observation.metadata.get("discovery_source", observation.platform),
        }
