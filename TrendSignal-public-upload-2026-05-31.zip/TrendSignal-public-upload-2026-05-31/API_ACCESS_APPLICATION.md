# TrendSignal API Access Description

TrendSignal is a private, non-commercial consumer product-trend research screener. It collects aggregated public trend signals and manually reviewed marketplace evidence to identify specific purchasable products or consumer behaviors that may deserve further investment research.

TrendSignal is designed for personal research workflows. It does not place trades, connect to brokerages, claim guaranteed investment returns, scrape restricted websites, or access private buyer information.

## Intended API Usage

- Discover public product trends and product listings.
- Collect aggregated marketplace and search-demand indicators.
- Validate manually reviewed product candidates.
- Preserve source URLs and raw evidence for auditability.
- Map commercially relevant products to possible public-company exposure for manual review.

## Data Practices

- API keys remain local and are excluded from version control.
- TikTok and Instagram inputs are manually exported CSV files. TrendSignal does not scrape those platforms.
- eBay data is treated as active-listing and marketplace evidence, not proof of completed sales.
- Etsy data is treated as niche-product listing evidence, not exact sales velocity.
- Google Ads Keyword Planner is used only as an optional second-stage validator for reviewed product candidates.

## Research Disclaimer

TrendSignal is a research tool only. It is not financial advice and does not execute trades.
