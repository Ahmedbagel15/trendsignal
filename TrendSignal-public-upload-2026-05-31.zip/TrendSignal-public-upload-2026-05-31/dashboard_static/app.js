const queueBody = document.querySelector("#queue-body");
const searchInput = document.querySelector("#search-input");
const decisionFilter = document.querySelector("#decision-filter");
const discoverButton = document.querySelector("#discover-button");
const validateButton = document.querySelector("#validate-button");
const refreshButton = document.querySelector("#refresh-button");
const saveChangesButton = document.querySelector("#save-changes-button");
const saveSummary = document.querySelector("#save-summary");
const pendingChanges = new Map();

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function compactNumber(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number)) return "0";
  return Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(number);
}

function sourceStatus(value, configuredLabel = "configured") {
  return value ? configuredLabel : "not configured";
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Request failed.");
  return payload;
}

function decisionOptions(selected) {
  const options = [
    ["", "Unreviewed"],
    ["approve", "Approve"],
    ["keep", "Keep"],
    ["watch", "Watch"],
    ["private_brand", "Private brand"],
    ["needs_mapping", "Needs mapping"],
    ["split_cluster", "Split cluster"],
    ["merge_cluster", "Merge cluster"],
    ["reject", "Reject"],
    ["too_broad", "Too broad"],
    ["adverse_event", "Adverse event"],
  ];
  return options
    .map(([value, label]) => `<option value="${value}" ${value === selected ? "selected" : ""}>${label}</option>`)
    .join("");
}

function renderQueue(payload) {
  document.querySelector("#queue-summary").textContent =
    `${payload.filtered} shown from ${payload.total} collected candidates`;
  if (!payload.rows.length) {
    queueBody.innerHTML = `<tr><td colspan="8" class="empty-state">No candidates match this view.</td></tr>`;
    return;
  }
  queueBody.innerHTML = payload.rows
    .map((row) => {
      const pending = pendingChanges.get(row.canonical_term);
      const decision = pending ? pending.decision : String(row.decision || "").toLowerCase();
      const notes = pending ? pending.notes : row.notes;
      const evidenceUrl = String(row.evidence_urls || "").split(",").find(Boolean);
      const evidence = evidenceUrl
        ? `<a href="${escapeHtml(evidenceUrl)}" target="_blank" rel="noreferrer">Open source evidence</a>`
        : `<span class="muted">No source evidence URL</span>`;
      const company = row.candidate_ticker
        ? `${escapeHtml(row.candidate_company)}<br><strong>${escapeHtml(row.candidate_ticker)}</strong>`
        : `<span class="muted">${escapeHtml(row.candidate_company || "Unmapped")}</span>`;
      return `
        <tr data-term="${escapeHtml(row.canonical_term)}" class="${pending ? "dirty-row" : ""}">
          <td>${escapeHtml(row.canonical_term)}</td>
          <td>${escapeHtml(row.sources_present || row.source_origin)}</td>
          <td>${compactNumber(row.strongest_source_score)}</td>
          <td>${compactNumber(row.commercial_intent_score)}</td>
          <td>${company}</td>
          <td>${evidence}</td>
          <td><select class="decision-select">${decisionOptions(decision)}</select></td>
          <td><input class="notes-input" value="${escapeHtml(notes)}" placeholder="Optional note"></td>
        </tr>`;
    })
    .join("");
}

async function loadQueue() {
  const params = new URLSearchParams({
    search: searchInput.value,
    decision: decisionFilter.value,
    limit: "300",
  });
  renderQueue(await request(`/api/queue?${params}`));
}

function updateSaveState() {
  const count = pendingChanges.size;
  saveChangesButton.disabled = count === 0;
  saveSummary.textContent = count ? `${count} unsaved ${count === 1 ? "change" : "changes"}` : "No unsaved changes";
}

function rememberRowChange(row) {
  pendingChanges.set(row.dataset.term, {
    canonical_term: row.dataset.term,
    decision: row.querySelector(".decision-select").value,
    notes: row.querySelector(".notes-input").value,
  });
  row.classList.add("dirty-row");
  updateSaveState();
}

async function saveChanges() {
  if (!pendingChanges.size) return;
  saveChangesButton.disabled = true;
  saveChangesButton.textContent = "Saving";
  const changes = [...pendingChanges.values()];
  try {
    for (const change of changes) {
      await request("/api/queue/decision", {
        method: "POST",
        body: JSON.stringify(change),
      });
      pendingChanges.delete(change.canonical_term);
    }
    saveChangesButton.textContent = "Saved";
    await Promise.all([loadStatus(), loadQueue()]);
  } catch (error) {
    saveChangesButton.textContent = "Retry save";
    window.alert(error.message);
  } finally {
    updateSaveState();
    setTimeout(() => {
      saveChangesButton.textContent = "Save changes";
    }, 900);
  }
}

function renderRun(run) {
  const dot = document.querySelector("#run-dot");
  const label = document.querySelector("#run-label");
  dot.className = "status-dot";
  discoverButton.disabled = run.running;
  validateButton.disabled = run.running;
  if (run.running) {
    dot.classList.add("running");
    label.textContent = `${run.mode} running`;
  } else if (run.return_code && run.return_code !== 0) {
    dot.classList.add("failed");
    label.textContent = `${run.mode} needs attention`;
  } else {
    label.textContent = run.finished_at ? `${run.mode} complete` : "Ready";
  }
  document.querySelector("#run-log").textContent =
    run.log_lines.length ? run.log_lines.join("\n") : "No dashboard-triggered run yet.";
  document.querySelector("#run-time").textContent =
    run.running ? `Started ${run.started_at}` : run.finished_at ? `Finished ${run.finished_at}` : "";
}

async function loadStatus() {
  const payload = await request("/api/status");
  document.querySelector("#stat-total").textContent = payload.queue.total;
  document.querySelector("#stat-unreviewed").textContent = payload.queue.unreviewed;
  document.querySelector("#stat-approved").textContent = payload.queue.approved;
  document.querySelector("#stat-watching").textContent = payload.queue.watching;
  document.querySelector("#stat-private").textContent = payload.queue.private_brands;
  document.querySelector("#stat-mapping").textContent = payload.queue.needs_mapping;
  document.querySelector("#source-youtube").textContent =
    sourceStatus(payload.sources.youtube_key_configured);
  document.querySelector("#source-reddit").textContent =
    sourceStatus(payload.sources.reddit_credentials_configured);
  document.querySelector("#source-exports").textContent =
    sourceStatus(payload.sources.social_exports_available, "files found");
  document.querySelector("#source-best-buy").textContent =
    sourceStatus(payload.sources.best_buy_key_configured);
  document.querySelector("#source-ebay").textContent =
    sourceStatus(payload.sources.ebay_credentials_configured);
  document.querySelector("#source-etsy").textContent =
    sourceStatus(payload.sources.etsy_key_configured);
  document.querySelector("#source-google-ads").textContent =
    sourceStatus(payload.sources.google_ads_credentials_configured);
  document.querySelector("#source-errors").textContent =
    payload.latest.source_errors_text || "No source notes are available yet.";
  renderRun(payload.run);
}

async function loadReports() {
  const payload = await request("/api/reports");
  document.querySelector("#report-list").innerHTML = payload.reports
    .slice(0, 12)
    .map(
      (report) => `
        <div class="report-item">
          <a href="${report.url}" target="_blank">${escapeHtml(report.name)}</a>
          <span class="report-meta">${report.kind} / ${report.size_kb} KB / ${escapeHtml(report.modified_at)}</span>
        </div>`
    )
    .join("") || `<p class="empty-state">No reports yet.</p>`;
}

async function startRun(mode) {
  if (pendingChanges.size && !window.confirm("You have unsaved review changes. Continue without saving them?")) {
    return;
  }
  try {
    await request("/api/run", { method: "POST", body: JSON.stringify({ mode }) });
    await loadStatus();
  } catch (error) {
    window.alert(error.message);
  }
}

let searchTimer;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadQueue, 250);
});
decisionFilter.addEventListener("change", loadQueue);
queueBody.addEventListener("change", (event) => {
  if (event.target.classList.contains("decision-select")) rememberRowChange(event.target.closest("tr"));
});
queueBody.addEventListener("input", (event) => {
  if (event.target.classList.contains("notes-input")) rememberRowChange(event.target.closest("tr"));
});
saveChangesButton.addEventListener("click", saveChanges);
discoverButton.addEventListener("click", () => startRun("discover"));
validateButton.addEventListener("click", () => startRun("validate"));
refreshButton.addEventListener("click", async () => {
  await Promise.all([loadStatus(), loadQueue(), loadReports()]);
});
document.querySelector("#reports-refresh").addEventListener("click", loadReports);

Promise.all([loadStatus(), loadQueue(), loadReports()]);
setInterval(loadStatus, 3000);
window.addEventListener("beforeunload", (event) => {
  if (!pendingChanges.size) return;
  event.preventDefault();
  event.returnValue = "";
});
