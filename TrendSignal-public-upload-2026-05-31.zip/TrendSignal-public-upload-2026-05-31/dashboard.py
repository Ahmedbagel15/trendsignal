from __future__ import annotations

import argparse
import json
import logging
import mimetypes
import subprocess
import sys
import threading
import webbrowser
from collections import deque
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

import pandas as pd

from core.review_queue import QUEUE_COLUMNS, ReviewQueue


ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "dashboard_static"
REPORTS_DIR = ROOT / "data" / "reports"
QUEUE_PATH = ROOT / "data" / "processed" / "validation_queue.csv"
FEEDBACK_PATH = ROOT / "data" / "processed" / "trend_feedback.csv"
ALLOWED_DECISIONS = {
    "",
    "approve",
    "keep",
    "watch",
    "private_brand",
    "needs_mapping",
    "split_cluster",
    "merge_cluster",
    "reject",
    "too_broad",
    "adverse_event",
}
DECISION_TO_FEEDBACK = {
    "keep": "valuable",
    "watch": "watch",
    "private_brand": "private_brand",
    "needs_mapping": "needs_mapping",
    "split_cluster": "needs_mapping",
    "merge_cluster": "needs_mapping",
    "reject": "reject",
    "too_broad": "too_broad",
    "adverse_event": "adverse_event",
}
REPORT_SUFFIXES = {".csv", ".md"}

LOGGER = logging.getLogger("trendsignal.dashboard")


def _json_value(value: Any) -> Any:
    if pd.isna(value):
        return ""
    if hasattr(value, "item"):
        return value.item()
    return value


def _read_env_keys() -> set[str]:
    env_path = ROOT / ".env"
    if not env_path.exists():
        return set()
    keys: set[str] = set()
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if value.strip():
            keys.add(key.strip())
    return keys


def _latest_file(pattern: str) -> Path | None:
    files = list(REPORTS_DIR.glob(pattern))
    return max(files, key=lambda path: path.stat().st_mtime) if files else None


def _report_files() -> list[dict[str, Any]]:
    if not REPORTS_DIR.exists():
        return []
    reports = [
        path
        for path in REPORTS_DIR.iterdir()
        if path.is_file() and path.suffix.lower() in REPORT_SUFFIXES
    ]
    reports.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return [
        {
            "name": path.name,
            "kind": path.suffix.lstrip(".").upper(),
            "size_kb": round(path.stat().st_size / 1024, 1),
            "modified_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="minutes"),
            "url": f"/reports/{path.name}",
        }
        for path in reports[:40]
    ]


def _load_queue() -> pd.DataFrame:
    return ReviewQueue(QUEUE_PATH).load()


def _queue_payload(query: dict[str, list[str]]) -> dict[str, Any]:
    frame = _load_queue()
    if frame.empty:
        return {"rows": [], "total": 0, "filtered": 0}

    total = len(frame)
    search = query.get("search", [""])[0].strip().lower()
    decision = query.get("decision", ["all"])[0].strip().lower()
    source = query.get("source", ["all"])[0].strip().lower()
    limit = min(max(int(query.get("limit", ["250"])[0]), 1), 1000)

    if search:
        searchable = (
            frame["canonical_term"].fillna("").astype(str)
            + " "
            + frame["candidate_company"].fillna("").astype(str)
            + " "
            + frame["candidate_ticker"].fillna("").astype(str)
        ).str.lower()
        frame = frame[searchable.str.contains(search, regex=False)]
    if decision != "all":
        frame = frame[frame["decision"].fillna("").astype(str).str.lower() == decision]
    if source != "all":
        frame = frame[
            frame["sources_present"].fillna("").astype(str).str.lower().str.contains(source, regex=False)
        ]

    numeric_strength = pd.to_numeric(frame["strongest_source_score"], errors="coerce").fillna(0)
    numeric_intent = pd.to_numeric(frame["commercial_intent_score"], errors="coerce").fillna(0)
    frame = frame.assign(_strength=numeric_strength, _intent=numeric_intent)
    frame = frame.sort_values(["_strength", "_intent"], ascending=False).head(limit)
    frame = frame.drop(columns=["_strength", "_intent"])
    rows = [
        {column: _json_value(row.get(column, "")) for column in QUEUE_COLUMNS}
        for row in frame.to_dict(orient="records")
    ]
    return {"rows": rows, "total": total, "filtered": len(rows)}


def _save_decision(payload: dict[str, Any]) -> dict[str, Any]:
    canonical_term = str(payload.get("canonical_term", "")).strip()
    decision = str(payload.get("decision", "")).strip().lower()
    notes = str(payload.get("notes", "")).strip()
    if decision == "split_cluster" and not notes:
        notes = "Review cluster members and promote the commercially distinct raw term into its own cluster next run."
    if decision == "merge_cluster" and not notes:
        notes = "Review related canonical terms and record which clusters should merge next run."
    if not canonical_term:
        raise ValueError("canonical_term is required")
    if decision not in ALLOWED_DECISIONS:
        raise ValueError(f"Unsupported decision: {decision}")

    queue = ReviewQueue(QUEUE_PATH)
    frame = queue.load()
    matches = frame["canonical_term"].fillna("").astype(str) == canonical_term
    if not matches.any():
        raise ValueError(f"Candidate not found: {canonical_term}")
    frame.loc[matches, "decision"] = decision
    frame.loc[matches, "notes"] = notes
    QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
    frame[QUEUE_COLUMNS].to_csv(QUEUE_PATH, index=False)
    feedback_label = DECISION_TO_FEEDBACK.get(decision)
    if feedback_label:
        _save_feedback(canonical_term, feedback_label, notes)
    return {"saved": True, "canonical_term": canonical_term, "decision": decision}


def _save_feedback(term: str, label: str, notes: str) -> None:
    columns = ["date", "term", "label", "notes"]
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
    existing = (
        pd.read_csv(FEEDBACK_PATH, keep_default_na=False)
        if FEEDBACK_PATH.exists()
        else pd.DataFrame(columns=columns)
    )
    incoming = pd.DataFrame(
        [{"date": datetime.now().date().isoformat(), "term": term, "label": label, "notes": notes}],
        columns=columns,
    )
    combined = pd.concat([existing, incoming], ignore_index=True)
    combined = combined.drop_duplicates(subset=["date", "term", "label"], keep="last")
    combined.reindex(columns=columns).to_csv(FEEDBACK_PATH, index=False)


class DashboardState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.running = False
        self.mode = ""
        self.started_at = ""
        self.finished_at = ""
        self.return_code: int | None = None
        self.lines: deque[str] = deque(maxlen=250)

    def start(self, mode: str) -> None:
        if mode not in {"discover", "validate"}:
            raise ValueError("mode must be discover or validate")
        with self.lock:
            if self.running:
                raise RuntimeError("A TrendSignal run is already in progress.")
            self.running = True
            self.mode = mode
            self.started_at = datetime.now().isoformat(timespec="seconds")
            self.finished_at = ""
            self.return_code = None
            self.lines.clear()
            self.lines.append(f"Starting TrendSignal {mode} run...")
        threading.Thread(target=self._execute, args=(mode,), daemon=True).start()

    def _execute(self, mode: str) -> None:
        try:
            process = subprocess.Popen(
                [sys.executable, "main.py", mode],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            assert process.stdout is not None
            for line in process.stdout:
                with self.lock:
                    self.lines.append(line.rstrip())
            return_code = process.wait()
        except Exception as exc:  # noqa: BLE001
            LOGGER.exception("Dashboard-triggered %s run failed", mode)
            with self.lock:
                self.lines.append(f"Run failed to start: {exc}")
            return_code = 1
        with self.lock:
            self.running = False
            self.return_code = return_code
            self.finished_at = datetime.now().isoformat(timespec="seconds")
            message = "Run completed." if return_code == 0 else f"Run exited with status {return_code}."
            self.lines.append(message)

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "running": self.running,
                "mode": self.mode,
                "started_at": self.started_at,
                "finished_at": self.finished_at,
                "return_code": self.return_code,
                "log_lines": list(self.lines),
            }


STATE = DashboardState()


def _status_payload() -> dict[str, Any]:
    queue = _load_queue()
    decisions = queue["decision"].fillna("").astype(str).str.lower() if not queue.empty else pd.Series(dtype=str)
    env_keys = _read_env_keys()
    source_errors = _latest_file("*_source_errors.md")
    latest_report = _latest_file("*_discovery_audit.md")
    latest_youtube = _latest_file("*_youtube_discoveries.csv")
    return {
        "run": STATE.snapshot(),
        "queue": {
            "total": int(len(queue)),
            "unreviewed": int((decisions == "").sum()),
            "approved": int(decisions.isin(["approve", "approved", "validate"]).sum()),
            "watching": int((decisions == "watch").sum()),
            "private_brands": int((decisions == "private_brand").sum()),
            "needs_mapping": int((decisions == "needs_mapping").sum()),
        },
        "sources": {
            "youtube_key_configured": "YOUTUBE_API_KEY" in env_keys,
            "reddit_credentials_configured": {
                "REDDIT_CLIENT_ID",
                "REDDIT_CLIENT_SECRET",
            }.issubset(env_keys),
            "social_exports_available": any((ROOT / "data" / "raw" / "social_exports").glob("*.csv")),
            "best_buy_key_configured": "BEST_BUY_API_KEY" in env_keys,
            "ebay_credentials_configured": {"EBAY_CLIENT_ID", "EBAY_CLIENT_SECRET"}.issubset(env_keys),
            "etsy_key_configured": {"ETSY_KEYSTRING", "ETSY_SHARED_SECRET"}.issubset(env_keys),
            "google_ads_credentials_configured": {
                "GOOGLE_ADS_DEVELOPER_TOKEN",
                "GOOGLE_ADS_CUSTOMER_ID",
            }.issubset(env_keys),
        },
        "latest": {
            "audit": latest_report.name if latest_report else "",
            "youtube": latest_youtube.name if latest_youtube else "",
            "source_errors": source_errors.name if source_errors else "",
            "source_errors_text": source_errors.read_text(encoding="utf-8") if source_errors else "",
        },
    }


class DashboardHandler(BaseHTTPRequestHandler):
    def _write_json(self, payload: dict[str, Any], status: HTTPStatus = HTTPStatus.OK) -> None:
        body = json.dumps(payload, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _write_file(self, path: Path) -> None:
        if not path.exists() or not path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        body = path.read_bytes()
        content_type, _ = mimetypes.guess_type(path.name)
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type or 'application/octet-stream'}; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length).decode("utf-8")) if length else {}

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._write_file(STATIC_DIR / "index.html")
            return
        if parsed.path.startswith("/static/"):
            name = Path(unquote(parsed.path.removeprefix("/static/"))).name
            self._write_file(STATIC_DIR / name)
            return
        if parsed.path == "/api/status":
            self._write_json(_status_payload())
            return
        if parsed.path == "/api/queue":
            try:
                self._write_json(_queue_payload(parse_qs(parsed.query)))
            except ValueError as exc:
                self._write_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        if parsed.path == "/api/reports":
            self._write_json({"reports": _report_files()})
            return
        if parsed.path == "/api/run":
            self._write_json(STATE.snapshot())
            return
        if parsed.path.startswith("/reports/"):
            name = Path(unquote(parsed.path.removeprefix("/reports/"))).name
            self._write_file(REPORTS_DIR / name)
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        try:
            payload = self._read_json()
            if parsed.path == "/api/run":
                STATE.start(str(payload.get("mode", "")))
                self._write_json({"started": True, "run": STATE.snapshot()}, HTTPStatus.ACCEPTED)
                return
            if parsed.path == "/api/queue/decision":
                self._write_json(_save_decision(payload))
                return
            self.send_error(HTTPStatus.NOT_FOUND)
        except (RuntimeError, ValueError, json.JSONDecodeError) as exc:
            self._write_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def log_message(self, format_string: str, *args: Any) -> None:
        LOGGER.debug(format_string, *args)


def main() -> None:
    parser = argparse.ArgumentParser(description="TrendSignal local dashboard")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8765, type=int)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s - %(message)s")
    server = ThreadingHTTPServer((args.host, args.port), DashboardHandler)
    url = f"http://{args.host}:{args.port}"
    LOGGER.info("TrendSignal dashboard is available at %s", url)
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        LOGGER.info("Stopping dashboard.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
