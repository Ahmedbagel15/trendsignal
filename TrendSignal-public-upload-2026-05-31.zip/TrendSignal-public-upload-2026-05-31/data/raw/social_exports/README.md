# Real Social Export CSVs

Place manually exported CSVs from restricted social or marketplace sources here.

Preferred canonical columns:

```text
term,platform,mentions,engagement,growth_rate,date,url,notes
```

Flexible export fields are also accepted, including `hashtag`, `query`, `title`,
`views`, `play_count`, `likes`, `favorites`, `comments`, `shares`, `saves`,
`rank`, `observed_at`, `exported_at`, and `link`.

Examples of useful platform values:

- `tiktok_creative_center`
- `tiktok_trending_searches`
- `instagram_explore`
- `x_twitter_export`
- `facebook_marketplace`

Download TikTok Creative Center exports when available. For Instagram Explore
screenshots, manually transcribe visible trends into CSV rows. Do not scrape
TikTok or Instagram pages directly.

Files in this folder are treated as real user-provided early-virality signals.
Samples in `data/raw/sample_inputs/` are format examples only.
